# -*- coding: utf-8 -*-
"""Skill 侧薄封装：调用分发包内的交付前校验器。

用法：python verify.py [分发包根目录]
"""
import os
import sys
import subprocess

pack = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.getcwd()
tool = os.path.join(pack, "deploy", "verify_pack.py")
if not os.path.exists(tool):
    print("未找到 %s，请传入分发包根目录" % tool)
    sys.exit(2)
sys.exit(subprocess.call([sys.executable, tool, "--root", pack]))
