---
name: radar-deploy
description: "部署、校验、升级与排障「A股投研雷达」本地控制台（Windows + 127.0.0.1:8080）。当用户要求部署投研雷达、安装雷达分发包、生成页面与后台服务、检查雷达部署是否干净、升级雷达代码、或排查雷达启动/访问/任务失败时使用。关键词：投研雷达、radar-deploy、部署雷达、雷达控制台、技巧工坊。"
agent_created: true
---

# 投研雷达部署与运维

## 这个 Skill 管什么

把一份「投研雷达分发包」就地部署成可访问的本地服务：单进程 `server.py` 托管 4 个页面、5 个任务脚本，用户双击 `console/start-console.bat` 后访问 `http://127.0.0.1:8080`。

**Skill 只是安装器与知识包，不是常驻服务。** 运行时完全由包内 `.venv` + `server.py` 承担，不依赖 WorkBuddy 会话存活。

## 首次部署

用户会把包解压到某个目录（下称 `<PACK>`），并把 `PROMPT.md` 里的提示词粘进 WorkBuddy。执行顺序：

1. **环境预检**：确认 Windows、Python ≥ 3.10、端口 8080 空闲、包文件齐全。
2. **交付前校验**（可选但建议）：`python <PACK>\deploy\verify_pack.py`，必须为退出码 0。它检查个人自选股、本机路径痕迹、密码盐/日志/缓存是否被误带入。
3. **安装 Skill 自身**：把 `<PACK>\skills\radar-deploy` 整个目录复制到 `%USERPROFILE%\.workbuddy\skills\radar-deploy`，提示用户在 WorkBuddy 中信任/启用一次。此步失败不阻断部署。
4. **执行部署脚本**：
   ```
   python <PACK>\deploy\bootstrap.py
   ```
   可选参数：`--port 8099` 换端口、`--mirror` 用国内 PyPI 镜像、`--skip-venv` 跳过依赖安装、`--no-launch` 只部署不启动。
5. **自检**：脚本会轮询 `/api/health` 与免登录 API `/api/rules`；若自动拉起服务窗口失败，提示用户**手动双击** `console\start-console.bat`。
6. **汇报**：输出访问地址（本机免登录）、数据目录、启动/停止/升级命令。

## 绝不覆盖

- `<PACK>\data\` 下任何已有 JSON / MD / XLSX（用户真实数据）
- `<PACK>\data\config\` 下已有配置（尤其用户自己的自选清单）
- `<PACK>\console\auth.json`（若用户为将来公网部署自行创建）
- `<PACK>\Materials\`（用户上传的技巧素材）

升级时**只覆盖** `console\` 与 `scripts\`，其余一律保留。

## 双击启动（首版唯一方式，不做开机自启）

1. 双击 `console\start-console.bat` → 服务在标题为 `RadarConsole` 的独立窗口运行
2. bat 先用 raw socket 确认 8080 真正监听，再自动打开 `http://127.0.0.1:8080`，**无需登录**
3. **关闭 `RadarConsole` 窗口即停止服务**；launcher 窗口可直接关掉；下次再用重新双击

bat 必须保持**纯 ASCII + CRLF**：cmd.exe 按当前代码页解析 .bat，中文内容叠加 `chcp 65001` 会造成字节错位、把中文片段当成命令执行，服务根本起不来。bat 还会探测 `.venv` 解释器、清空 `AUTH_REQUIRED`、设置 `RADAR_DATA` / `PYTHONIOENCODING=utf-8` / `NO_PROXY`，并检查端口避免双实例。

## 常见故障

| 现象 | 原因与处理 |
| --- | --- |
| 双击 bat 后服务没起来、窗口出现乱码命令 | bat 被改成了非 ASCII 编码；重新解压原始包，不要手动另存为 UTF-8/GBK。修复版为纯 ASCII + CRLF |
| curl / 自检访问 127.0.0.1 得到 502 | `HTTP_PROXY` 未设 `NO_PROXY`；bat 与 bootstrap 已自动绕过，浏览器仍被拦截时给 `127.0.0.1;localhost` 加系统代理绕过 |
| 双击后浏览器先弹错误页 | 旧版先开浏览器再起服务；修复版改为端口就绪后再开，刷新即可 |
| 首次打开是空屏 | `data\` 下没有示例快照；重新跑 `bootstrap.py`（仅当数据目录为空时才会写入示例） |
| 打开页面被要求登录 | 环境变量 `AUTH_REQUIRED` 被设成了 `1`；清除该变量并重启 bat（本机默认免登录） |
| 任务打印 emoji 后退出码非 0 | bat 未生效导致子进程 stdout 为 GBK；确认用 bat 启动、或设 `PYTHONIOENCODING=utf-8` |
| 首屏数据是「示例数据」 | 正常。运行任一任务后会抓取当日真实行情并覆盖 |
| akshare 抓不到行情 | 需外网；检查网络/代理，或在非交易时段稍后重试 |
| 端口被占用 | 换端口启动：`start-console.bat` 内改 `PORT`，或 `python server.py 8099` |

## 校验与排障命令

```
python <PACK>\deploy\verify_pack.py              # 交付前黑/隐私闸门
python <PACK>\deploy\bootstrap.py --no-launch    # 离线自检（不启动服务）
python <PACK>\console\server.py 8099             # 手动指定端口启动
```

更完整的说明见 `references/部署说明.md`。
