# 复制到 WorkBuddy 执行的提示词

> 使用方式：把下面分隔线内的整段文字复制进 WorkBuddy 对话框并发送。首次部署不需要预先安装任何 Skill。

---

请帮我在这台 Windows 电脑上部署「A股投研雷达」本地控制台。

**一、定位分发包**
在我下载/解压的目录里找到同时含有 `deploy\bootstrap.py`、`console\server.py`、`demo\manifest.json` 的文件夹，记为 `<PACK>`（就地部署，解压目录就是安装目录，不要复制到别处）。若找不到，先向我询问路径，不要猜测、不要创建同名空目录。

**二、环境预检**（任一项不满足就停止并说明原因，不要继续）
- 操作系统为 Windows，且 `python --version` ≥ 3.10
- 端口 8080 未被占用（若已有本服务在监听，直接打开浏览器即可，不要再启动第二个实例）
- `<PACK>` 内 `console\`、`scripts\`、`config\`、`demo\`、`requirements.txt` 齐全

**三、执行部署**
1. 运行 `python <PACK>\deploy\verify_pack.py`。退出码必须为 0；若非 0，把问题清单原样给我并立即停止——这表示包里混入了不该分发的内容。
2. 把 `<PACK>\skills\radar-deploy` 整个目录复制到 `%USERPROFILE%\.workbuddy\skills\radar-deploy`，然后提示我在 WorkBuddy 中信任/启用一次这个 Skill，供以后升级和排障使用。**此步失败不阻断部署**，说明情况后继续。
3. 运行 `python <PACK>\deploy\bootstrap.py`。脚本会：建 `.venv` 并安装依赖 → 生成演示自选清单 → 写入示例快照 → 拉起服务窗口 → 自检 `/api/health` 与免登录 API（本机回环探测自动绕开代理）。**若本机代理会拦截镜像站，不要加 `--mirror`**，用默认官方 PyPI。

**四、硬性约束**
- 禁止覆盖 `<PACK>\data\`、`<PACK>\data\config\`、`Materials\` 中任何**已存在**的内容。
- 禁止修改包内 Python 源码来绕过任何报错。
- 任何一步失败立即停止，说明失败原因和回滚方式（只需删除 `<PACK>\.venv` 与 `<PACK>\data` 后重跑，代码文件不受影响）。
- 不要注册开机自启、不要创建系统服务；服务只由 `console\start-console.bat` 双击启动。

**五、完成后向我汇报**
- 访问地址 `http://127.0.0.1:8080/`（**本机免登录，打开即用**；服务只监听 127.0.0.1）
- 数据目录的绝对路径
- 启动方式（双击 `console\start-console.bat`）与停止方式（关闭标题为 `RadarConsole` 的服务窗口）
- 升级注意事项（只覆盖 `console\` 与 `scripts\`，绝不覆盖 `data\` 与 `Materials\`）
- 首次打开显示的是示例数据，运行任一任务后会自动换成当日真实行情
- 若服务窗口没能自动拉起，明确提示我手动双击 bat，不要假装部署已完全成功（非交互会话里自动拉起的窗口常常不存活）

---

## 备注

- 想换端口：部署时加 `--port 8099`；之后手动启动用 `python console\server.py 8099`。
- 只想校验不部署：`python <PACK>\deploy\bootstrap.py --no-launch --skip-venv`。
- 后续运维（重跑任务、换端口、升级、看日志）可直接对 WorkBuddy 说，已安装的 `radar-deploy` Skill 会给出对应 SOP。
- 将来若需公网部署：在 `start-console.bat` 里设 `AUTH_REQUIRED=1` 恢复账号密码登录，创建 `console\auth.json` 配置强密码，并自行加 TLS 反向代理。
- 双击 bat 后会有两个窗口：标题为 `RadarConsole` 的服务窗口（保留），以及一个 launcher 窗口（可直接关掉）。bat 会等 8080 真正监听后才打开浏览器。
- bat 与 bootstrap 已自动把 `127.0.0.1,localhost,::1` 并入 `NO_PROXY`；若浏览器仍显示 502，请在系统代理里给 `127.0.0.1;localhost` 加绕过。
- 若双击后窗口出现乱码并把中文当命令执行，说明 bat 被改成了非 ASCII 编码：重新解压原始分发包，不要手动另存为 UTF-8/GBK。
