# -*- coding: utf-8 -*-
"""分发包交付前硬闸门。

扫描整个待发布包，禁止出现：
  1. 分发者的 9 只个人自选股（代码或名称）
  2. 本机痕迹（个人路径、旧数据目录名、微信素材文件名、弱默认口令）
  3. 不该随包分发的文件（密码盐、auth.json、自选清单、日志、缓存、字节码）
     注：登录虽默认关闭，密码类文件仍一律禁止随包分发

用法：python deploy/verify_pack.py [--root <包根目录>]
退出码 0 = 通过；1 = 发现问题（逐条打印文件与行号）。
"""
import os
import io
import sys
import argparse

BS = chr(92)
BAN_CODES = ["600900", "601899", "600406", "600598", "601579",
             "603087", "600750", "603528", "002027"]
BAN_NAMES = ["长江电力", "紫金矿业", "国电南瑞", "北大荒", "会稽山",
             "甘李药业", "华润江中", "多伦科技", "分众传媒"]
FORBIDDEN_TEXT = [
    "stock_research",
    "C:" + BS + "Users" + BS + "hp",
    "admin123",
    "微信图片_",
]
FORBIDDEN_NAMES = {".auth_salt", "auth.json", "watch_stock.csv",
                   "server_out.log", "server_err.log", "launcher_out.log",
                   "worker_out.log", "run_stockpool.log"}
FORBIDDEN_SUFFIX = (".pyc", ".log", ".xlsx", ".jpg", ".jpeg", ".png")
TEXT_EXT = {".py", ".html", ".css", ".bat", ".md", ".json", ".csv", ".txt", ".yaml", ".yml"}
SKIP_DIRS = {".venv", "__pycache__", "data", ".git", "_shots"}
SELF_NAME = os.path.basename(__file__)


def check(root):
    issues = []
    scanned = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            path = os.path.join(dirpath, fn)
            rel = os.path.relpath(path, root).replace(os.sep, "/")
            if fn in FORBIDDEN_NAMES:
                issues.append("%s : 不应随包分发的文件" % rel)
            if fn.lower().endswith(FORBIDDEN_SUFFIX):
                issues.append("%s : 不应随包分发的二进制/日志文件" % rel)
            if fn == SELF_NAME:
                continue  # 校验器自身持有黑名单常量，跳过
            if os.path.splitext(fn)[1].lower() not in TEXT_EXT:
                continue
            scanned += 1
            try:
                txt = io.open(path, encoding="utf-8", errors="replace").read()
            except Exception as e:
                issues.append("%s : 无法读取 %s" % (rel, e))
                continue
            for lineno, line in enumerate(txt.splitlines(), 1):
                for token in BAN_CODES + BAN_NAMES:
                    if token in line:
                        issues.append("%s:%d : 命中禁用标的 %s" % (rel, lineno, token))
                for token in FORBIDDEN_TEXT:
                    if token in line:
                        issues.append("%s:%d : 命中本机痕迹 %s" % (rel, lineno, token))
    return scanned, issues


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    scanned, issues = check(root)
    print("扫描文本文件：%d 个" % scanned)
    if issues:
        print("❌ 校验未通过，共 %d 处问题：" % len(issues))
        for x in issues[:60]:
            print("   -", x)
        if len(issues) > 60:
            print("   ... 另有 %d 处" % (len(issues) - 60))
        return 1
    print("✅ 校验通过：无个人自选股、无本机痕迹、无敏感文件")
    return 0


if __name__ == "__main__":
    sys.exit(main())
