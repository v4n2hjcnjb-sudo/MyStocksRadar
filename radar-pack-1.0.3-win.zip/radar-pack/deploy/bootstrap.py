# -*- coding: utf-8 -*-
"""投研雷达 · 一键部署（就地部署：解压目录即安装目录）。

用法：
    python deploy/bootstrap.py                    # 完整部署并启动
    python deploy/bootstrap.py --no-launch        # 只部署不启动（自检用）
    python deploy/bootstrap.py --skip-venv        # 跳过依赖安装（已有环境时）
    python deploy/bootstrap.py --port 8099        # 指定端口
    python deploy/bootstrap.py --mirror           # 使用清华 PyPI 镜像

原则：任何一步失败立即停止；绝不覆盖已存在的 config/ 与用户数据。
"""
import os
import io
import sys
import json
import time
import socket
import shutil
import argparse
import subprocess
import urllib.request
import urllib.error
import datetime as dt

# 本机回环探测必须绕开 HTTP_PROXY/HTTPS_PROXY；外网行情请求仍走用户原有代理
LOCAL_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONSOLE = os.path.join(ROOT, "console")
SCRIPTS = os.path.join(ROOT, "scripts")
CONFIG = os.path.join(ROOT, "config")
DEMO = os.path.join(ROOT, "demo")
VENV = os.path.join(ROOT, ".venv")
DATA = os.path.join(ROOT, "data")
REQUIREMENTS = os.path.join(ROOT, "requirements.txt")
BAT = os.path.join(CONSOLE, "start-console.bat")

SUBDIRS = ["daily_hot", "stock_pool", "watch_list", "daily_report", "config", "cache", "Materials"]
WATCH_SEED = ["600519,贵州茅台", "600036,招商银行", "601318,中国平安",
              "300750,宁德时代", "000858,五粮液", "600276,恒瑞医药", "000333,美的集团"]
REQUIRED = [os.path.join(CONSOLE, "server.py"), BAT,
            os.path.join(DEMO, "manifest.json"), REQUIREMENTS,
            os.path.join(CONFIG, "indicators.json")]


def log(tag, msg):
    print("[%s] %s" % (tag, msg), flush=True)


def fail(msg, hint=""):
    log("FAIL", msg)
    if hint:
        log("HINT", hint)
    log("ROLLBACK", "如需重来，仅删除安装目录下的 .venv\\ 与 data\\ 后重新运行本脚本；代码文件不受影响。")
    sys.exit(1)


def precheck(port, no_launch):
    if sys.platform != "win32":
        fail("首版仅支持 Windows。", "请在 Windows 机器上部署。")
    if sys.version_info < (3, 10):
        fail("需要 Python 3.10 及以上，当前 %s" % sys.version.split()[0])
    missing = [p for p in REQUIRED if not os.path.exists(p)]
    if missing:
        fail("分发包不完整，缺少：%s" % ", ".join(os.path.relpath(m, ROOT) for m in missing))
    need = ["daily_hot.py", "trend_report.py", "watch_monitor.py",
            "stock_pool.py", "review_report.py", "ta_rules.py", "data_common.py"]
    lack = [f for f in need if not os.path.exists(os.path.join(SCRIPTS, f))]
    if lack:
        fail("缺少任务脚本：%s" % ", ".join(lack))
    if not no_launch:
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", port))
        except OSError:
            fail("端口 %d 已被占用。" % port, "关闭占用该端口的程序，或改用 --port 指定其它端口。")
        finally:
            s.close()
    log("OK", "环境预检通过（%s / Python %s / 端口 %d）" % (sys.platform, sys.version.split()[0], port))


def ensure_venv(skip, mirror):
    py = os.path.join(VENV, "Scripts", "python.exe")
    if skip:
        log("SKIP", "按参数跳过虚拟环境安装")
        return py if os.path.exists(py) else sys.executable
    if not os.path.exists(py):
        log("STEP", "创建虚拟环境 .venv ...")
        r = subprocess.run([sys.executable, "-m", "venv", VENV],
                           capture_output=True, text=True)
        if r.returncode != 0:
            fail("创建 venv 失败：%s" % (r.stderr or r.stdout).strip()[-400:])
    log("STEP", "安装依赖（首次约需 1-3 分钟）...")
    cmd = [py, "-m", "pip", "install", "-r", REQUIREMENTS, "--disable-pip-version-check"]
    if mirror:
        cmd += ["-i", "https://pypi.tuna.tsinghua.edu.cn/simple"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        fail("依赖安装失败：%s" % (r.stderr or r.stdout).strip()[-600:],
             "可加 --mirror 使用国内镜像；或手动在 .venv 内执行 pip install -r requirements.txt")
    log("OK", "依赖就绪：%s" % py)
    return py


def ensure_config():
    """只补齐缺失项，绝不覆盖用户已有配置与数据。"""
    for d in SUBDIRS:
        os.makedirs(os.path.join(DATA, d), exist_ok=True)
    cfg = os.path.join(DATA, "config")

    watch = os.path.join(cfg, "watch_stock.csv")
    if not os.path.exists(watch):
        io.open(watch, "w", encoding="utf-8", newline="").write(
            "code,name\n" + "\n".join(WATCH_SEED) + "\n")
        log("OK", "已生成演示自选清单（7 只中性标的）")
    else:
        log("KEEP", "保留已有 watch_stock.csv")

    for fn in ("indicators.json", "strategy_rule.md", "material_stocks.csv"):
        src, dst = os.path.join(CONFIG, fn), os.path.join(cfg, fn)
        if not os.path.exists(dst):
            shutil.copy2(src, dst)
    log("OK", "配置种子就位")

    # 示例快照：仅当对应数据目录完全为空时写入，避免覆盖任何真实数据
    man = json.load(io.open(os.path.join(DEMO, "manifest.json"), encoding="utf-8"))
    today = dt.date.today().strftime("%Y-%m-%d")
    ph = man.get("placeholder", "__DEMO_DATE__")
    by_dir = {}
    for item in man["files"]:
        by_dir.setdefault(item["subdir"], []).append(item)
    written = 0
    for subdir, items in by_dir.items():
        d = os.path.join(DATA, subdir)
        if any(f.endswith((".json", ".md")) for f in os.listdir(d)):
            log("KEEP", "%s/ 已有数据，跳过示例快照" % subdir)
            continue
        for item in items:
            src = os.path.join(DEMO, item["src"])
            dst = os.path.join(d, item["dst"].replace("{date}", today))
            if os.path.exists(dst):
                continue
            txt = io.open(src, encoding="utf-8").read().replace(ph, today)
            io.open(dst, "w", encoding="utf-8", newline="").write(txt)
            written += 1
    log("OK", "示例快照写入 %d 个文件（首次打开不空屏，运行任务后自动覆盖）" % written)

    # 本机免登录：不生成任何密码文件；登录代码仅在 AUTH_REQUIRED=1 时启用


def launch(port):
    env = dict(os.environ)
    env["RADAR_DATA"] = DATA
    env["PYTHONIOENCODING"] = "utf-8"
    # 本地回环绕过代理；外网代理保留，任务脚本抓行情仍可联网
    env["NO_PROXY"] = "127.0.0.1,localhost,::1," + env.get("NO_PROXY", "")
    env["no_proxy"] = env["NO_PROXY"]
    flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
    try:
        subprocess.Popen(["cmd.exe", "/c", BAT], cwd=CONSOLE, env=env, creationflags=flags)
        log("OK", "已拉起服务窗口（console/start-console.bat）")
        return True
    except Exception as e:
        log("WARN", "自动启动失败：%s；请手动双击 console/start-console.bat" % e)
        return False


def selfcheck(port, launched):
    if not launched:
        # 未启动模式：只做文件自检
        need = [os.path.join(DATA, "daily_hot"), os.path.join(DATA, "watch_list"),
                os.path.join(DATA, "daily_report"), os.path.join(DATA, "stock_pool")]
        ok = all(os.path.isdir(d) and os.listdir(d) for d in need)
        log("OK" if ok else "FAIL", "离线自检：四个看板数据目录 %s" % ("均已就绪" if ok else "未就绪"))
        if not ok:
            sys.exit(1)
        return
    base = "http://127.0.0.1:%d" % port
    for _ in range(30):
        try:
            # 显式禁用代理，避免 HTTP_PROXY 把 127.0.0.1 请求送去外网代理
            body = LOCAL_OPENER.open(base + "/api/health", timeout=3).read().decode()
            json.loads(body)
            break
        except Exception:
            time.sleep(1)
    else:
        fail("服务未通过 /api/health 自检。",
             "1) 看 RadarConsole 服务窗口的报错；2) 自动拉起的窗口在非交互会话里可能未存活，请手动双击 console\\start-console.bat。")
    log("OK", "/api/health 通过（本地回环已绕开代理）")
    try:
        body = LOCAL_OPENER.open(base + "/api/rules", timeout=5).read().decode("utf-8")
        if "rules" not in json.loads(body):
            raise ValueError("返回内容缺少 rules")
        log("OK", "免登录访问 /api/rules 通过（无需账号密码）")
    except Exception as e:
        fail("免登录自检未通过：%s" % e,
             "确认服务由包内 server.py 启动，且环境变量 AUTH_REQUIRED 未设为 1。")


def main():
    ap = argparse.ArgumentParser(description="投研雷达一键部署")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--no-launch", action="store_true", help="只部署不启动")
    ap.add_argument("--skip-venv", action="store_true", help="跳过 venv 与依赖安装")
    ap.add_argument("--mirror", action="store_true", help="使用清华 PyPI 镜像（若本机代理拦截该域名请去掉此参数）")
    args = ap.parse_args()

    log("STEP", "安装目录 = %s" % ROOT)
    precheck(args.port, args.no_launch)
    ensure_venv(args.skip_venv, args.mirror)
    ensure_config()
    launched = False
    if not args.no_launch:
        launched = launch(args.port)
    selfcheck(args.port, launched)

    print("\n" + "=" * 62)
    print("  部署完成")
    print("  访问地址 : http://127.0.0.1:%d/" % args.port)
    print("  登录     : 已取消，本机打开即用（无需账号密码）")
    print("  数据目录 : %s" % DATA)
    print("  启动     : 双击 console/start-console.bat")
    print("  停止     : 关闭服务窗口，或在窗口内按 Ctrl+C")
    print("  升级     : 只覆盖 console/ 与 scripts/，切勿覆盖 data/ 与 Materials/")
    print("  说明     : 首次打开为示例数据，运行任一任务后自动替换为当日真实数据")
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
