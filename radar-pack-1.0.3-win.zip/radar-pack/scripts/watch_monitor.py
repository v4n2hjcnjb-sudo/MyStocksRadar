# -*- coding: utf-8 -*-
"""
03-盘中自选监控｜自选股盘中走势跟踪
读取：RADAR_DATA 数据目录/config/watch_stock.csv
输出：RADAR_DATA 数据目录/watch_list/YYYY-MM-DD-自选股盘中监控.md
数据源：新浪全A快照（延时行情）+ 腾讯/新浪历史K线（量比、均线、形态）

2026-10 增强（来自 Materials/ 操盘技巧素材）：
  1. 均线结构：MA5/MA20/MA60 排列与关键位得失（素材「关键均线知识点」）
  2. 日内强弱：开盘价锚点六句口诀的近似判定（素材「黄金开盘30分钟」）
  3. 形态标记：回踩MA20止跌缩量、长阴短柱、梅开二度、三K结构
  说明：素材口诀原需开盘后30分钟分时数据，本脚本用当日开/高/低/现价做近似，
        仅作日内强弱标签，不构成买卖信号。
"""
import sys
import os
import time
import datetime as dt
import pandas as pd
import numpy as np

import ta_rules as ta
import data_common as dc

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 数据根目录：由 bootstrap/启动脚本注入 RADAR_DATA；未设置时落到用户目录，避免依赖固定盘符
RADAR_DATA = os.environ.get("RADAR_DATA") or os.path.join(os.path.expanduser("~"), "radar-data")
BASE = RADAR_DATA
WATCH_FILE = os.path.join(BASE, "config", "watch_stock.csv")
OUT_DIR = os.path.join(BASE, "watch_list")
DISCLAIMER = "\n---\n*本内容仅基于公开历史市场数据进行统计整理，不构成任何投资建议，无法预测股价未来走势，股市有风险，入市需谨慎。*"


def ensure_dirs():
    os.makedirs(OUT_DIR, exist_ok=True)


def retry(fn, *a, tries=3, delay=2, **kw):
    """带退避重试的接口调用（外网接口偶发连接失败）"""
    last = None
    for i in range(tries):
        try:
            return fn(*a, **kw)
        except Exception as e:
            last = e
            print(f"  [warn] {getattr(fn, '__name__', 'fn')} 第{i + 1}次失败：{type(e).__name__}")
            if i < tries - 1:
                time.sleep(delay * (i + 1))
    raise last


def is_trade_date(d: dt.date) -> bool:
    try:
        import akshare as ak
        cal = retry(ak.tool_trade_date_hist_sina)
        return str(d) in set(cal["trade_date"].astype(str))
    except Exception:
        return d.weekday() < 5


def fmt_num(v, nd=2):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "--"
    try:
        return f"{float(v):.{nd}f}"
    except Exception:
        return str(v)


def main():
    import akshare as ak
    ensure_dirs()
    today = dt.date.today()
    if not is_trade_date(today):
        print(f"{today} 非交易日，跳过盘中监控。")
        return
    if not os.path.exists(WATCH_FILE):
        print(f"❌ 未找到监控清单：{WATCH_FILE}")
        return

    watch = pd.read_csv(WATCH_FILE, dtype={"code": str})
    watch["code"] = watch["code"].str.zfill(6)
    codes = set(watch["code"])
    print(f"监控清单 {len(codes)} 只：{', '.join(sorted(codes))}")

    # 新浪全A快照（稳定数据源；东财快照接口当前不稳定）
    spot = retry(ak.stock_zh_a_spot)
    spot["code6"] = spot["代码"].str[-6:]
    sub = spot[spot["code6"].isin(codes)].copy()
    if sub.empty:
        print("⚠️ 快照中未匹配到清单个股（可能已退市、停牌或代码有误）。")
        return

    # 历史K线窗口拉长到 200 日：同时满足量比(近5日)、MA60、形态识别
    hist_start = (today - dt.timedelta(days=300)).strftime("%Y%m%d")
    hist_end = today.strftime("%Y%m%d")

    now = dt.datetime.now()
    in_session = (9 <= now.hour < 11 and now.minute >= 30) or 11 <= now.hour < 13 or (13 <= now.hour < 15)
    note = "盘中延时行情" if in_session else "非交易时段，以下为最新收盘/最近行情快照"
    L = [f"# 【自选股盘中监控】{today.strftime('%Y-%m-%d')}", "",
         f"> 数据时间：{now.strftime('%Y-%m-%d %H:%M:%S')}；{note}；涨跌幅绝对值超过 3% 标记【异动】。", "",
         "> 说明：数据源为新浪延时行情；量比为近似值（当日成交量 ÷ 近5日日均成交量）。",
         "> 均线结构/日内强弱参考 Materials 素材中的均线体系与开盘口诀，其中「日内强弱」用当日开高低现价近似开盘30分钟走势，仅作强弱标签，非买卖信号。", "",
         "| 代码 | 名称 | 最新价 | 涨跌幅 | 成交额(亿) | 量比(估) | 均线结构 | 日内强弱 | 形态标记 | 状态 |",
         "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]

    details = []   # 逐只明细，供「信号提示」段落使用

    for _, r in sub.iterrows():
        code = r["code6"]
        name = r["名称"]
        price = r.get("最新价", np.nan)
        pct = r.get("涨跌幅", np.nan)
        amount = r.get("成交额", 0)
        cur_vol = r.get("成交量", np.nan)
        o, h, l = r.get("今开", np.nan), r.get("最高", np.nan), r.get("最低", np.nan)

        vr = np.nan
        ma_txt, ma_flags, tags, sigs = "--", [], [], []
        try:
            hl = ta.load_kline(ak, code, hist_start, hist_end, retry=retry)
            if hl is not None and len(hl) >= 6 and pd.notna(cur_vol) and float(cur_vol) > 0:
                prev5 = float(hl["成交量"].iloc[-6:-1].mean())
                if prev5 > 0:
                    vr = float(cur_vol) / prev5
            if hl is not None and len(hl) >= 25:
                m = ta.ma_analysis(hl)
                ma_txt = m.get("state", "--")
                if m.get("pullback_ma20"):
                    tags.append("回踩MA20缩量")
                    sigs.append(("偏多", "回踩MA20止跌缩量：素材口径为洗盘特征，可作为观察点"))
                if m.get("cross_20_60"):
                    tags.append("MA20×MA60金叉")
                    sigs.append(("偏多", "MA20上穿MA60金叉，中期趋势转强"))
                if not m.get("above_ma60", True) and m.get("ma60"):
                    sigs.append(("风险", f"跌破MA60（{m['ma60']:.2f}），长期成本线失守"))
                yin = ta.long_yin_short_bar(hl)
                if yin.get("found"):
                    tags.append("长阴短柱")
                    sigs.append(("观察", yin["text"]))
                mk = ta.meikai_erdu(hl, code)
                if mk.get("score", 0) >= 3:
                    tags.append(f"梅开二度{mk['score']}/5")
                    sigs.append(("观察", mk["text"]))
                k3 = ta.three_k_bias(hl)
                if k3.get("state") in ("外包线", "内包线"):
                    tags.append(k3["state"])
                    sigs.append(("中性", k3["text"]))
        except Exception as e:
            print(f"  [warn] {code} 形态计算失败：{type(e).__name__}")

        bias_label, bias_text, bias_tone = ta.intraday_bias(o, h, l, price, pct, vr)
        if bias_tone == "risk":
            sigs.insert(0, ("风险", bias_text))
        elif bias_tone == "bull":
            sigs.insert(0, ("偏多", bias_text))
        elif bias_tone == "watch":
            sigs.insert(0, ("观察", bias_text))

        flag = "【异动】" if pd.notna(pct) and abs(pct) > 3 else ""
        amount_s = "--" if pd.isna(amount) else f"{amount / 1e8:.2f}"
        tag_s = "、".join(tags) if tags else "--"
        L.append(f"| {code} | {name} | {fmt_num(price)} | {fmt_num(pct)} | {amount_s} | {fmt_num(vr)} | {ma_txt} | {bias_label} | {tag_s} | {flag} |")
        amount_yi = None
        try:
            if amount is not None and not (isinstance(amount, float) and amount != amount):
                amount_yi = round(float(amount) / 1e8, 2)
        except Exception:
            amount_yi = None
        details.append({"code": code, "name": name, "price": price, "pct": pct, "ma": ma_txt,
                        "amount_yi": amount_yi, "flags": ma_flags, "sigs": sigs, "vr": vr})

    # ---- 信号提示 ----
    L.append("")
    L.append("## 信号提示（按素材技巧口径整理）")
    L.append("")
    hit_any = False
    for d in details:
        if not d["sigs"]:
            continue
        hit_any = True
        L.append(f"### {d['code']} {d['name']}（最新 {fmt_num(d['price'])}，{fmt_num(d['pct'])}%，量比 {fmt_num(d['vr'])}）")
        for tone, text in d["sigs"][:6]:
            if text:
                L.append(f"- **【{tone}】**{text}")
        L.append("")
    if not hit_any:
        L.append("本次无触发形态与日内强弱提示。")
        L.append("")
    L.append("> 提示说明：以上标签来自素材口诀的机械化实现，其中「日内强弱」为近似判定；形态仅为客观统计，不代表未来涨跌。")
    L.append(DISCLAIMER)

    out = os.path.join(OUT_DIR, f"{today.strftime('%Y-%m-%d')}-自选股盘中监控.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"✅ 监控报告已保存：{out}")

    # ---- 结构化输出（前端 dashboard 用）----
    wm_data = {
        "date": today.strftime("%Y-%m-%d"),
        "time": now.strftime("%Y-%m-%d %H:%M:%S"),
        "note": note,
        "stocks": [{
            "code": d["code"], "name": d["name"],
            "price": (None if (d["price"] is None or (isinstance(d["price"], float) and d["price"] != d["price"])) else round(float(d["price"]), 2)),
            "pct": (None if (d["pct"] is None or (isinstance(d["pct"], float) and d["pct"] != d["pct"])) else round(float(d["pct"]), 2)),
            "amount_yi": d.get("amount_yi"),
            "vr": (None if (d["vr"] is None or (isinstance(d["vr"], float) and d["vr"] != d["vr"])) else round(float(d["vr"]), 2)),
            "ma": d["ma"],
            "sigs": [{"tone": t, "text": tx} for t, tx in d["sigs"]],
        } for d in details],
    }
    dc.save_json(OUT_DIR, f"{today.strftime('%Y-%m-%d')}-自选股盘中监控.json", wm_data)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        print(f"❌ {__file__} 异常终止：{e}")
        raise
