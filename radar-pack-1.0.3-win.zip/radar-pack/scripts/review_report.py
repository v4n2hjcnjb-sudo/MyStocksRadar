# -*- coding: utf-8 -*-
"""
A股投研雷达 · 复盘与明日研判（自动汇总）
========================================
读取当日 4 个任务（daily_hot / trend_report / watch_monitor / stock_pool）的结构化
输出，按统一研判框架（趋势阶段、广度背离、level 由 phase 判定）汇总成
《今日复盘与明日研判》Markdown 报告。

输入：RADAR_DATA 数据目录 下各任务最新 JSON（无外部网络依赖）
输出：RADAR_DATA 数据目录\\daily_report\\<date>-今日复盘与明日研判.md
错误日志：RADAR_DATA 数据目录\\daily_report\\review_report.err.log（任一环节异常时追加）

设计原则（健壮性）：
- 单任务数据缺失/异常，不再导致整任务失败，而是降级生成并标注 ⚠️。
- 无论成功与否，都会尽力写出一份报告（退出码 0），保证任务流水线不中断。
- 真实异常信息写入 review_report.err.log，便于事后排查。
"""
import os
import sys
import json
import datetime as dt
import traceback

# Windows 下由 start-console.bat 拉起时，子进程 stdout 默认 GBK(CP936)；
# 打印 ✅/❌/⚠️ 会触发 UnicodeEncodeError，导致报告已写出却仍被判「退出码非0」。
# 与 daily_hot / trend_report / watch_monitor / stock_pool 保持一致，强制 UTF-8。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# 数据根目录：由 bootstrap/启动脚本注入 RADAR_DATA；未设置时落到用户目录，避免依赖固定盘符
RADAR_DATA = os.environ.get("RADAR_DATA") or os.path.join(os.path.expanduser("~"), "radar-data")
BASE = RADAR_DATA
OUT_DIR = os.path.join(BASE, "daily_report")
ERR_LOG = os.path.join(OUT_DIR, "review_report.err.log")


def latest_json(subdir, hint=None):
    """返回某子目录下最新的 .json 文件绝对路径（可带文件名关键字过滤）。"""
    d = os.path.join(BASE, subdir)
    if not os.path.isdir(d):
        return None
    fs = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".json")]
    if hint:
        fs = [f for f in fs if hint in os.path.basename(f)]
    if not fs:
        return None
    fs.sort(key=os.path.getmtime, reverse=True)
    return fs[0]


def load_latest(subdir, hint=None):
    p = latest_json(subdir, hint)
    if not p:
        return None, None
    try:
        return json.load(open(p, encoding="utf-8")), p
    except Exception as e:  # noqa: BLE001
        return {"_error": str(e)}, p


def fnum(v, nd=2):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "--"
    return f"{v:.{nd}f}"


def fpct(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "--"
    return f"{v:+.2f}%"


def fval(v):
    """安全解析为 float；失败返回 None（用于本应数值但可能取到 '—'/'N/A' 的字段）。"""
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _idx_line(d):
    """把 {name: {pct:...}} 字典拼成 '名称+1.23%、名称-0.45%' 形式。"""
    return "、".join(f"{k}{fpct(v.get('pct'))}" for k, v in d.items())


def _gline(lst):
    """把 [{'name':..,'pct':..}] 列表拼成 '名称+1.23%' 形式。"""
    return "、".join(f"{x.get('name')}{fpct(x.get('pct'))}" for x in (lst or []))


def _valid_pct(p):
    """过滤明显异常的点位涨跌幅（指数单日几乎不可能 >50%，如 KOSPI 抓取失败出现的 -100%）。"""
    try:
        p = float(p)
    except (TypeError, ValueError):
        return False
    return abs(p) <= 50


def _only_dicts(lst):
    """只保留列表中的 dict 元素，过滤掉 int/str/None 等脏数据（daily_hot 偶发混入）。"""
    return [x for x in (lst or []) if isinstance(x, dict)]


def _only_dict_vals(d):
    """只保留 dict 中的 dict 值，过滤掉 str/int 等脏值（index_trend_us 偶发混入）。"""
    out = {}
    for k, v in (d or {}).items():
        if isinstance(v, dict):
            out[k] = v
    return out


def _after_close(gen_str):
    """判断 daily_hot 生成时间是否晚于当日 15:00 收盘（用于标注指数/广度数据时效）。

    盘前热点常在开盘前运行，其行情实为前一交易日收盘；若 generated_at 早于当日 15:00，
    说明该快照并非最新收盘，复盘结论可能失真。
    """
    if not gen_str:
        return False
    g = None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            g = dt.datetime.strptime(gen_str, fmt)
            break
        except Exception:  # noqa: BLE001
            continue
    if g is None:
        return False
    return g >= dt.datetime(g.year, g.month, g.day, 15, 0, 0)


# 防御/红利类板块关键词（用于结构结论与机会面判定）
DEF_KW = ["银行", "煤炭", "红利", "高股息", "电力", "公路", "铁路", "公用事业", "家电"]


def _write_err_log(date, errors):
    """把本次运行捕获到的异常（含 traceback）追加写入持久化错误日志。"""
    try:
        os.makedirs(OUT_DIR, exist_ok=True)
        ts = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(ERR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n===== {ts} | date={date} | 捕获异常 {len(errors)} 处 =====\n")
            for name, exc in errors:
                f.write(f"\n--- [{name}] ---\n")
                f.write("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        return True
    except Exception:
        return False


def main():
    date = dt.date.today().strftime("%Y-%m-%d")
    L = []
    errors = []  # (环节名, Exception) 列表

    # ===== 数据读取（最外层，单独保护）=====
    dh = tr = wm = sp = None
    dh_p = tr_p = wm_p = sp_p = None
    try:
        dh, dh_p = load_latest("daily_hot", "市场热点")
        tr, tr_p = load_latest("daily_report", "盘后趋势")
        wm, wm_p = load_latest("watch_list", "自选股盘中监控")
        sp, sp_p = load_latest("stock_pool", "选股池")
    except Exception as e:  # noqa: BLE001
        errors.append(("数据读取", e))

    # 统一共享变量默认值（任意段落异常都不应导致后续 NameError）
    idx = {}
    indices = []
    up = down = zt = dt_ = None
    ratio = 0.0
    ratio_s = "?"
    mild = []
    key_notes = []
    def_sec = []
    hot = []
    weak = []
    nas_pct = None
    tr_stocks = []
    wm_stocks = []
    sel = []
    gen = ""
    mismatch = []

    # ===== 头部 =====
    try:
        date = (dh or {}).get("date") or date
        gen = (dh or {}).get("generated_at", "")
        try:
            next_d = (dt.date.fromisoformat(date) + dt.timedelta(days=1)).strftime("%m-%d")
        except Exception:  # noqa: BLE001
            next_d = ""

        missing = []
        if dh is None:
            missing.append("盘前热点(daily_hot)")
        if tr is None:
            missing.append("盘后趋势(trend_report)")
        if wm is None:
            missing.append("盘中监控(watch_monitor)")
        if sp is None:
            missing.append("自动选股(stock_pool)")

        dates = {}
        for tag, obj in (("盘前", dh), ("盘后", tr), ("盘中", wm), ("选股", sp)):
            if obj and obj.get("date"):
                dates[tag] = obj["date"]
        mismatch = [f"{k}={v}" for k, v in dates.items() if v != date]

        L.append(f"# {date} 今日复盘与明日研判")
        L.append("")
        L.append(f"> 数据基准：{date} 收盘（daily_hot / trend_report 当日产出，已含完整行情）")
        L.append("> 研判框架：趋势阶段（trend_state / classify_index）、广度背离校核、level 由趋势阶段统一判定（不再由 score 反推）的最新版本。")
        L.append("> 本复盘由 `review_report.py` 依据当日各任务结构化输出自动汇总生成。")
        if missing:
            L.append(f"> ⚠️ 部分数据源缺失，以下结论仅基于已有数据：{'、'.join(missing)}")
        if mismatch:
            L.append(f"> ⚠️ 各任务数据日期不一致（基准 {date}；{'、'.join(mismatch)}），结论可能跨日混合，建议重跑后再生。")
        L.append("")
        L.append("---")
        L.append("")
    except Exception as e:  # noqa: BLE001
        errors.append(("报告头部", e))
        L.append(f"⚠️ 报告头部生成异常：{e}")
        next_d = ""

    # ===== 一、指数与广度 =====
    try:
        L.append("## 一、指数与广度（重点：指数失真 + 广度背离）")
        L.append("")
        idx_raw = (dh or {}).get("index_trend")
        idx = idx_raw if isinstance(idx_raw, dict) else {}
        indices_raw = (dh or {}).get("indices") or []
        indices = indices_raw if isinstance(indices_raw, list) else []
        if indices:
            L.append("| 指数 | 收盘 | 涨跌幅 | 趋势阶段 |")
            L.append("|---|---|---|---|")
            for x in indices:
                if not isinstance(x, dict):
                    continue
                nm = x.get("name", "")
                last = x.get("price") or (idx.get(nm, {}) or {}).get("last")
                pct = x.get("pct")
                trd = (idx.get(nm, {}) or {}).get("trend") or {}
                ph = trd.get("label") or trd.get("phase") or ""
                L.append(f"| {nm} | {fnum(last)} | {fpct(pct)} | {ph} |")
        else:
            L.append("- 指数数据缺失。")
        L.append("")

        sent = (dh or {}).get("sentiment") or {}
        up = fval(sent.get("上涨"))
        down = fval(sent.get("下跌"))
        zt = fval(sent.get("涨停"))
        dt_ = fval(sent.get("跌停"))
        if up is not None and down is not None:
            ratio = (down / up) if up else float("inf")
            ratio_s = f"{ratio:.1f}" if up else "∞"
            L.append(f"- **广度**：全市场上涨 {fnum(up, 0)} / 下跌 {fnum(down, 0)}，涨跌比约 **1:{ratio_s}**；涨停 {fnum(zt, 0)} / 跌停 {fnum(dt_, 0)}。")

        # 广度背离：温和指数 + 广度恶劣
        mild = []
        if up is not None and down is not None and down > 0:
            for nm, v in idx.items():
                p = fval(v.get("pct"))
                if p is not None and p >= -1.0 and (down / max(up, 1)) > 2:
                    mild.append(nm)
        if mild:
            L.append(f"- ⚠️ **指数失真**：{'、'.join(mild)} 当日跌幅相对温和，但个股已呈普跌，属「指数基础偏脆弱」情形。")
        # 提炼各指数 trend.note 中的广度提示
        div_notes = []
        for nm, v in idx.items():
            note = ((v or {}).get("trend") or {}).get("note")
            if note:
                div_notes.append(note)
        key_notes = list(dict.fromkeys(n for n in div_notes if any(k in n for k in ["广度", "背离", "脆弱", "存疑", "基础"])))
        if key_notes:
            L.append(f"- ⚠️ **广度背离提示**：{'；'.join(key_notes[:2])}")
        # 数据时效透明标注：指数/广度是否来自当日收盘后快照
        if gen:
            if _after_close(gen):
                L.append(f"- **数据时效**：daily_hot 生成于 {gen}（✅ 收盘后快照，为最新收盘数据）。")
            else:
                L.append(f"- **数据时效**：daily_hot 生成于 {gen}（⚠️ 盘前/盘中快照，非最新收盘；建议收盘后重跑『盘前热点』再生成复盘）。")
        L.append("")
        L.append("---")
        L.append("")
    except Exception as e:  # noqa: BLE001
        errors.append(("一、指数与广度", e))
        L.append(f"⚠️ 该部分生成异常：{e}")
        L.append("")
        L.append("---")
        L.append("")

    # ===== 二、板块强弱结构 =====
    try:
        L.append("## 二、板块强弱结构")
        L.append("")
        hot = _only_dicts((dh or {}).get("hot_sectors"))
        weak = _only_dicts((dh or {}).get("weak_sectors"))
        L.append("**相对强势（逆势）**")
        if hot:
            for s in hot[:8]:
                ld = s.get("leaders") or []
                ld = _only_dicts(ld)
                lds = "、".join(f"{l.get('name')}{fpct(l.get('pct'))}" for l in ld) if ld else ""
                L.append(f"- {s.get('name')} {fpct(s.get('pct'))}" + (f"：领涨 {lds}" if lds else ""))
        else:
            L.append("- 暂无热点板块数据。")
        L.append("")
        L.append("**弱势方向**")
        if weak:
            for s in weak[:5]:
                L.append(f"- {s.get('name')} {fpct(s.get('pct'))}")
        else:
            L.append("- 暂无弱势板块数据。")
        L.append("")
        def_sec = [s.get("name", "") for s in hot if any(k in s.get("name", "") for k in DEF_KW)]
        if def_sec:
            L.append(f"**结构结论**：今日呈**防御（{'/'.join(def_sec[:3])}）+ 局部题材**占优，成长与高位品种承压。")
        else:
            L.append("**结构结论**：今日资金偏向局部题材与防御，需结合广度判断赚钱效应。")
        L.append("")
        L.append("---")
        L.append("")
    except Exception as e:  # noqa: BLE001
        errors.append(("二、板块强弱结构", e))
        L.append(f"⚠️ 该部分生成异常：{e}")
        L.append("")
        L.append("---")
        L.append("")

    # ===== 三、外围与催化 =====
    try:
        L.append("## 三、外围与催化")
        L.append("")
        us_raw = (dh or {}).get("index_trend_us")
        us = _only_dict_vals(us_raw if isinstance(us_raw, dict) else {})
        asia_raw = (dh or {}).get("index_trend_asia")
        asia = _only_dict_vals(asia_raw if isinstance(asia_raw, dict) else {})
        gus = (dh or {}).get("global", {}).get("us") or []
        gus = _only_dicts(gus)
        gas = (dh or {}).get("global", {}).get("asia") or []
        gas = _only_dicts(gas)
        gus_valid = [x for x in gus if _valid_pct(x.get("pct"))]
        gas_valid = [x for x in gas if _valid_pct(x.get("pct"))]
        nas_pct = None
        for x in gus_valid:
            if "纳" in str(x.get("name", "")):
                nas_pct = x.get("pct")
        if gus_valid:
            L.append(f"- **美股**：{_gline(gus_valid)}（最近一刻）。")
        elif us:
            us_v = {k: v for k, v in us.items() if _valid_pct(v.get("pct"))}
            if us_v:
                L.append(f"- **美股**：{_idx_line(us_v)}。")
        if gas_valid:
            L.append(f"- **亚太**：{_gline(gas_valid)}。")
        elif asia:
            as_v = {k: v for k, v in asia.items() if _valid_pct(v.get("pct"))}
            if as_v:
                L.append(f"- **亚太**：{_idx_line(as_v)}。")
        pol = (dh or {}).get("catalyst", {}).get("policy") or []
        fed = (dh or {}).get("macro", {}).get("fed_news") or []
        if pol or fed:
            L.append("- **宏观催化**：")
            for p in pol[:4]:
                L.append(f"  - {p.get('time', '')} {p.get('text', '')}")
            for f in fed[:3]:
                L.append(f"  - 美联储：{f.get('text', '')}")
        crude = (dh or {}).get("macro", {}).get("crude")
        if crude:
            fps = (dh or {}).get("macro", {}).get("futures_prices") or []
            fps_s = "、".join(f"{f.get('name')}{fpct(f.get('pct'))}" for f in fps)
            L.append(f"- **商品**：原油（{crude.get('name')}）{fnum(crude.get('price'))}{crude.get('unit', '')} {fpct(crude.get('pct'))}"
                     + (f"；{fps_s}" if fps_s else ""))
        L.append("")
        L.append("---")
        L.append("")
    except Exception as e:  # noqa: BLE001
        errors.append(("三、外围与催化", e))
        L.append(f"⚠️ 该部分生成异常：{e}")
        L.append("")
        L.append("---")
        L.append("")

    # ===== 四、自选股研判 =====
    try:
        L.append("## 四、自选股研判（level 由趋势阶段统一判定）")
        L.append("")
        tr_stocks = _only_dicts((tr or {}).get("stocks"))
        if tr_stocks:
            L.append("| 名称 | 评分 | 趋势阶段 | 研判 | 关键依据 |")
            L.append("|---|---|---|---|---|")
            for s in tr_stocks:
                basis = s.get("basis") or []
                basis = _only_dicts(basis)
                key = "；".join(b.get("text", "") for b in basis[:2])
                for pre in ("均线：", "量能：", "MACD："):
                    key = key.replace(pre, "")
                L.append(f"| {s.get('name')} | {fnum(s.get('score'), 0)} | {s.get('trend', '')} | {s.get('level', '')} | {key} |")
        else:
            L.append("- 盘后趋势数据缺失。")
        L.append("")
        wm_stocks = _only_dicts((wm or {}).get("stocks"))
        if wm_stocks:
            L.append(f"**盘中/收盘信号（{(wm or {}).get('time', '')}）**")
            for s in wm_stocks:
                sigs = _only_dicts(s.get("sigs"))
                sg = "；".join(x.get("text", "") for x in sigs) if sigs else "无显著信号"
                L.append(f"- {s.get('name')} {fpct(s.get('pct'))}｜{sg}")
            L.append("")
        sel = _only_dicts((sp or {}).get("selection"))
        if sel:
            L.append(f"**当日自动选股（热点优选 {len(sel)} 只）**")
            for s in sel:
                L.append(f"- {s.get('股票名称')}（{s.get('所属行业')}）评分 {fnum(s.get('综合评分'), 1)}｜{s.get('形态信号', '--')}")
            L.append("")
        L.append("> 说明：level（强势/中性/弱势）直接由趋势阶段（phase）决定：上升趋势→强势、震荡→中性、下降趋势→弱势，研判口径一致。")
        L.append("")
        L.append("---")
        L.append("")
    except Exception as e:  # noqa: BLE001
        errors.append(("四、自选股研判", e))
        L.append(f"⚠️ 该部分生成异常：{e}")
        L.append("")
        L.append("---")
        L.append("")

    # ===== 五、明日考量与策略 =====
    try:
        L.append(f"## 五、明日（{next_d}）考量与策略")
        L.append("")
        risks, observes, opps, strat = [], [], [], []
        if up is not None and down is not None:
            if ratio > 2:
                risks.append(f"今日广度恶劣（涨跌比 1:{ratio_s}），惯性下探概率偏高。")
            if mild:
                risks.append(f"{'、'.join(mild)} 表面抗跌但个股普跌，广度背离提示**补跌风险**——若该护盘力量熄火，指数可能快速向个股水位靠拢。")
        if nas_pct is not None and _valid_pct(nas_pct) and fval(nas_pct) is not None and fval(nas_pct) < 0:
            risks.append(f"美股纳指 {fpct(nas_pct)} 回调，对明日 A 股成长板块有情绪压制。")
        if not risks:
            risks.append("暂无显著系统性风险信号，但需结合广度与外围动态实时跟踪。")

        observes.append("创业板/科创能否**缩量企稳**（不再创新低、跌停家数收敛）是短线止跌信号。")
        observes.append("护盘主线（银行/红利）能否延续决定指数「面子」，但赚钱效应要看成长与题材是否回暖。")

        if def_sec:
            opps.append(f"防御：高股息/红利（{'/'.join(def_sec[:3])}）避险。")
        top_hot = sorted(hot, key=lambda s: (fval(s.get("pct")) or -999), reverse=True)[:3]
        if top_hot:
            opps.append("政策/业绩：题材主线 —— " + "、".join(f"{s.get('name')}({fpct(s.get('pct'))})" for s in top_hot) + "。")
        strong = [s.get("name") for s in tr_stocks if s.get("level") == "强势" or "上升" in str(s.get("trend", ""))]
        if strong:
            opps.append("个股：逆势抗跌且处上升通道的 " + "、".join(strong[:5]) + " 可作为中期观察。")
        if not opps:
            opps.append("暂无明确占优方向，等待广度与主线明朗。")

        strat.append("控制仓位，回避高位破位品种（MA 空头排列、跌破 MA60 类）。")
        strat.append("不追日内脉冲，等待广度改善（涨跌比回升至 1:2 以内）再提升风险敞口。")
        if mild:
            strat.append("若指数回踩关键支撑且护盘不崩，可视为阶段性低吸观察区；若护盘补跌带动指数破位，则以防守为主。")

        L.append("**风险面**")
        for i, r in enumerate(risks, 1):
            L.append(f"{i}. {r}")
        L.append("")
        L.append("**观察面**")
        for o in observes:
            L.append(f"- {o}")
        L.append("")
        L.append("**机会面（相对占优方向）**")
        for o in opps:
            L.append(f"- {o}")
        L.append("")
        L.append("**策略建议**")
        for s in strat:
            L.append(f"- {s}")
        L.append("")
        L.append("---")
        L.append("")
    except Exception as e:  # noqa: BLE001
        errors.append(("五、明日考量与策略", e))
        L.append(f"⚠️ 该部分生成异常：{e}")
        L.append("")
        L.append("---")
        L.append("")

    # ===== 六、说明 =====
    try:
        L.append("## 六、说明")
        L.append("")
        L.append(f"- 数据基准：{date}（daily_hot 生成于 {gen or '当日'}）。")
        L.append("- 本复盘由 `review_report.py` 自动汇总当日各任务结构化输出，研判口径与控制台其它视图（趋势研判、广度背离提示）保持一致。")
        if missing:
            L.append(f"- ⚠️ 以下数据源缺失，部分结论可能不完整：{'、'.join(missing)}。建议重跑对应任务后再生成。")
        if mismatch:
            L.append(f"- ⚠️ 各任务数据日期不一致（基准 {date}；{'、'.join(mismatch)}），建议全部重跑后再生成。")
        L.append("- 本内容仅基于公开历史市场数据进行统计整理，不构成任何投资建议，无法预测股价未来走势，股市有风险，入市需谨慎。")
    except Exception as e:  # noqa: BLE001
        errors.append(("六、说明", e))
        L.append(f"⚠️ 该部分生成异常：{e}")

    # ===== 降级警告汇总（若有异常）=====
    if errors:
        L.append("")
        L.append("---")
        L.append("")
        L.append("## ⚠️ 生成警告（已尽力降级生成，以下环节存在异常，结论可能不完整）")
        for name, exc in errors:
            L.append(f"- **{name}**：{exc}")

    # ===== 始终写出报告（即便有异常）=====
    md = "\n".join(L)
    try:
        os.makedirs(OUT_DIR, exist_ok=True)
        out = os.path.join(OUT_DIR, f"{date}-今日复盘与明日研判.md")
        with open(out, "w", encoding="utf-8") as f:
            f.write(md + "\n")
    except Exception as e:  # noqa: BLE001
        # 连文件都写不出，才真正失败
        errors.append(("写出报告文件", e))
        _write_err_log(date, errors)
        print(f"❌ 复盘报告写出失败：{e}")
        raise

    # 收尾打印整体保护：报告既已写出，任何 stdout 异常（GBK 编码、管道提前关闭等）
    # 都不得让整任务被判非零退出——打印只是通知，不是任务成败依据。
    try:
        if errors:
            _write_err_log(date, errors)
            print(f"⚠️ 复盘报告已降级生成（{len(errors)} 处异常，详见 {ERR_LOG}）：{out}")
        else:
            print(f"✅ 复盘报告已生成：{out}")
        print(f"   日期={date}  指数={len(idx)} 热点板块={len(hot)} 自选股={len(tr_stocks)} 选股={len(sel)}")
        if missing:
            print(f"   ⚠ 缺失：{', '.join(missing)}")
        if mismatch:
            print(f"   ⚠ 日期不一致：{', '.join(mismatch)}")
    except Exception:
        pass
    return True  # 报告已成功写出


if __name__ == "__main__":
    try:
        ok = main()
    except SystemExit:
        raise
    except Exception as e:
        # main() 仅在“报告写出失败”时才会抛出；其余异常均已在各段内部降级处理，
        # 此处兜底：真实崩溃（未写出报告）才以非零退出，便于任务引擎识别真正失败。
        try:
            traceback.print_exc()
        except Exception:
            pass
        print(f"❌ review_report 异常终止（报告未写出）：{e}")
        sys.exit(1)
    sys.exit(0 if ok else 1)
