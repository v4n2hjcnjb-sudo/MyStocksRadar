# -*- coding: utf-8 -*-
"""
01-盘前每日热点｜每日市场热点简报
数据：akshare 公开行情接口（东财 / 乐咕 / 财联社 / 巨潮 / 新浪）
输出：RADAR_DATA 数据目录/daily_hot/YYYY-MM-DD-市场热点.md
      RADAR_DATA 数据目录/daily_hot/YYYY-MM-DD-市场热点.json   （供前端 dashboard）

2026-10 增强：
  - 热点板块识别改为"全市场快照 × 行业映射"聚合（规避东财板块接口被代理拦截）
  - 新增宏观模块：美联储利率与最新消息、期货/商品最新消息与价格、原油价格
  - 新增指数趋势展示（近30日收盘 sparkline 数据）
"""
import sys
import os
import time
import datetime as dt

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

import data_common as dc
import ta_rules as ta  # 供 _enrich_trend_with_breadth 调用 ta.breadth_note（指数广度背离提示）

# 数据根目录：由 bootstrap/启动脚本注入 RADAR_DATA；未设置时落到用户目录，避免依赖固定盘符
RADAR_DATA = os.environ.get("RADAR_DATA") or os.path.join(os.path.expanduser("~"), "radar-data")
BASE = RADAR_DATA
OUT_DIR = os.path.join(BASE, "daily_hot")
DISCLAIMER = "\n---\n*本内容仅基于公开历史市场数据进行统计整理，不构成任何投资建议，无法预测股价未来走势，股市有风险，入市需谨慎。*"

IDX_NAMES = ["上证指数", "深证成指", "创业板指", "沪深300", "科创50"]
IDX_SINA = [("sh000001", "上证指数"), ("sz399001", "深证成指"), ("sz399006", "创业板指"),
            ("sh000300", "沪深300"), ("sh000688", "科创50")]
POLICY_KW = ["政策", "国务院", "发改委", "工信部", "央行", "证监会", "财政部", "规划", "补贴", "降准", "降息", "国常会"]
RISK_KW = ["风险", "警示", "退市", "处罚", "立案", "调查", "减持", "解禁"]
# 新增：美联储与期货/商品关键词
FED_KW = ["美联储", "鲍威尔", "FOMC", "联邦基金", "利率决议", "加息", "降息", "点阵图", "非农", "cpi", "通胀"]
FUTURES_KW = ["期货", "原油", "黄金", "大宗商品", "伦铜", "铜价", "COMEX", "商品期货", "螺纹", "铁矿石", "农产品", "化工"]


def ensure_dirs():
    os.makedirs(OUT_DIR, exist_ok=True)


def is_trade_date(d: dt.date) -> bool:
    try:
        import akshare as ak
        cal = ak.tool_trade_date_hist_sina()
        return str(d) in set(cal["trade_date"].astype(str))
    except Exception:
        return d.weekday() < 5


def safe(fn, *a, tries=3, delay=2, **kw):
    last = None
    for i in range(tries):
        try:
            return fn(*a, **kw)
        except Exception as e:
            last = e
            print(f"  [warn] {getattr(fn, '__name__', 'fn')} 第{i + 1}次失败：{type(e).__name__}: {e}")
            if i < tries - 1:
                time.sleep(delay * (i + 1))
    print(f"  [warn] {getattr(fn, '__name__', 'fn')} 重试{tries}次后仍失败：{last}")
    return None


def get_notice(ak, date_str):
    for fmt in (date_str.replace("-", ""), date_str):
        try:
            df = ak.stock_notice_report(symbol="全部", date=fmt)
            if df is not None and not df.empty:
                return df
        except Exception:
            continue
    return None


def _win_pct(d):
    """窗口首尾涨跌幅(%)，用于指数趋势段落（修复此前误用 len 显示"N 点"的 bug）"""
    if not d or len(d) < 2:
        return None
    try:
        return (float(d[-1]) / float(d[0]) - 1) * 100
    except Exception:
        return None


def _index_trend_line(nm, v):
    """把单个指数趋势 dict 渲染为简报一行（含研判标签 + 窗口涨跌幅 + 广度提示）"""
    t = v.get("trend") or {}
    w30, w15, w5 = _win_pct(v.get("d30")), _win_pct(v.get("d15")), _win_pct(v.get("d5"))
    wp = "；".join(f"{w}日 {x:+.2f}%" for w, x in (("30", w30), ("15", w15), ("5", w5)) if x is not None)
    parts = [f"**{nm}**：最新 {v['last']}（{v['pct']:+.2f}%）"]
    if wp:
        parts.append(wp)
    ma_bits = []
    if t.get("above_ma20") is not None:
        ma_bits.append("站上MA20" if t["above_ma20"] else "跌破MA20")
    if t.get("above_ma60") is not None:
        ma_bits.append("站上MA60" if t["above_ma60"] else "跌破MA60")
    if t.get("macd_state"):
        ma_bits.append(t["macd_state"])
    if t.get("label"):
        parts.append(f"研判 {t['label']}（{('，'.join(ma_bits))}）")
    line = "；".join(parts)
    if t.get("note"):
        line += f"　⚠ {t['note']}"
    return line


def _enrich_trend_with_breadth(trend_dict, breadth):
    """③ B档广度：把全市场广度背离提示写入各指数 trend.note（不覆盖分类）"""
    if not trend_dict or not breadth:
        return trend_dict
    out = {}
    for nm, v in trend_dict.items():
        v = dict(v)
        t = v.get("trend")
        if isinstance(t, dict):
            v["trend"] = {**t, "note": ta.breadth_note(t.get("above_ma20"), breadth)}
        out[nm] = v
    return out


def get_index_table(ak):
    for attempt in range(1, 4):
        try:
            df = ak.stock_zh_index_spot_em()
            if df is not None and not df.empty:
                df = df[df["名称"].isin(IDX_NAMES)]
                rows = []
                for _, r in df.iterrows():
                    try:
                        _p = float(r["最新价"]); _c = float(r["涨跌幅"])
                        rows.append((r["名称"], round(_p, 2), _c, "实时快照"))
                    except Exception:
                        continue
                return rows, "东财实时快照"
        except Exception as e:
            print(f"  [warn] 东财指数快照第{attempt}次失败：{type(e).__name__}")
            time.sleep(2)
    rows = []
    for symbol, name in IDX_SINA:
        try:
            df = ak.stock_zh_index_daily(symbol=symbol)
            if df is not None and len(df) >= 2:
                last = df.iloc[-1]
                prev = df.iloc[-2]
                pct = (float(last["close"]) / float(prev["close"]) - 1) * 100
                rows.append((name, round(float(last["close"]), 2), pct, "最新收盘"))
        except Exception as e:
            print(f"  [warn] 新浪指数 {symbol} 失败：{type(e).__name__}")
    return rows, "新浪日线（最新收盘）"


def get_global_markets(ak):
    import urllib.request
    us_rows, us_src = [], ""
    try:
        codes = ",".join(c for c, _ in [("gb_dji", "道琼斯"), ("gb_ixic", "纳斯达克"), ("gb_inx", "标普500")])
        req = urllib.request.Request(
            "https://hq.sinajs.cn/list=" + codes,
            headers={"User-Agent": "Mozilla/5.0", "Referer": "https://finance.sina.com.cn"})
        with urllib.request.urlopen(req, timeout=12) as r:
            txt = r.read().decode("gbk", errors="replace")
        name_map = {"gb_dji": "道琼斯", "gb_ixic": "纳斯达克", "gb_inx": "标普500"}
        for line in txt.strip().splitlines():
            body = line.split('="', 1)
            if len(body) < 2:
                continue
            code = body[0].rsplit("_", 1)[-1]
            f = body[1].strip('";').split(",")
            if len(f) < 5 or not f[1]:
                continue
            try:
                price, pct = float(f[1]), float(f[2])
            except Exception:
                continue
            us_rows.append((name_map.get(code, f[0]), price, pct, f[3].strip()))
        if us_rows:
            us_src = "新浪美股行情（最近一刻）"
    except Exception as e:
        print(f"  [warn] 新浪美股 hq 失败：{type(e).__name__}: {e}")
    if not us_rows:
        for sym, name in ((".INX", "标普500"), (".DJI", "道琼斯"), (".IXIC", "纳斯达克")):
            try:
                df = safe(ak.index_us_stock_sina, symbol=sym)
                if df is not None and len(df) >= 2:
                    last, prev = df.iloc[-1], df.iloc[-2]
                    pct = (float(last["close"]) / float(prev["close"]) - 1) * 100
                    us_rows.append((name, float(last["close"]), pct, str(last["date"])))
            except Exception as e:
                print(f"  [warn] 美股指数日线 {sym} 失败：{type(e).__name__}")
        if us_rows:
            us_src = "akshare 美股指数日线（最近收盘）"
    asia_rows = []
    for sina, nm in (("int_nikkei", "日经225"), ("b_KOSPI", "韩国KOSPI")):
        try:
            req = urllib.request.Request(
                f"https://hq.sinajs.cn/list={sina}",
                headers={"User-Agent": "Mozilla/5.0", "Referer": "https://finance.sina.com.cn"})
            with urllib.request.urlopen(req, timeout=12) as r:
                txt = r.read().decode("gbk", errors="replace")
            f = txt.split('="', 1)[1].strip().strip('";').split(",")
            if len(f) >= 4 and f[1]:
                asia_rows.append((nm, float(f[1]), float(f[3]), "新浪行情"))
        except Exception as e:
            print(f"  [warn] 新浪 {nm} 失败：{type(e).__name__}")
    return us_rows, us_src, asia_rows


def get_fed_rate(ak):
    """美联储利率（最新一期决议）"""
    try:
        df = safe(ak.macro_bank_usa_interest_rate)
        if df is not None and not df.empty:
            last = df.iloc[-1]
            return {"value": last.get("今值"), "date": str(last.get("日期")),
                    "prev": last.get("前值")}
    except Exception as e:
        print(f"  [warn] 美联储利率获取失败：{e}")
    return None


def get_crude_price(ak):
    """原油价格：上海原油期货 SC0（INE）连续合约最新收盘与当日涨跌"""
    try:
        df = safe(ak.futures_main_sina, "SC0")
        if df is not None and len(df) >= 2:
            last, prev = df.iloc[-1], df.iloc[-2]
            cur = float(last["收盘价"])
            chg = (cur / float(prev["收盘价"]) - 1) * 100
            return {"price": round(cur, 1), "pct": round(chg, 2),
                    "unit": "元/桶", "name": "上海原油(SC)", "date": str(last["日期"])}
    except Exception as e:
        print(f"  [warn] 原油价格获取失败：{e}")
    return None


def get_futures_prices(ak):
    """主要商品期货最新价格（黄金/铜/原油/螺纹/白银）"""
    specs = [("AU0", "黄金"), ("CU0", "沪铜"), ("SC0", "原油"), ("RB0", "螺纹钢"), ("AG0", "白银")]
    out = []
    for sym, nm in specs:
        try:
            df = safe(ak.futures_main_sina, sym)
            if df is not None and len(df) >= 2:
                last, prev = df.iloc[-1], df.iloc[-2]
                cur = float(last["收盘价"])
                chg = (cur / float(prev["收盘价"]) - 1) * 100
                out.append({"name": nm, "price": round(cur, 2), "pct": round(chg, 2),
                            "date": str(last["日期"])})
        except Exception as e:
            print(f"  [warn] 商品期货 {nm} 获取失败：{e}")
    return out


def get_cls_news(ak, keyword_list, limit=6):
    """财联社快讯按关键词过滤"""
    df = safe(ak.stock_info_global_cls, symbol="全部")
    if df is None or df.empty:
        return []
    items = []
    for _, r in df.iterrows():
        title = str(r.get("标题", "")).strip()
        content = str(r.get("内容", "")).strip()
        text = title + content
        if any(k.lower() in text.lower() for k in keyword_list) and len(items) < limit:
            items.append((str(r.get("发布时间", ""))[:16], title or content[:90]))
    return items


def main():
    import akshare as ak

    ensure_dirs()
    today = dt.date.today()
    if not is_trade_date(today):
        print(f"{today} 非交易日，跳过盘前简报生成。")
        return
    today_s = today.strftime("%Y-%m-%d")
    now_s = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    L = [f"# 【盘前市场热点简报】{today_s}", "",
         "> 数据来自公开接口，行情为最新可得快照，仅作客观统计整理。", ""]

    # 1 指数概览
    L.append("## 指数概览")
    idx_rows, idx_src = get_index_table(ak)
    if idx_rows:
        L.append("| 指数 | 点位 | 涨跌幅 | 数据口径 |")
        L.append("| --- | --- | --- | --- |")
        for name, price, pct, src in idx_rows:
            L.append(f"| {name} | {price:.2f} | {pct:+.2f}% | {src} |")
        L.append(f"- 数据来源：{idx_src}")
    else:
        L.append("指数行情获取失败（接口异常），请稍后重试或升级 akshare。")
    L.append("")

    # 1.5 隔夜外围市场
    L.append("## 隔夜外围市场")
    us_rows, us_src, asia_rows = get_global_markets(ak)
    L.append("### 美股（最近一刻）")
    for name, price, pct, ts in us_rows:
        L.append(f"- {name}：{price:.2f}（{pct:+.2f}%）{ts}")
    if not us_rows:
        L.append("- 美股行情获取失败（接口异常）。")
    L.append("### 亚太（日韩）")
    for name, price, pct, src in asia_rows:
        L.append(f"- {name}：{price:.2f}（{pct:+.2f}%）{src}")
    if not asia_rows:
        L.append("- 日韩行情获取失败（接口异常）。")
    L.append("")

    # 2 市场情绪
    L.append("## 市场情绪概览")
    act = safe(ak.stock_market_activity_legu)
    sentiment = None
    if act is not None and not act.empty:
        kv = dict(zip(act["item"], act["value"]))
        keys = ["上涨", "下跌", "平盘", "涨停", "跌停"]
        row = " ｜ ".join(f"{k}: {kv.get(k, '--')}" for k in keys)
        L.append(f"- 全市场：{row}")
        sentiment = {k: kv.get(k, None) for k in keys}
        L.append("- 数据来源：乐咕乐股市场活跃度（盘前为上一交易日收盘统计）")
    else:
        L.append("- 全市场涨跌家数获取失败。")
    L.append("")

    # ③ B档：全市场广度（涨少跌多=脆弱），供指数研判背离提示
    breadth = None
    if sentiment and sentiment.get("上涨") is not None and sentiment.get("下跌") is not None:
        try:
            breadth = {"up": float(sentiment["上涨"]), "down": float(sentiment["下跌"])}
        except Exception:
            breadth = None

    # 3 北向资金
    L.append("## 北向资金")
    hsgt = safe(ak.stock_hsgt_fund_flow_summary_em)
    north = None
    if hsgt is not None and not hsgt.empty:
        north_rows = hsgt[hsgt["资金方向"] == "北向"]
        if not north_rows.empty:
            latest = north_rows.iloc[-1]
            north = {"date": str(latest.get("交易日", "")),
                     "sh": latest.get("成交净买额", "--"), "sz": "--"}
            if len(north_rows) >= 2:
                north["sz"] = north_rows.iloc[-2].get("成交净买额", "--")
            L.append(f"- 最新交易日：{north['date']}")
            L.append(f"- 沪股通成交净买额：{north['sh']} 亿元；深股通：{north['sz']} 亿元")
        L.append("- 注：2024年8月18日起北向实时净买入已停止逐日披露，接口返回为 0/空属正常。")
    else:
        L.append("- 未获取到北向资金接口数据，请以交易所官方披露为准。")
    L.append("")

    # 4 热点板块（基于全市场快照 × 行业映射，规避东财板块接口）
    L.append("## 板块热点排行（行业动量）")
    spot = safe(ak.stock_zh_a_spot)
    ind_map = dc.get_industry_map(ak, today, safe=safe)
    hot = dc.get_hot_sectors(spot, ind_map, top_n=8, min_count=8) if spot is not None else []
    weak = list(reversed(hot[-5:])) if hot else []
    if hot:
        L.append("### 涨幅居前行业（热点板块）")
        L.append("| 行业 | 中位涨跌幅 | 样本数 | 领涨股 |")
        L.append("| --- | --- | --- | --- |")
        for s in hot:
            ld = "、".join(f"{x['name']}({x['pct']:+.1f}%)" for x in s["leaders"][:2]) if s["leaders"] else "--"
            L.append(f"| {s['name']} | {s['pct']:+.2f}% | {s['count']} | {ld} |")
        L.append("")
        L.append("### 跌幅居前行业")
        for s in weak:
            L.append(f"- {s['name']}：{s['pct']:+.2f}%")
    else:
        L.append("行业动量数据获取失败（接口异常或行业映射缺失）。")
    L.append("")

    # 5 宏观：美联储 / 期货 / 原油 / 指数趋势
    L.append("## 宏观与外围（美联储 · 期货 · 原油）")
    fed_rate = get_fed_rate(ak)
    fed_news = get_cls_news(ak, FED_KW, limit=6)
    fut_news = get_cls_news(ak, FUTURES_KW, limit=6)
    crude = get_crude_price(ak)
    fut_prices = get_futures_prices(ak)
    trend = dc.get_index_trend(ak, safe=safe)
    us_trend = dc.get_us_index_trend(ak, safe=safe)
    asia_trend = dc.get_asia_index_trend(ak, safe=safe)

    L.append("### 美联储")
    if fed_rate:
        L.append(f"- 联邦基金利率（最新决议）：**{fed_rate.get('value')}**　决议日：{fed_rate.get('date')}（前值 {fed_rate.get('prev')}）")
    else:
        L.append("- 美联储利率数据获取失败。")
    if fed_news:
        for t, s in fed_news:
            L.append(f"- [{t}] {s}")
    else:
        L.append("- 暂无检索到美联储相关快讯。")
    L.append("")
    L.append("### 期货与商品")
    if crude:
        L.append(f"- 原油（{crude['name']}）：**{crude['price']} {crude['unit']}**（{crude['pct']:+.2f}%）{crude['date']}")
    else:
        L.append("- 原油价格获取失败。")
    if fut_prices:
        L.append("| 商品期货 | 最新价 | 当日涨跌幅 |")
        L.append("| --- | --- | --- |")
        for f in fut_prices:
            L.append(f"| {f['name']} | {f['price']} | {f['pct']:+.2f}% |")
    if fut_news:
        L.append("**最新消息：**")
        for t, s in fut_news:
            L.append(f"- [{t}] {s}")
    else:
        L.append("- 暂无检索到期货/商品相关快讯。")
    L.append("")
    L.append("### 主要指数趋势研判（5/15/30日）")
    if trend:
        for nm, v in _enrich_trend_with_breadth(trend, breadth).items():
            L.append("- " + _index_trend_line(nm, v))
    else:
        L.append("- 主要指数趋势数据获取失败。")
    L.append("")
    L.append("### 美股三大指数趋势研判（5/15/30日）")
    if us_trend:
        for nm, v in _enrich_trend_with_breadth(us_trend, breadth).items():
            L.append("- " + _index_trend_line(nm, v))
    else:
        L.append("- 美股指数趋势数据获取失败。")
    L.append("")
    L.append("### 日韩指数趋势研判（5/15/30日）")
    if asia_trend:
        for nm, v in _enrich_trend_with_breadth(asia_trend, breadth).items():
            L.append("- " + _index_trend_line(nm, v))
    else:
        L.append("- 日韩指数趋势数据获取失败。")
    L.append("")

    # 6 催化事件与公告
    L.append("## 重要催化事件与公告")
    tele = safe(ak.stock_info_global_cls, symbol="全部")
    policy_items, risk_items = [], []
    if tele is not None and not tele.empty:
        for _, r in tele.iterrows():
            title = str(r.get("标题", "")).strip()
            content = str(r.get("内容", "")).strip()
            text = title + content
            if any(k in text for k in POLICY_KW) and len(policy_items) < 8:
                policy_items.append((str(r.get("发布时间", ""))[:16], title or content[:80]))
            if any(k in text for k in RISK_KW) and len(risk_items) < 5:
                risk_items.append((str(r.get("发布时间", ""))[:16], title or content[:80]))
    L.append("### 产业政策 / 宏观催化")
    for t, s in policy_items:
        L.append(f"- [{t}] {s}")
    if not policy_items:
        L.append("- 暂无检索到明显政策类快讯。")
    L.append("")
    L.append("### 上市公司重大公告")
    notice = get_notice(ak, today_s)
    if notice is not None and not notice.empty:
        for _, r in notice.head(8).iterrows():
            L.append(f"- {r.get('公告标题', '')}（{r.get('代码', '')}）")
    else:
        prev = today - dt.timedelta(days=1)
        while prev.weekday() >= 5:
            prev -= dt.timedelta(days=1)
        notice2 = get_notice(ak, prev.strftime("%Y-%m-%d"))
        if notice2 is not None and not notice2.empty:
            for _, r in notice2.head(8).iterrows():
                L.append(f"- {r.get('公告标题', '')}（{r.get('股票代码', '')}）")
            L.append(f"- （以上为 {prev.strftime('%Y-%m-%d')} 公告，当日公告尚未披露完）")
        else:
            L.append("- 暂未获取到当日及上一交易日公告数据。")
    L.append("")

    # 7 风险提示
    L.append("## 市场风险提示")
    if risk_items:
        for t, s in risk_items:
            L.append(f"- [{t}] {s}")
    else:
        L.append("- 留意跌幅居前板块的持续性；")
        L.append("- 关注解禁、减持等事件的个股扰动；")
        L.append("- 关注外围市场与汇率波动对风险偏好的影响。")
    L.append("")
    L.append(DISCLAIMER)

    # ---- 写出 .md ----
    out_md = os.path.join(OUT_DIR, f"{today_s}-市场热点.md")
    with open(out_md, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"✅ 简报已保存：{out_md}")

    # ---- 写出 .json（前端 dashboard 用）----
    data = {
        "date": today_s, "generated_at": now_s,
        "indices": [{"name": n, "price": p, "pct": pct, "src": s} for n, p, pct, s in idx_rows],
        "global": {"us": [{"name": n, "price": p, "pct": pc, "time": t} for n, p, pc, t in us_rows],
                   "asia": [{"name": n, "price": p, "pct": pc, "src": s} for n, p, pc, s in asia_rows],
                   "src": us_src},
        "sentiment": sentiment,
        "north": north,
        "hot_sectors": hot,
        "weak_sectors": weak,
        "macro": {"fed_rate": fed_rate, "fed_news": [{"time": t, "text": s} for t, s in fed_news],
                  "futures_news": [{"time": t, "text": s} for t, s in fut_news],
                  "crude": crude, "futures_prices": fut_prices},
        "index_trend": _enrich_trend_with_breadth(trend, breadth),
        "index_trend_us": _enrich_trend_with_breadth(us_trend, breadth),
        "index_trend_asia": _enrich_trend_with_breadth(asia_trend, breadth),
        "catalyst": {"policy": [{"time": t, "text": s} for t, s in policy_items],
                     "notice": []},
        "risk": [{"time": t, "text": s} for t, s in risk_items],
    }
    dc.save_json(OUT_DIR, f"{today_s}-市场热点.json", data)
    print("---- 预览前 20 行 ----")
    print("\n".join(L[:20]))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        print(f"❌ {__file__} 异常终止：{e}")
        raise
