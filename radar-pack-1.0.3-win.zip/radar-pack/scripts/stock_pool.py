# -*- coding: utf-8 -*-
"""
02-盘前自动选股｜自定义规则选股
规则来源：RADAR_DATA 数据目录/config/strategy_rule.md
输出：RADAR_DATA 数据目录/stock_pool/YYYY-MM-DD选股池.xlsx
  Sheet1=热点精选3只（从热点板块中按综合评分优选，不足则补齐到3只）
  Sheet2=候选池（通过全部规则的全部标的，按综合评分排序）
  Sheet3=过滤明细（含每只标的过滤原因）
  Sheet4=热点板块（当日行业动量 TOP，含领涨股）
  Sheet5=素材观察池（Materials 素材提及股票的逐只评估）
数据源：
  成分股   -> 中证指数官网（沪深300 + 中证500）
  估值    -> 东财估值接口 stock_value_em（PE(TTM)/PB/总市值，逐只）
  基本面   -> 东财业绩报表 stock_yjbb_em（ROE/净利润同比/所处行业，一次拉取）
  行情快照 -> 新浪全A快照（名称/ST 过滤）
  历史K线  -> 腾讯/新浪日线（量能/MACD/形态/周线）
  解禁    -> 东财解禁明细 stock_restricted_release_detail_em（未来30日，一次拉取）

2026-10 增强（来自 Materials/ 操盘技巧素材）：
  规则7  行业相对估值：PE(TTM) 低于同行业中位数（素材「豆包选股指令」）
  规则8  盈利质量：ROE 不低于下限且净利润同比未大幅下滑（素材「排除业绩下滑」）
  加分项 周线买点（站稳5周线/周线多头/突破平台/10周线防守）、长阴短柱、梅开二度、主升浪可量化形态
  综合评分 估值15 + 成长25 + 量能10 + MACD10 + 周线20 + 形态20 = 100
"""
import sys
import os
import json
import time
import datetime as dt
import pandas as pd
import numpy as np

import ta_rules as ta
import data_common as dc

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 数据根目录：由 bootstrap/启动脚本注入 RADAR_DATA；未设置时落到用户目录，避免依赖固定盘符
RADAR_DATA = os.environ.get("RADAR_DATA") or os.path.join(os.path.expanduser("~"), "radar-data")
BASE = RADAR_DATA
CONFIG_DIR = os.path.join(BASE, "config")
OUT_DIR = os.path.join(BASE, "stock_pool")
RULE_FILE = os.path.join(CONFIG_DIR, "strategy_rule.md")
MATERIAL_FILE = os.path.join(CONFIG_DIR, "material_stocks.csv")
DISCLAIMER = "本内容仅基于公开历史市场数据进行统计整理，不构成任何投资建议，无法预测股价未来走势，股市有风险，入市需谨慎。"

# 候选范围：hs300_zz500（沪深300+中证500，推荐省时）｜ all（全市场，耗时长）
SCOPE = "hs300_zz500"
MKT_CAP_MIN, MKT_CAP_MAX = 50e8, 500e8   # 总市值 50亿~500亿
PE_MIN, PE_MAX = 10.0, 35.0              # PE(TTM)
PB_MIN = 1.0                             # PB > 1
UNLOCK_DAYS = 30                         # 未来30日无大额解禁
UNLOCK_AMT_TH = 1e8                      # 解禁市值 > 1亿元 视为大额

# ---- 素材技巧新增条件（可自行调整/关闭）----
# 行业相对估值：不做硬筛选，只参与评分。
# 原因：市值被限定在 50~500 亿后，池内标的 PE 天然高于同行业大盘股，
#       "PE 低于行业中位数"会与市值条件形成双重惩罚（实测 73/227 因此被误杀）。
INDUSTRY_PE_BONUS = 5.0                  # 规则7（加分）：PE 低于同行业中位数，估值分上限内 +5
IND_PE_MIN_SAMPLE = 5                    # 同行业样本少于该数量时不算相对估值
ROE_MIN = 0.0                            # 规则8：ROE 下限（%），0 表示仅剔除亏损
PROFIT_GROWTH_MIN = -50.0                # 规则8：净利润同比下限（%），只排除"暴雷"，不追求零下滑
CACHE_DIR = os.path.join(BASE, "cache")  # 估值/基本面当日缓存，避免重复请求

# ---- 选股器可调开关（实时重跑时由外部参数覆盖；默认每日任务不受影响）----
_ONLY_MACD = False   # 仅保留 MACD 金叉标的
_ONLY_HOT = False    # 仅保留热点板块标的


def apply_params(params):
    """用外部传参覆盖选股阈值/开关。仅在当前进程生效（每次重跑为独立子进程），安全。"""
    if not isinstance(params, dict):
        return
    g = globals()
    # 用户传入的表单值可能为空串/非数字，用 to_f 安全解析；解析失败则保留当前默认值
    if "mkt_cap_min" in params:
        v = dc.to_f(params["mkt_cap_min"])
        if pd.notna(v):
            g["MKT_CAP_MIN"] = v * 1e8
    if "mkt_cap_max" in params:
        v = dc.to_f(params["mkt_cap_max"])
        if pd.notna(v):
            g["MKT_CAP_MAX"] = v * 1e8
    if "pe_min" in params:
        v = dc.to_f(params["pe_min"])
        if pd.notna(v):
            g["PE_MIN"] = v
    if "pe_max" in params:
        v = dc.to_f(params["pe_max"])
        if pd.notna(v):
            g["PE_MAX"] = v
    if "pb_min" in params:
        v = dc.to_f(params["pb_min"])
        if pd.notna(v):
            g["PB_MIN"] = v
    if "roe_min" in params:
        v = dc.to_f(params["roe_min"])
        if pd.notna(v):
            g["ROE_MIN"] = v
    if "profit_growth_min" in params:
        v = dc.to_f(params["profit_growth_min"])
        if pd.notna(v):
            g["PROFIT_GROWTH_MIN"] = v
    g["_ONLY_MACD"] = bool(params.get("only_macd", False))
    g["_ONLY_HOT"] = bool(params.get("only_hot", False))


def ensure_dirs():
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)


def _cache_file(name, today):
    return os.path.join(CACHE_DIR, f"{name}_{today.strftime('%Y%m%d')}.json")


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _save_json(path, obj):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except Exception as e:
        print(f"  [warn] 缓存写入失败：{e}")


def safe(fn, *a, tries=3, delay=2, **kw):
    """带退避重试的接口调用（外网接口偶发连接失败），最终失败返回 None"""
    last = None
    for i in range(tries):
        try:
            return fn(*a, **kw)
        except Exception as e:
            last = e
            print(f"  [warn] {getattr(fn, '__name__', 'fn')} 第{i + 1}次失败：{type(e).__name__}: {e}")
            if i < tries - 1:
                time.sleep(delay * (i + 1))
    print(f"  [warn] {getattr(fn, '__name__', 'fn')} 重试{tries}次后仍失败：{last}")
    return None


def pick_col(df, *names):
    for n in names:
        if n in df.columns:
            return n
    return None


def build_universe(ak):
    """构建候选股票池（成分股代码）"""
    if SCOPE == "all":
        spot = safe(ak.stock_zh_a_spot)
        if spot is None:
            return set()
        return set(spot["代码"].str[-6:])
    codes = set()
    for idx_code, idx_name in (("000300", "沪深300"), ("000905", "中证500")):
        cons = safe(ak.index_stock_cons_csindex, symbol=idx_code)
        if cons is None or cons.empty:
            print(f"  [warn] {idx_name} 成分获取失败")
            continue
        col = pick_col(cons, "成分券代码", "品种代码", "代码", "成分券代码Constituent Code")
        if col is None:
            print(f"  [warn] {idx_name} 成分列名未知：{list(cons.columns)}")
            continue
        codes.update(cons[col].astype(str).str.zfill(6))
    print(f"候选池：{len(codes)} 只（{SCOPE}）")
    return codes


def get_valuation_map(ak, codes, today=None):
    """逐只获取估值（PE_TTM/PB/总市值），返回 {code: dict}；约 0.4s/只
    当日结果会缓存到 cache/valuation_YYYYMMDD.json，重复运行只补缺失标的。"""
    codes = sorted(set(codes))
    cache_path = _cache_file("valuation", today) if today else None
    m = (_load_json(cache_path) or {}) if cache_path else {}
    if cache_path and m:
        print(f"  估值缓存命中 {len(m)} 只")

    todo = [c for c in codes if c not in m]
    total = len(todo)
    for i, code in enumerate(todo, 1):
        df = safe(ak.stock_value_em, symbol=code)
        if df is not None and not df.empty:
            last = df.iloc[-1]
            try:
                m[code] = {
                    "pe_ttm": float(last.get("PE(TTM)", np.nan) or np.nan),
                    "pb": float(last.get("市净率", np.nan) or np.nan),
                    "mcap": float(last.get("总市值", np.nan) or np.nan),
                }
            except Exception:
                pass
        if i % 100 == 0 or i == total:
            print(f"  估值获取进度：{i}/{total}")
        time.sleep(0.05)
    if cache_path and todo:
        _save_json(cache_path, m)
    print(f"估值就绪：{len([c for c in codes if c in m])}/{len(codes)} 只")
    return {c: m[c] for c in codes if c in m}


def _quarter_ends(today, n=4):
    """最近 n 个季度报告期（YYYYMMDD），从最近往前推"""
    out = []
    y, q = today.year, (today.month - 1) // 3      # q: 0..3 当前季度序号
    ends = [("0331", 0), ("0630", 1), ("0930", 2), ("1231", 3)]
    # 生成最近 4 个已过期的报告期末
    cand = []
    for yy in (y, y - 1):
        for md, _ in ends:
            d = dt.date(yy, int(md[:2]), int(md[2:]))
            if d < today:
                cand.append(d)
    cand.sort(reverse=True)
    return [d.strftime("%Y%m%d") for d in cand[:n]]


def get_fundamentals(ak, today):
    """一次性拉取业绩报表：ROE、净利润同比、所处行业。返回 (map, 报告期)，当日缓存。"""
    cache_path = _cache_file("fundamentals", today)
    cached = _load_json(cache_path)
    if cached and cached.get("map"):
        print(f"基本面缓存命中：{cached.get('period')} 报告期，{len(cached['map'])} 只")
        return cached["map"], cached.get("period")

    for d in _quarter_ends(today, 4):
        df = safe(ak.stock_yjbb_em, date=d, tries=2, delay=2)
        if df is None or len(df) < 1000:
            # 季报未披露完整（返回极少数据）时跳过，避免用残缺样本判断 ROE
            print(f"  [warn] 报告期 {d} 数据不完整（{0 if df is None else len(df)} 条），换上一期")
            continue
        code_col = pick_col(df, "股票代码", "代码")
        roe_col = pick_col(df, "净资产收益率")
        grow_col = pick_col(df, "净利润-同比增长")
        ind_col = pick_col(df, "所处行业", "行业")
        if code_col is None:
            continue
        m = {}
        for _, r in df.iterrows():
            code = str(r[code_col]).zfill(6)
            try:
                roe = float(r[roe_col]) if roe_col and pd.notna(r.get(roe_col)) else np.nan
            except Exception:
                roe = np.nan
            try:
                grow = float(r[grow_col]) if grow_col and pd.notna(r.get(grow_col)) else np.nan
            except Exception:
                grow = np.nan
            ind = str(r[ind_col]) if ind_col and pd.notna(r.get(ind_col)) else ""
            m[code] = {"roe": roe, "np_growth": grow, "industry": ind}
        print(f"基本面数据：{d} 报告期，{len(m)} 只")
        _save_json(cache_path, {"period": d, "map": m})
        return m, d
    print("  [warn] 业绩报表获取失败，规则8（ROE/净利润）本次不生效")
    return {}, None


def get_unlock_map(ak, today):
    """未来30日大额解禁映射 {code: (解禁日期, 解禁市值)}；接口失败返回 None（规则降级并提示）"""
    start = today.strftime("%Y%m%d")
    end = (today + dt.timedelta(days=UNLOCK_DAYS)).strftime("%Y%m%d")
    q = safe(ak.stock_restricted_release_detail_em, start_date=start, end_date=end)
    if q is None or q.empty:
        print("  [warn] 未来30日解禁明细为空（接口无数据），解禁规则本次不生效。")
        return None
    code_col = pick_col(q, "股票代码", "代码")
    date_col = pick_col(q, "解禁时间", "解禁日期")
    amt_col = pick_col(q, "实际解禁市值", "解禁市值")
    if code_col is None or date_col is None:
        print(f"  [warn] 解禁字段未知：{list(q.columns)}")
        return None
    m = {}
    for _, r in q.iterrows():
        try:
            d = pd.to_datetime(r[date_col]).date()
        except Exception:
            continue
        if not (today <= d <= today + dt.timedelta(days=UNLOCK_DAYS)):
            continue
        amt = dc.to_f(r[amt_col], 0.0) if amt_col else 0.0
        code = str(r[code_col]).zfill(6)
        if amt > UNLOCK_AMT_TH:
            m.setdefault(code, (d, amt))
    print(f"未来{UNLOCK_DAYS}日大额解禁个股：{len(m)} 只")
    return m


def compute_macd(close):
    ema_fast = close.ewm(span=12, adjust=False).mean()
    ema_slow = close.ewm(span=26, adjust=False).mean()
    dif = ema_fast - ema_slow
    dea = dif.ewm(span=9, adjust=False).mean()
    return dif, dea


def check_stock(code, name, val, fund, hist, unlock_map, ind_pe_median, tech=True):
    """
    按全部规则检查单只标的。
    tech=False 时只做估值/基本面初筛（用于避免对必然被过滤的标的多拉K线）。
    返回 (reasons, metrics)：reasons 为空即通过全部规则。
    """
    reasons, m = [], {}

    # 规则1：ST/*ST
    if "ST" in str(name).upper():
        reasons.append("ST/*ST股票")

    # 规则2/3：市值、PE(TTM)、PB
    if val is None:
        reasons.append("估值数据获取失败（PE/PB/市值缺失）")
    else:
        mcap, pe_ttm, pb = val["mcap"], val["pe_ttm"], val["pb"]
        m.update({"mcap": mcap, "pe": pe_ttm, "pb": pb})
        if pd.isna(mcap) or not (MKT_CAP_MIN <= mcap <= MKT_CAP_MAX):
            reasons.append(f"总市值{('--' if pd.isna(mcap) else f'{mcap/1e8:.0f}亿')}不在50~500亿")
        if pd.isna(pe_ttm) or not (PE_MIN <= pe_ttm <= PE_MAX):
            reasons.append(f"PE(TTM)={('--' if pd.isna(pe_ttm) else f'{pe_ttm:.1f}')}不在10~35")
        if pd.isna(pb) or pb <= PB_MIN:
            reasons.append(f"PB={('--' if pd.isna(pb) else f'{pb:.2f}')}未>1")
        # 规则7（加分项，不淘汰）：PE 低于同行业中位数——只记录，参与评分
        if ind_pe_median and not pd.isna(pe_ttm):
            m["ind_pe"] = ind_pe_median
            m["ind_pe_ok"] = bool(pe_ttm < ind_pe_median)

    # 规则8：ROE 与净利润同比（素材：排除业绩下滑的公司）
    f = fund or {}
    roe, grow = f.get("roe", np.nan), f.get("np_growth", np.nan)
    m.update({"roe": roe, "np_growth": grow, "industry": f.get("industry", "")})
    if fund:
        if pd.isna(roe):
            reasons.append("ROE缺失")
        elif roe <= ROE_MIN:
            reasons.append(f"ROE={roe:.1f}%（亏损），排除")
        if pd.isna(grow):
            reasons.append("净利润同比缺失")
        elif grow < PROFIT_GROWTH_MIN:
            reasons.append(f"净利润同比{grow:.0f}%（低于{PROFIT_GROWTH_MIN:.0f}%，业绩暴雷）")

    # 规则4/5：放量 + MACD金叉
    vma5 = vma20 = None
    if not tech:
        pass
    elif hist is not None and not hist.empty and len(hist) >= 25:
        vol = hist["成交量"]
        vma5 = float(vol.rolling(5).mean().iloc[-1])
        vma20 = float(vol.rolling(20).mean().iloc[-1])
        m.update({"vma5": vma5, "vma20": vma20})
        if not (vma5 > vma20):
            reasons.append(f"未放量(5日均量{vma5:.0f}≤20日均量{vma20:.0f})")
        dif, dea = compute_macd(hist["收盘"])
        golden = bool(dif.iloc[-2] <= dea.iloc[-2] and dif.iloc[-1] > dea.iloc[-1])
        m["macd_golden"] = golden
        if not golden:
            reasons.append("MACD未形成金叉(DIF未上穿DEA)")
    else:
        reasons.append("历史行情不足，无法计算量能/MACD")

    # 规则6：未来30日无大额解禁
    if unlock_map is not None and code in unlock_map:
        d, amt = unlock_map[code]
        reasons.append(f"未来30日({d})有解禁市值约{amt/1e8:.1f}亿元")

    return reasons, m


def collect_forms(hist, code):
    """素材形态信号（长阴短柱、梅开二度、三K、主升浪可量化形态、回踩MA20）"""
    forms = []
    if hist is None or hist.empty:
        return forms
    ma = ta.ma_analysis(hist)
    if ma.get("pullback_ma20"):
        forms.append({"name": "回踩MA20缩量", "weight": 8, "text": "回踩MA20止跌缩量"})
    if ma.get("cross_20_60"):
        forms.append({"name": "MA20×MA60金叉", "weight": 8, "text": "MA20上穿MA60"})
    yin = ta.long_yin_short_bar(hist)
    if yin.get("found"):
        forms.append({"name": "长阴短柱", "weight": 10 if yin.get("confirmed") else 6, "text": yin["text"]})
    mk = ta.meikai_erdu(hist, code)
    if mk.get("score", 0) >= 3:
        forms.append({"name": "梅开二度", "weight": 10 if mk.get("hit") else 6, "text": mk["text"]})
    for s in ta.main_wave_signals(hist, code):
        forms.append(s)
    return forms


def score_stock(m, weekly, forms):
    """综合评分：估值10+行业相对5 + 成长25 + 量能10 + MACD10 + 周线20 + 形态20"""
    s = 0.0
    pe = m.get("pe")
    if pe and not pd.isna(pe):
        s += 10 * (1 - min(max((pe - PE_MIN) / (PE_MAX - PE_MIN), 0), 1))
    if m.get("ind_pe_ok"):
        s += INDUSTRY_PE_BONUS
    roe = m.get("roe")
    if roe and not pd.isna(roe):
        s += min(15.0, max(0.0, roe / 10 * 15))
    grow = m.get("np_growth")
    if grow is not None and not pd.isna(grow):
        s += min(10.0, max(0.0, (grow + 20) / 5))
    v5, v20 = m.get("vma5"), m.get("vma20")
    if v5 and v20 and v20 > 0:
        s += min(10.0, max(0.0, (v5 / v20 - 1) * 20))
    if m.get("macd_golden"):
        s += 10
    s += min(20, ta.score_signals(weekly)[0])
    s += min(20, sum(f.get("weight", 0) for f in forms))
    return round(min(100.0, s), 1)


def evaluate_materials(ak, name_map, fund_map, unlock_map, ind_pe_medians, today):
    """对 Materials 素材提及的股票逐只评估，返回评估行列表"""
    if not os.path.exists(MATERIAL_FILE):
        print("  [warn] 未找到素材股票清单，跳过观察池评估")
        return []
    try:
        mat = pd.read_csv(MATERIAL_FILE, dtype={"code": str})
    except Exception as e:
        print(f"  [warn] 素材清单读取失败：{e}")
        return []
    mat["code"] = mat["code"].str.zfill(6)
    mat = mat.drop_duplicates(subset=["code"])
    print(f">> 开始评估素材提及股票 {len(mat)} 只 ...")

    start = (today - dt.timedelta(days=400)).strftime("%Y%m%d")
    end = today.strftime("%Y%m%d")
    rows = []
    for _, r in mat.iterrows():
        code = r["code"]
        name = name_map.get(code, r.get("name", ""))
        val_map = get_valuation_map(ak, [code], today)
        val = val_map.get(code)
        hist = ta.load_kline(ak, code, start, end, retry=safe)
        fund = fund_map.get(code)
        ind = (fund or {}).get("industry", "")
        med = ind_pe_medians.get(ind) if ind else None
        reasons, m = check_stock(code, name, val, fund, hist, unlock_map, med)
        weekly = ta.weekly_signals(hist) if hist is not None and not hist.empty else []
        forms = collect_forms(hist, code)

        # 结论措辞：区分"基本面风险"与"估值/市值不符"
        if not reasons:
            verdict = "符合全部选股条件，可纳入选股池"
        elif any(k in "".join(reasons) for k in ("ST", "大幅下滑", "ROE缺失", "净利润同比缺失")):
            verdict = "基本面存在风险，暂不建议纳入"
        elif val and pd.notna(m.get("mcap", np.nan)) and m["mcap"] > MKT_CAP_MAX:
            verdict = "大型权重股，超出市值上限（可作底仓长期观察，不进短中期选股池）"
        elif val and pd.notna(m.get("pe", np.nan)) and (m["pe"] > PE_MAX or m["pe"] < 0):
            verdict = "估值不在区间（偏高或亏损），等回调/盈利改善再评估"
        else:
            verdict = "暂不符合全部条件，可加入自选监控观察"

        rows.append({
            "股票代码": code, "股票名称": name,
            "素材来源": r.get("source", ""), "题材标签": r.get("tag", ""),
            "总市值(亿)": round(m["mcap"] / 1e8, 1) if m.get("mcap") and not pd.isna(m["mcap"]) else None,
            "PE(TTM)": round(m["pe"], 1) if m.get("pe") and not pd.isna(m["pe"]) else None,
            "PB": round(m["pb"], 2) if m.get("pb") and not pd.isna(m["pb"]) else None,
            "ROE(%)": round(m["roe"], 1) if m.get("roe") and not pd.isna(m["roe"]) else None,
            "净利润同比(%)": round(m["np_growth"], 1) if m.get("np_growth") and not pd.isna(m["np_growth"]) else None,
            "所属行业": ind,
            "周线信号": "、".join(s["name"] for s in weekly) or "--",
            "形态信号": "、".join(f["name"] for f in forms) or "--",
            "未通过条件": "；".join(reasons) if reasons else "全部通过",
            "评估结论": verdict,
        })
    print(f"素材观察池评估完成：{len(rows)} 只")
    return rows


def main():
    import akshare as ak
    ensure_dirs()
    today = dt.date.today()
    today_s = today.strftime("%Y-%m-%d")

    # 选股器实时重跑：从环境变量指定的参数文件载入自定义条件（默认每日任务无此变量）
    screener_mode = False
    pf = os.environ.get("SCREENER_PARAMS_FILE")
    if pf and os.path.exists(pf):
        try:
            apply_params(json.load(open(pf, encoding="utf-8")))
            screener_mode = True
            print("🔧 已载入选股器自定义参数（实时重跑模式）。")
        except Exception as e:
            print(f"  [warn] 选股器参数文件读取失败：{e}")

    rule_text = ""
    if os.path.exists(RULE_FILE):
        rule_text = open(RULE_FILE, encoding="utf-8").read()
        print("✅ 已读取选股规则文件。")

    codes = build_universe(ak)
    if not codes:
        print("❌ 候选池为空，退出。")
        return

    # 名称与ST过滤（新浪全A快照）
    spot = safe(ak.stock_zh_a_spot)
    if spot is None:
        print("❌ 全市场快照获取失败，退出。")
        return
    spot["code6"] = spot["代码"].str[-6:]
    name_map = dict(zip(spot["code6"], spot["名称"]))

    # 估值（逐只）
    print(">> 开始逐只获取估值（PE_TTM/PB/总市值），预计 5~10 分钟 ...")
    val_map = get_valuation_map(ak, codes, today)

    # 基本面（一次拉取）：ROE / 净利润同比 / 行业
    fund_map, report_period = get_fundamentals(ak, today)

    # 热点板块（基于全市场快照 × 行业映射，规避东财板块接口被代理拦截）
    ind_map = {c: v.get("industry", "") for c, v in fund_map.items() if v.get("industry")}
    hot_sectors = dc.get_hot_sectors(spot, ind_map, top_n=8, min_count=8) if fund_map else []
    hot_set = {s["name"] for s in hot_sectors}
    print(f"热点板块识别：{len(hot_sectors)} 个（{ '、'.join(s['name'] for s in hot_sectors[:5]) or '无' }）")

    # 行业中位 PE（规则7 加分项，样本>=5 才计算）
    ind_pe_medians = {}
    if fund_map:
        buckets = {}
        for code, v in val_map.items():
            ind = fund_map.get(code, {}).get("industry", "")
            pe = v.get("pe_ttm")
            if ind and pe is not None and not pd.isna(pe) and 0 < pe < 300:
                buckets.setdefault(ind, []).append(pe)
        for ind, arr in buckets.items():
            if len(arr) >= IND_PE_MIN_SAMPLE:
                ind_pe_medians[ind] = float(np.median(arr))
        print(f"行业PE中位数：{len(ind_pe_medians)} 个行业（样本≥{IND_PE_MIN_SAMPLE}）")

    # 解禁（未来30日全市场一次拉取）
    unlock_map = get_unlock_map(ak, today)

    # 过滤与精查
    start = (today - dt.timedelta(days=400)).strftime("%Y%m%d")
    end = today.strftime("%Y%m%d")
    picked, filtered = [], []

    for code in sorted(codes):
        name = name_map.get(code, "")
        val = val_map.get(code)
        # 先做估值/基本面初筛，避免对必然被过滤的标的多拉K线
        reasons, m = check_stock(code, name, val, fund_map.get(code), None, unlock_map,
                                 ind_pe_medians.get(fund_map.get(code, {}).get("industry", "")),
                                 tech=False)
        if reasons:
            filtered.append({"股票代码": code, "股票名称": name, "过滤原因": "；".join(reasons)})
            continue

        hist = ta.load_kline(ak, code, start, end, retry=safe)
        reasons, m = check_stock(code, name, val, fund_map.get(code), hist, unlock_map,
                                 ind_pe_medians.get(fund_map.get(code, {}).get("industry", "")))
        if reasons:
            filtered.append({"股票代码": code, "股票名称": name, "过滤原因": "；".join(reasons)})
            continue

        # 选股器开关：仅 MACD 金叉 / 仅热点板块
        if _ONLY_MACD and not m.get("macd_golden"):
            filtered.append({"股票代码": code, "股票名称": name, "过滤原因": "仅MACD金叉：未形成金叉"})
            continue
        if _ONLY_HOT and m.get("industry", "") not in hot_set:
            filtered.append({"股票代码": code, "股票名称": name, "过滤原因": "仅热点板块：不在当日热点板块"})
            continue

        weekly = ta.weekly_signals(hist) if hist is not None else []
        forms = collect_forms(hist, code)
        score = score_stock(m, weekly, forms)
        picked.append({
            "股票代码": code,
            "股票名称": name,
            "所属行业": m.get("industry", ""),
            "热点板块": bool(m.get("industry", "") in hot_set),
            "来源板块": m.get("industry", "") if m.get("industry", "") in hot_set else "",
            "综合评分": score,
            "总市值(亿)": round(m["mcap"] / 1e8, 1),
            "PE(TTM)": round(m["pe"], 2),
            "行业中位PE": round(ind_pe_medians.get(m.get("industry", ""), np.nan), 1)
                          if m.get("industry") in ind_pe_medians else None,
            "PB": round(m["pb"], 2),
            "ROE(%)": round(m["roe"], 1) if not pd.isna(m.get("roe", np.nan)) else None,
            "净利润同比(%)": round(m["np_growth"], 1) if not pd.isna(m.get("np_growth", np.nan)) else None,
            "5日均量/20日均量": round(m["vma5"] / m["vma20"], 2) if m.get("vma20") else None,
            "MACD状态": "金叉(DIF上穿DEA)",
            "周线信号": "、".join(s["name"] for s in weekly) or "--",
            "形态信号": "、".join(f["name"] for f in forms) or "--",
            "过滤原因": "通过全部规则",
        })
        print(f"  ✅ 入选 {code} {name}（评分 {score}）")

    picked_df = pd.DataFrame(picked)
    if not picked_df.empty:
        picked_df = picked_df.sort_values("综合评分", ascending=False)
    # 从热点板块中优先选 3 只；热点不足则用其余候选补齐到 3 只
    selection = []
    if not picked_df.empty:
        hot_pick = picked_df[picked_df["热点板块"] == True]
        others = picked_df[picked_df["热点板块"] != True]
        if not hot_pick.empty:
            selection = pd.concat([hot_pick, others]).head(3).to_dict("records")
        else:
            selection = others.head(3).to_dict("records")
    filtered_df = pd.DataFrame(filtered)

    # 素材观察池
    mat_rows = evaluate_materials(ak, name_map, fund_map, unlock_map, ind_pe_medians, today)
    mat_df = pd.DataFrame(mat_rows)

    out = os.path.join(OUT_DIR, (f"screener_{today_s}选股池.xlsx" if screener_mode else f"{today_s}选股池.xlsx"))
    hot_df = pd.DataFrame(
        [{"热点板块": s["name"], "中位涨跌幅(%)": s["pct"], "样本数": s["count"],
          "领涨股": "、".join(f"{x['name']}({x['pct']:+.1f}%)" for x in s["leaders"][:3])}
         for s in hot_sectors]) if hot_sectors else pd.DataFrame()
    sel_df = pd.DataFrame(selection) if selection else pd.DataFrame()
    with pd.ExcelWriter(out, engine="openpyxl") as w:
        sel_df.to_excel(w, sheet_name="热点精选3只", index=False)
        picked_df.to_excel(w, sheet_name="候选池", index=False)
        filtered_df.to_excel(w, sheet_name="过滤明细", index=False)
        if not hot_df.empty:
            hot_df.to_excel(w, sheet_name="热点板块", index=False)
        if not mat_df.empty:
            mat_df.to_excel(w, sheet_name="素材观察池", index=False)
    print(f"✅ 选股池已保存：{out}")
    print(f"统计：入选（候选）{len(picked)} 只 / 热点精选 {len(selection)} 只 / 过滤 {len(filtered)} 只 / 素材观察 {len(mat_rows)} 只")
    if selection:
        print("---- 热点精选 3 只 ----")
        for s in selection:
            tag = "【热点】" if s.get("热点板块") else "【备选】"
            print(f"  {tag} {s['股票代码']} {s['股票名称']}（{s.get('所属行业','')}）"
                  f"评分={s['综合评分']} PE={s['PE(TTM)']} ROE={s['ROE(%)']}")
    if picked:
        print("---- 入选清单（按评分）----")
        for p in picked_df.head(20).to_dict("records"):
            print(f"  {p['股票代码']} {p['股票名称']}（{p['所属行业']}）评分={p['综合评分']} "
                  f"PE={p['PE(TTM)']} ROE={p['ROE(%)']} 形态={p['形态信号']}")
    elif filtered:
        near = sorted(filtered, key=lambda x: x["过滤原因"].count("；"))[:5]
        print("---- 本次无标的同时满足全部条件，最接近的标的 ----")
        for x in near:
            print(f"  {x['股票代码']} {x['股票名称']}：差 {x['过滤原因']}")
    if unlock_map is None:
        print("⚠️ 注意：本次解禁数据未获取到，规则6（未来30日无大额解禁）未执行过滤。")
    if not fund_map:
        print("⚠️ 注意：本次业绩报表未获取到，规则8（ROE/净利润）未执行过滤。")
    if rule_text:
        print("---- 本次生效规则 ----")
        print(rule_text.strip())
    # ---- 结构化输出（前端 dashboard 用）----
    stock_data = {
        "date": today_s,
        "hot_sectors": hot_sectors,
        "selection": selection,
        "candidates": picked_df.to_dict("records") if not picked_df.empty else [],
        "filtered_count": len(filtered),
        "material": mat_rows,
    }
    dc.save_json(OUT_DIR, (f"screener_{today_s}选股池.json" if screener_mode else f"{today_s}选股池.json"), stock_data)
    print(DISCLAIMER)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        print(f"❌ {__file__} 异常终止：{e}")
        raise
