# -*- coding: utf-8 -*-
"""
ta_rules.py — 操盘技巧指标库（源自 Materials/ 微信素材，逐条评估后保留可代码化部分）

设计原则：
1. 只保留"口径唯一、无未来函数、可被数据验证"的规则；
2. 主观参数多的形态只输出"进度/提示"，不作为硬性买卖信号；
3. 所有函数输入统一为日线 DataFrame：列名 日期/开盘/最高/最低/收盘/成交量，按日期升序；
4. 任何数据不足或异常一律返回空结果，不抛异常（保证上游任务不中断）。

对应素材条目：
- 均线知识点（5/20/60日）      -> ma_analysis()
- 开盘黄金30分钟六句口诀        -> intraday_bias()
- 三根K线日内偏见（外包/内包）  -> three_k_bias()
- 梅开二度"二三四"口诀          -> meikai_erdu()
- 长阴短柱（价跌量缩洗盘）      -> long_yin_short_bar()
- 周线三买点 + 周线5买点        -> weekly_signals()
- 主升浪十句口诀（可量化部分）  -> main_wave_signals()
"""
import numpy as np
import pandas as pd

# 涨停阈值（用于识别首板/连板，非交易日精确判定，仅做形态识别）
LIMIT_MAIN = 9.8     # 主板
LIMIT_GEM = 19.5     # 创业板/科创板


def _f(v, default=np.nan):
    try:
        x = float(v)
        return x if np.isfinite(x) else default
    except Exception:
        return default


def limit_threshold(code: str) -> float:
    """按代码前缀返回涨停幅度阈值（仅用于形态识别）"""
    code = str(code)
    if code.startswith(("300", "301", "688", "689")):
        return LIMIT_GEM
    return LIMIT_MAIN


def load_kline(ak, code, start, end, retry=None, fresh=False):
    """历史K线多源获取（腾讯优先 / 东财补充），返回含 OHLCV 的 DataFrame（日期升序）。

    fresh=True 启用「新鲜度择优」：腾讯日线在当日收盘后常滞后一个交易日
    （T+1 才补齐当日 K 线），若直接采用会让盘后趋势误用前一交易日收盘。
    此时再取东财日线，并选用最后一根 K 线日期更新的那份。
    默认 False 保持原有单次请求行为，避免 stock_pool 全市场批量调用时请求翻倍。
    """
    def call(fn, **kw):
        return retry(fn, **kw) if retry else fn(**kw)

    prefix = "sh" if code.startswith("6") else ("sz" if code.startswith(("0", "3")) else "bj")
    frames = []

    # ① 腾讯日线（原首选，稳定但当日 K 线常滞后）
    try:
        df = call(ak.stock_zh_a_hist_tx, symbol=prefix + code, start_date=start,
                  end_date=end, adjust="qfq", tries=2, delay=1)
        if df is not None and not df.empty:
            frames.append(pd.DataFrame({
                "日期": pd.to_datetime(df["date"]),
                "开盘": df["open"].astype(float),
                "最高": df["high"].astype(float),
                "最低": df["low"].astype(float),
                "收盘": df["close"].astype(float),
                "成交量": df["volume"].astype(float),
            }))
    except Exception as e:
        print(f"  [warn] 腾讯K线 {code} 失败：{type(e).__name__}")

    # ② 需要更新数据时，补取东财日线
    try:
        end_d = pd.to_datetime(str(end), format="%Y%m%d")
    except Exception:
        end_d = None
    covered = bool(frames) and (end_d is None or frames[0]["日期"].max() >= end_d)
    if (not frames) or (fresh and not covered):
        try:
            df = call(ak.stock_zh_a_hist, symbol=code, period="daily", start_date=start,
                      end_date=end, adjust="qfq", tries=2, delay=1)
            if df is not None and not df.empty:
                frames.append(pd.DataFrame({
                    "日期": pd.to_datetime(df["日期"]),
                    "开盘": df["开盘"].astype(float),
                    "最高": df["最高"].astype(float),
                    "最低": df["最低"].astype(float),
                    "收盘": df["收盘"].astype(float),
                    "成交量": df["成交量"].astype(float),
                }))
        except Exception as e:
            print(f"  [warn] 东财K线 {code} 失败：{type(e).__name__}")

    if not frames:
        return None
    # 多源择优：最后日期最新者优先，日期相同则取数据更完整的一份
    best = max(frames, key=lambda x: (x["日期"].max(), len(x)))
    return best.sort_values("日期").reset_index(drop=True)


def with_pct(df):
    """补充 涨跌幅(%) 列"""
    d = df.copy()
    d["涨跌幅"] = d["收盘"].pct_change() * 100
    return d


# ---------------------------------------------------------------- 均线体系
def ma_analysis(df):
    """
    素材「关键均线知识点」的可执行版。
    返回 dict：排列状态、关键位得失、20上穿60金叉、回踩MA20止跌缩量（买点观察）
    """
    if df is None or len(df) < 25:
        return {}
    d = with_pct(df)
    c = d["收盘"]
    ma5, ma10, ma20 = (c.rolling(n).mean() for n in (5, 10, 20))
    ma60 = c.rolling(60).mean()
    ma20_prev = ma20.shift(1)
    ma60_prev = ma60.shift(1)

    last = float(c.iloc[-1])
    m5, m10, m20 = float(ma5.iloc[-1]), float(ma10.iloc[-1]), float(ma20.iloc[-1])
    m60 = _f(ma60.iloc[-1])

    if m5 > m10 > m20:
        state = "多头排列"
    elif m5 < m10 < m20:
        state = "空头排列"
    else:
        state = "均线交织"

    # 20日线上穿60日线（金叉）——最近5个交易日内发生
    cross_20_60 = False
    if not np.isnan(m60):
        for i in range(-5, 0):
            a, b = _f(ma20.iloc[i - 1]), _f(ma60.iloc[i - 1])
            x, y = _f(ma20.iloc[i]), _f(ma60.iloc[i])
            if not any(np.isnan(v) for v in (a, b, x, y)) and a <= b and x > y:
                cross_20_60 = True
                break

    # 回踩MA20止跌缩量（素材：回踩20日线止跌 + 缩量不破 => 主力洗盘，买入机会）
    pullback_ma20 = False
    ma20_gap = np.nan
    if not np.isnan(m20) and m20 > 0:
        ma20_gap = (last - m20) / m20 * 100
        near = abs(ma20_gap) <= 3.0
        low_touch = float(d["最低"].iloc[-1]) <= m20 * 1.01
        close_hold = last >= m20 * 0.99
        v5 = float(d["成交量"].iloc[-5:].mean())
        v20 = float(d["成交量"].iloc[-20:].mean())
        shrink = v20 > 0 and v5 < v20
        pullback_ma20 = bool(near and low_touch and close_hold and shrink)

    flags = []
    if state == "多头排列":
        flags.append("均线多头排列，上升趋势确认")
    elif state == "空头排列":
        flags.append("均线空头排列，趋势偏弱")
    if not np.isnan(m60):
        flags.append("站上MA60（长期成本线）" if last > m60 else "跌破MA60（长期成本线）")
    if last >= m5:
        flags.append("守住MA5（短线未破位）")
    else:
        flags.append("跌破MA5（短线走弱）")
    if cross_20_60:
        flags.append("MA20上穿MA60（金叉）")
    if pullback_ma20:
        flags.append("回踩MA20止跌缩量（洗盘特征）")

    return {
        "state": state, "price": last, "ma5": m5, "ma10": m10, "ma20": m20, "ma60": m60,
        "above_ma20": last > m20, "above_ma60": (not np.isnan(m60)) and last > m60,
        "cross_20_60": cross_20_60, "pullback_ma20": pullback_ma20, "ma20_gap": ma20_gap,
        "flags": flags,
        "text": f"{state}；{'站上' if last > m20 else '跌破'}MA20" + (f"；距MA20{ma20_gap:+.1f}%" if not np.isnan(ma20_gap) else ""),
    }


# ---------------------------------------------------------------- 长阴短柱
def long_yin_short_bar(df, lookback=15):
    """
    素材「长阴短柱」：回调中出现长阴线但成交量明显萎缩 => 主力未出货、洗盘概率大。
    确认条件：其后某日收盘站上该阴线开盘价。
    """
    if df is None or len(df) < 15:
        return {"found": False, "confirmed": False, "text": ""}
    d = with_pct(df)
    v5_prev = d["成交量"].shift(1).rolling(5).mean()
    n = len(d)
    for i in range(max(5, n - lookback), n):
        r = d.iloc[i]
        body = (r["开盘"] - r["收盘"]) / r["开盘"] * 100 if r["开盘"] > 0 else 0
        vref = _f(v5_prev.iloc[i])
        if _f(r["涨跌幅"]) <= -3.0 and body >= 2.5 and vref > 0 and r["成交量"] <= vref * 0.8:
            later = d.iloc[i + 1:]
            confirmed = bool((later["收盘"] > r["开盘"]).any()) if len(later) else False
            return {
                "found": True, "confirmed": confirmed,
                "date": r["日期"].strftime("%Y-%m-%d"),
                "pct": _f(r["涨跌幅"]), "vol_ratio": r["成交量"] / vref,
                "open": float(r["开盘"]),
                "text": (f"{r['日期'].strftime('%m-%d')}长阴{r['涨跌幅']:.1f}%但量能仅为前5日均量"
                         f"{r['成交量'] / vref * 100:.0f}%（价跌量缩=洗盘特征）"
                         + ("，其后已收盘站上该阴线开盘价，形态确认" if confirmed else
                            f"，待收盘站上{r['开盘']:.2f}确认")),
            }
    return {"found": False, "confirmed": False, "text": ""}


# ---------------------------------------------------------------- 梅开二度
def meikai_erdu(df, code="", lookback=60):
    """
    素材「梅开二度二三四口诀」：首板涨停（主力试盘）后缩量回调，
    二：回调不破涨停价的1/2；三：至少三连阴；四：量缩至首板量的1/4以下。
    进场：次日倍量阳包阴。
    返回五条件进度（0~5），不做买卖结论。
    """
    empty = {"hit": False, "score": 0, "total": 5, "text": "", "board_date": None}
    if df is None or len(df) < 12:
        return empty
    d = with_pct(df)
    th = limit_threshold(code)
    n = len(d)
    lo = max(1, n - lookback)
    board_idx = None
    for i in range(n - 2, lo - 1, -1):
        if _f(d["涨跌幅"].iloc[i]) >= th:
            board_idx = i
            break
    if board_idx is None or board_idx >= n - 2:
        return empty

    board_close = float(d["收盘"].iloc[board_idx])
    board_vol = float(d["成交量"].iloc[board_idx])
    post = d.iloc[board_idx + 1:]
    if post.empty:
        return empty

    score = 1  # 条件0：存在首板涨停（试盘）
    conds = ["首板涨停"]

    # 二：回调不破涨停价的一半
    if float(post["最低"].min()) >= board_close * 0.5:
        score += 1
        conds.append("回调未破涨停价1/2")

    # 三：回调段至少出现三连阴
    is_yin = (post["收盘"] < post["开盘"]).tolist()
    triple = any(is_yin[i] and is_yin[i + 1] and is_yin[i + 2] for i in range(len(is_yin) - 2))
    if triple:
        score += 1
        conds.append("出现三连阴")

    # 四：量能缩至首板量的1/4以下
    if board_vol > 0 and float(post["成交量"].min()) <= board_vol * 0.25:
        score += 1
        conds.append("量缩至首板1/4以下")

    # 进场信号：最近2日内倍量阳包阴
    entry = False
    for i in range(max(board_idx + 1, n - 2), n):
        prev = d.iloc[i - 1]
        cur = d.iloc[i]
        if (cur["收盘"] > cur["开盘"] and cur["收盘"] > prev["开盘"]
                and cur["开盘"] <= prev["收盘"] and cur["成交量"] >= prev["成交量"] * 1.8):
            entry = True
            break
    if entry:
        score += 1
        conds.append("倍量阳包阴启动")

    return {
        "hit": score >= 4, "score": score, "total": 5,
        "board_date": d["日期"].iloc[board_idx].strftime("%Y-%m-%d"),
        "cond_text": "、".join(conds),
        "text": f"首板涨停 {d['日期'].iloc[board_idx].strftime('%m-%d')}，形态进度 {score}/5（{'、'.join(conds)}）",
    }


# ---------------------------------------------------------------- 三K偏见
def three_k_bias(df):
    """素材「三根K线锁定日内偏见」：外包线=多空分歧加大，内包线=缩量蓄势"""
    if df is None or len(df) < 4:
        return {"state": "", "text": ""}
    d = df
    k1, k2, k3 = d.iloc[-3], d.iloc[-2], d.iloc[-1]
    o2, c2 = float(k2["开盘"]), float(k2["收盘"])
    hi2, lo2 = float(k2["最高"]), float(k2["最低"])
    hi3, lo3 = float(k3["最高"]), float(k3["最低"])

    if hi3 > hi2 and lo3 < lo2:
        return {"state": "外包线", "text": "外包K线：多空分歧加大、波动放大，方向不明（素材口径：偏谨慎）"}
    if hi3 <= hi2 and lo3 >= lo2:
        v = float(k3["成交量"])
        vprev = float(k2["成交量"])
        shrink = vprev > 0 and v < vprev
        return {"state": "内包线", "text": f"内包K线：{'缩量' if shrink else '未缩量'}蓄势，等待方向选择"}
    body2_top, body2_bot = max(o2, c2), min(o2, c2)
    if body2_bot > float(k1["最高"]):
        return {"state": "多头结构", "text": "二号K线实体站上一号K线最高价，短线偏多结构"}
    if body2_top < float(k1["最低"]):
        return {"state": "空头结构", "text": "二号K线实体跌破一号K线最低价，短线偏空结构"}
    return {"state": "无明确结构", "text": ""}


# ---------------------------------------------------------------- 周线信号
def weekly_signals(df):
    """素材「周线三买点」+「周线5买点」的可量化部分，返回命中的信号列表"""
    if df is None or len(df) < 80:
        return []
    try:
        w = (df.set_index("日期")
               .resample("W-FRI")
               .agg({"开盘": "first", "最高": "max", "最低": "min", "收盘": "last", "成交量": "sum"})
               .dropna())
    except Exception:
        return []
    if len(w) < 22:
        return []
    c = w["收盘"]
    ma5w, ma10w, ma20w = c.rolling(5).mean(), c.rolling(10).mean(), c.rolling(20).mean()
    v10w = w["成交量"].rolling(10).mean()

    last = float(c.iloc[-1])
    out = []

    # 1. 站稳五周线：最近3周收盘均在5周线上
    if not np.isnan(ma5w.iloc[-1]) and all(_f(c.iloc[i]) > _f(ma5w.iloc[i]) for i in (-3, -2, -1)):
        out.append({"name": "站稳5周线", "weight": 10, "text": "连续3周收盘站上5周均线（波段上车信号）"})

    # 2. 5周/20周线多头且5周线拐头向上
    if (_f(ma5w.iloc[-1]) > _f(ma20w.iloc[-1]) and _f(ma5w.iloc[-1]) > _f(ma5w.iloc[-5])) \
            and not np.isnan(ma20w.iloc[-1]):
        out.append({"name": "周线多头排列", "weight": 10, "text": "5周线上穿并高于20周线，且5周线拐头向上"})

    # 3. 突破前四周最高价（震荡平台突破）
    if len(w) >= 6:
        prior_high = float(w["最高"].iloc[-5:-1].max())
        if last > prior_high:
            out.append({"name": "周线突破平台", "weight": 10, "text": f"本周收盘突破前4周最高价 {prior_high:.2f}"})

    # 4. 10周线防守：最近4周收盘均在10周线上
    if not np.isnan(ma10w.iloc[-1]) and all(_f(c.iloc[i]) > _f(ma10w.iloc[i]) for i in (-4, -3, -2, -1)):
        out.append({"name": "10周线防守", "weight": 10, "text": "连续4周收盘站稳10周线（主力横盘建仓特征）"})

    # 5. 破阴起爆：上周大阴线被本周大阳线反包，且量能放大3倍
    if len(w) >= 12:
        p, cur = w.iloc[-2], w.iloc[-1]
        p_pct = (float(p["收盘"]) / float(w["收盘"].iloc[-3]) - 1) * 100
        vref = _f(v10w.iloc[-2])
        if (p_pct <= -7 and float(cur["收盘"]) > float(cur["开盘"])
                and float(cur["收盘"]) > float(p["开盘"])
                and vref > 0 and float(cur["成交量"]) >= vref * 3):
            out.append({"name": "破阴起爆", "weight": 15, "text": "周线大阴被大阳反包且量能达均量3倍（强启动信号）"})

    return out


# ---------------------------------------------------------------- 主升浪形态
def main_wave_signals(df, code=""):
    """素材「主升浪十句口诀」中可量化的部分，只输出形态标记，不做买卖结论"""
    if df is None or len(df) < 65:
        return []
    d = with_pct(df)
    out = []
    c, o = d["收盘"], d["开盘"]
    h, l, v = d["最高"], d["最低"], d["成交量"]
    last, last_o = float(c.iloc[-1]), float(o.iloc[-1])
    vma5 = float(v.iloc[-5:].mean())
    vma20 = float(v.iloc[-20:].mean())
    hi60, lo60 = float(h.iloc[-60:].max()), float(l.iloc[-60:].min())

    # 低位突然放量（主力点火）
    pos = (last - lo60) / (hi60 - lo60) if hi60 > lo60 else 1
    if pos <= 0.35 and vma20 > 0 and float(v.iloc[-1]) >= vma20 * 2 and last > last_o:
        out.append({"name": "低位放量", "weight": 10, "text": f"处于60日区间低位（{pos * 100:.0f}%分位）且放量收阳，疑似资金介入"})

    # 连续下跌但量能递增，阳线反包
    seg = d.iloc[-6:-1]
    if len(seg) == 5 and (seg["收盘"] < seg["开盘"]).sum() >= 3 and last > last_o \
            and last > float(seg["开盘"].iloc[-1]):
        out.append({"name": "跌后反包", "weight": 10, "text": "前期连续收阴后今日阳线反包前一日开盘价"})

    # 涨停连板
    th = limit_threshold(code)
    if _f(d["涨跌幅"].iloc[-1]) >= th and len(d) > 1 and _f(d["涨跌幅"].iloc[-2]) >= th:
        out.append({"name": "连板强势", "weight": 15, "text": "连续两个涨停，短线强势"})

    # 连续阳线（≥7根）
    yin_yang = (c.iloc[-8:] > o.iloc[-8:]).tolist()
    if len(yin_yang) == 8 and sum(yin_yang) >= 7:
        out.append({"name": "连续阳线", "weight": 10, "text": f"近8个交易日中{sum(yin_yang)}根阳线，主力态度明确"})

    # 长下影线（针形探底）
    rng = float(h.iloc[-1]) - float(l.iloc[-1])
    lower_shadow = min(last, last_o) - float(l.iloc[-1])
    body = abs(last - last_o)
    if rng > 0 and lower_shadow / rng >= 0.5 and lower_shadow >= body * 2:
        out.append({"name": "长下影探底", "weight": 10, "text": "长下影线，下方有承接（素材称黄金坑）"})

    # K线包住均线后放量炸开
    if len(d) >= 21:
        ma5 = c.rolling(5).mean().iloc[-2]
        ma10 = c.rolling(10).mean().iloc[-2]
        ma20 = c.rolling(20).mean().iloc[-2]
        prev_h, prev_l = float(h.iloc[-2]), float(l.iloc[-2])
        if all(prev_l <= _f(m) <= prev_h for m in (ma5, ma10, ma20)) \
                and last > last_o and vma5 > 0 and float(v.iloc[-1]) >= vma5 * 1.5:
            out.append({"name": "突破均线束", "weight": 15, "text": "均线粘合后放量长阳突破（素材称大行情启动）"})

    return out


# ---------------------------------------------------------------- 盘中口诀
def intraday_bias(open_, high, low, price, pct, vol_ratio=np.nan):
    """
    素材「黄金开盘30分钟六句口诀」的近似判定（用当日 开/高/低/现价 替代分时）。
    修复：原 `p>o and h>p` 分支中 h>p 几乎恒真，导致大涨股被误判为中性观望；
    现改为以「收盘相对开盘的强弱 + 涨跌幅分级」为主，并正确识别盘中是否触及/冲过开盘价。
    返回 (标签, 提示, 语气)  语气: risk / watch / bull / neutral
    """
    o, h, l, p = _f(open_), _f(high), _f(low), _f(price)
    pc, vr = _f(pct), _f(vol_ratio)
    if any(np.isnan(x) for x in (o, h, l, p)) or o <= 0:
        return "数据不足", "", "neutral"

    above = p > o
    below = p < o
    touched_open = l <= o * 1.005       # 盘中最低曾触及/跌破开盘价
    pushed_above = h >= o * 1.005       # 盘中最高曾冲过开盘价

    if above:
        if pc >= 3:
            return "强势上涨", "收盘显著高于开盘且涨幅居前，日内资金主动做多（素材口径：强）", "bull"
        if pc >= 0.5:
            if touched_open:
                return "震荡上行回踩不破", "贴开盘价上方运行、盘中回踩未有效跌破，偏多（素材口径：慢涨不破→留意）", "bull"
            return "稳步上行不破开盘价", "贴开盘价上方运行，疑似资金吸筹（素材口径：慢涨不破均线→留意）", "bull"
        if touched_open:
            return "下探后收复开盘价", "盘中下探后拉回收复开盘价，有承接（素材口径：重点盯）", "watch"
        return "横盘微涨", "围绕开盘价窄幅波动、略有走高，方向待确认", "neutral"
    if below:
        if pc <= -3:
            return "弱势下跌", "收盘明显低于开盘价，日内资金主动卖出（素材口径：弱）", "risk"
        if pushed_above:
            return "冲高回落跌破开盘价", "盘中曾冲高至开盘价上方但回落至下方，上攻乏力（素材口径：先冲后落→防继续下探）", "risk"
        if touched_open:
            return "下探后未能收复开盘价", "反弹无力、仍在开盘价下方，日内偏弱（素材口径：谨慎）", "risk"
        return "弱势震荡", "收盘略低于开盘价、波幅有限，偏弱观望", "watch"
    return "日内持平", "", "neutral"


def score_signals(signals):
    """把信号列表（含 weight）汇总为总分，并返回权重前几的名称"""
    if not signals:
        return 0, ""
    total = sum(s.get("weight", 0) for s in signals)
    names = "、".join(s["name"] for s in signals)
    return total, names


# ---------------------------------------------------------------- 统一趋势状态
def _macd_series(close, fast=12, slow=26, signal=9):
    """由收盘价序列计算 MACD，返回 (dif, dea, hist) 三个 Series"""
    c = pd.Series(close, dtype="float64") if not isinstance(close, pd.Series) else close
    ema_fast = c.ewm(span=fast, adjust=False).mean()
    ema_slow = c.ewm(span=slow, adjust=False).mean()
    dif = ema_fast - ema_slow
    dea = dif.ewm(span=signal, adjust=False).mean()
    return dif, dea, (dif - dea) * 2


# 5 态相位 -> 中文展示标签（个股 / 指数通用，保证全系统口径一致）
_PHASE_LABEL = {
    "up": "上升趋势",
    "up_weak": "上升动能减弱",
    "range": "震荡",
    "down_weak": "下降趋势（弱势整理）",
    "down": "下降趋势",
}


def trend_state(close):
    """
    由收盘价序列判定趋势状态（个股 / 指数通用，统一口径）。
    返回 dict：phase / label / valid / c / ma5,10,20,60 / above_ma20,above_ma60 /
               ma_multi / golden / death / d / e / macd_state。
    判定树（④ 纳入 MA60 长期分水岭；⑦ 多空分支对称）：
      up      : MA5>10>20 且 收盘>MA20 且 DIF>DEA(金叉)
      down    : MA5<10<20 且 收盘<MA20 且 DIF<DEA(死叉)
      up_weak : MA多头排列且收盘>MA20（MACD未金叉，或 未站稳MA60）
      down_weak: MA空头排列且收盘<MA20（或 守住MA60）
      range   : 其余
    """
    res = {"valid": False, "phase": "unknown", "label": "数据不足", "c": np.nan,
           "ma5": np.nan, "ma10": np.nan, "ma20": np.nan, "ma60": np.nan,
           "above_ma20": None, "above_ma60": None, "ma_multi": "",
           "golden": False, "death": False, "d": np.nan, "e": np.nan, "macd_state": ""}
    c = pd.Series(close, dtype="float64") if not isinstance(close, pd.Series) else close
    if len(c) < 25:
        return res
    ma5 = float(c.rolling(5).mean().iloc[-1])
    ma10 = float(c.rolling(10).mean().iloc[-1])
    ma20 = float(c.rolling(20).mean().iloc[-1])
    m60 = float(c.rolling(60).mean().iloc[-1]) if len(c) >= 60 else np.nan
    last = float(c.iloc[-1])
    dif, dea, _ = _macd_series(c)
    d, e = float(dif.iloc[-1]), float(dea.iloc[-1])
    golden = float(dif.iloc[-2]) <= float(dea.iloc[-2]) and d > e
    death = float(dif.iloc[-2]) >= float(dea.iloc[-2]) and d < e

    if ma5 > ma10 > ma20:
        ma_multi = "多头排列"
    elif ma5 < ma10 < ma20:
        ma_multi = "空头排列"
    else:
        ma_multi = "均线交织"

    if ma5 > ma10 > ma20 and last > ma20 and d > e:
        phase = "up"
    elif ma5 < ma10 < ma20 and last < ma20 and d < e:
        phase = "down"
    elif ma5 > ma10 > ma20 and last > ma20:
        phase = "up_weak"
    elif ma5 < ma10 < ma20 and last < ma20:
        phase = "down_weak"
    else:
        phase = "range"
    # ④ MA60 长期分水岭微调：上升但未站稳长期成本线→降级为动能减弱；下降但守住→升级
    if phase == "up" and (np.isnan(m60) or last < m60):
        phase = "up_weak"
    if phase == "down" and (not np.isnan(m60)) and last > m60:
        phase = "down_weak"

    macd_parts = []
    if golden:
        macd_parts.append("金叉")
    if death:
        macd_parts.append("死叉")
    macd_parts.append("零轴上方" if d > 0 else "零轴下方")

    res.update({"valid": True, "phase": phase, "label": _PHASE_LABEL[phase],
                "c": last, "ma5": ma5, "ma10": ma10, "ma20": ma20, "ma60": m60,
                "above_ma20": last > ma20, "above_ma60": (not np.isnan(m60)) and last > m60,
                "ma_multi": ma_multi, "golden": golden, "death": death,
                "d": d, "e": e, "macd_state": "、".join(macd_parts)})
    return res


def classify_index(closes, breadth=None):
    """
    指数趋势研判（③ 核心）：复用 trend_state 给出统一趋势标签。
    breadth={'up':x,'down':y} 用于广度背离提示（指数偏强但涨少跌多=脆弱）。
    返回 dict：label / phase / above_ma20 / above_ma60 / ma_multi / macd_state / note
    """
    st = trend_state(closes)
    if not st["valid"]:
        return {"label": "数据不足", "phase": "unknown", "above_ma20": None,
                "above_ma60": None, "ma_multi": "", "macd_state": "", "note": ""}
    note = breadth_note(st["above_ma20"], breadth) if breadth else ""
    return {"label": st["label"], "phase": st["phase"],
            "above_ma20": st["above_ma20"], "above_ma60": st["above_ma60"],
            "ma_multi": st["ma_multi"], "macd_state": st["macd_state"], "note": note}


def breadth_note(above_ma20, breadth):
    """全市场广度背离提示：指数偏强但涨少跌多 -> 脆弱（③ B 档广度）"""
    if not breadth or not isinstance(breadth, dict):
        return ""
    up, down = _f(breadth.get("up")), _f(breadth.get("down"))
    if np.isnan(up) or np.isnan(down) or up >= down:
        return ""
    return ("指数站上MA20但全市场涨少跌多，广度背离，上涨基础偏脆弱"
            if above_ma20 else "全市场涨少跌多，广度偏弱，反弹持续性存疑")
