# -*- coding: utf-8 -*-
"""
data_common.py · 投研雷达共享数据工具
- 行业映射（code -> 所处行业），用于"热点板块"计算
- 热点板块识别：基于全市场快照涨跌幅按行业聚合（中位涨跌幅），
  不依赖东财板块接口（该接口在当前环境被代理拦截）
- 结构化 JSON 输出（供前端 dashboard 渲染）
"""
import os
import json
import datetime as dt
import pandas as pd
import numpy as np

CACHE_DIR = os.path.join(os.environ.get("RADAR_DATA") or os.path.join(os.path.expanduser("~"), "radar-data"), "cache")


def _cache_file(name, today):
    os.makedirs(CACHE_DIR, exist_ok=True)
    return os.path.join(CACHE_DIR, f"{name}_{today.strftime('%Y%m%d')}.json")


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _save_json(path, obj):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except Exception as e:
        print(f"  [warn] JSON 缓存写入失败：{e}")


def _sanitize(o):
    """递归把 NaN/inf 转成 None，保证 JSON 可序列化"""
    if isinstance(o, dict):
        return {k: _sanitize(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_sanitize(v) for v in o]
    if isinstance(o, float):
        if o != o or o in (float("inf"), float("-inf")):
            return None
        return o
    return o


def to_f(v, default=np.nan):
    """把任意值安全解析为 float；失败（None/空串/非数字字符串如 '—'/'N/A'）返回 default。
    与 float() 不同：0.0 正常返回，不会误判为缺失。"""
    if v is None:
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def fval(v):
    """安全转 float，失败返回 None（用于本应数值但可能取到 '—'/'N/A' 的字段）。"""
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def fnum(v, nd=2):
    try:
        return f"{float(v):.{nd}f}"
    except (TypeError, ValueError):
        return "--"


def fpct(v):
    try:
        return f"{float(v):+.2f}%"
    except (TypeError, ValueError):
        return "--"


def save_json(out_dir, name, obj):
    """把结构化结果写入 out_dir/name.json（覆盖同目录同名旧文件，保持最新一份）"""
    try:
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(_sanitize(obj), f, ensure_ascii=False, indent=2)
        print(f"✅ 结构化数据已保存：{path}")
        return path
    except Exception as e:
        print(f"  [warn] JSON 写出失败：{e}")
        return None


def get_industry_map(ak, today, safe=None):
    """返回 {code(6位): 行业}；优先用当日缓存，否则拉取业绩报表提取行业。"""
    cache = _cache_file("industry", today)
    c = _load_json(cache)
    if c:
        print(f"  行业映射缓存命中：{len(c)} 只")
        return c

    def yjbb(d):
        return ak.stock_yjbb_em(date=d)

    # 复用与 stock_pool 一致的季度回退逻辑
    y, q = today.year, (today.month - 1) // 3
    ends = [("0331", 0), ("0630", 1), ("0930", 2), ("1231", 3)]
    cand = []
    for yy in (y, y - 1):
        for md, _ in ends:
            d = dt.date(yy, int(md[:2]), int(md[2:]))
            if d < today:
                cand.append(d)
    cand.sort(reverse=True)

    m = {}
    for d in cand[:4]:
        try:
            df = (safe or (lambda fn, *a, **k: fn(*a, **k)))(yjbb, d.strftime("%Y%m%d"))
        except Exception as e:
            print(f"  [warn] 业绩报表 {d} 失败：{e}")
            continue
        if df is None or len(df) < 1000:
            continue
        code_col = "股票代码" if "股票代码" in df.columns else "代码"
        ind_col = "所处行业" if "所处行业" in df.columns else ("行业" if "行业" in df.columns else None)
        if ind_col is None:
            continue
        for _, r in df.iterrows():
            code = str(r[code_col]).zfill(6)
            ind = str(r[ind_col]) if pd.notna(r[ind_col]) else ""
            if ind:
                m[code] = ind
        if m:
            _save_json(cache, m)
            print(f"  行业映射：{d} 报告期，{len(m)} 只")
            return m
    print("  [warn] 行业映射获取失败，热点板块识别降级。")
    return m


def get_hot_sectors(spot_df, ind_map, top_n=8, min_count=8):
    """
    基于全市场快照按行业聚合，识别热点板块。
    spot_df: 含 代码/涨跌幅 列的快照（如 stock_zh_a_spot）
    ind_map: {code: 行业}
    返回 [{name, pct(中位涨跌幅), count, leaders:[{code,name,pct}]}, ...] 按 pct 降序
    """
    if spot_df is None or spot_df.empty or not ind_map:
        return []
    df = spot_df.copy()
    # akshare 新版快照的「代码」带市场前缀（sh/sz/bj），需提取末尾 6 位数字用于行业映射
    df["code6"] = df["代码"].astype(str).str.extract(r"(\d{6})", expand=False) if "代码" in df.columns else df.get("code6")
    ind_col = "涨跌幅" if "涨跌幅" in df.columns else None
    if ind_col is None or "code6" not in df.columns:
        return []
    df["_ind"] = df["code6"].map(ind_map)
    df = df[df["_ind"].notna()]
    df[ind_col] = pd.to_numeric(df[ind_col], errors="coerce")
    df = df.dropna(subset=[ind_col])
    rows = []
    for ind, g in df.groupby("_ind"):
        g = g.copy()
        med = float(g[ind_col].median())
        cnt = len(g)
        if cnt < min_count:
            continue
        g = g.sort_values(ind_col, ascending=False)
        leaders = []
        for _, r in g.head(3).iterrows():
            nm = r.get("名称", "")
            leaders.append({
                "code": r["code6"], "name": ("" if pd.isna(nm) else str(nm)),
                "pct": round(float(r[ind_col]), 2),
            })
        rows.append({"name": ind, "pct": round(med, 2), "count": int(cnt), "leaders": leaders})
    rows.sort(key=lambda x: -x["pct"])
    return rows[:top_n]


def _trend_windows(closes, windows=(5, 15, 30)):
    """从收盘价序列截取各窗口（旧→新），返回 {d5,d15,d30}"""
    closes = [float(x) for x in closes]
    out = {}
    for w in windows:
        seg = closes[-w:]
        out[f"d{w}"] = [round(x, 2) for x in seg]
    return out


def _trend_for(ak, safe, symbol, name, fetcher, windows=(5, 15, 30)):
    """通用：取某指数日线收盘，输出 last/pct + 5/15/30 日窗口（用于趋势 sparkline）。"""
    try:
        df = safe(fetcher, symbol)
        if df is None or len(df) < 2:
            return None
        closes = df["close"].tolist()
        last = float(closes[-1]); prev = float(closes[-2])
        res = {"last": round(last, 2), "pct": round((last / prev - 1) * 100, 2)}
        res.update(_trend_windows(closes, windows))
        try:
            from ta_rules import classify_index
            res["trend"] = classify_index(closes)
        except Exception as e:
            print(f"  [warn] 指数趋势研判 {name} 失败：{e}")
            res["trend"] = None
        return res
    except Exception as e:
        print(f"  [warn] 指数趋势 {name} 失败：{e}")
        return None


def get_index_trend(ak, safe=None):
    """主要指数近 5/15/30 日收盘（趋势展示）"""
    safe = safe or (lambda fn, *a, **k: fn(*a, **k))
    syms = [("sh000001", "上证指数"), ("sz399001", "深证成指"),
            ("sz399006", "创业板指"), ("sh000300", "沪深300"), ("sh000688", "科创50")]
    out = {}
    for sym, name in syms:
        r = _trend_for(ak, safe, sym, name, lambda s: ak.stock_zh_index_daily(symbol=s))
        if r:
            out[name] = r
    return out


def get_us_index_trend(ak, safe=None):
    """美股三大指数（道琼斯 / 纳斯达克 / 标普500）近 5/15/30 日趋势"""
    safe = safe or (lambda fn, *a, **k: fn(*a, **k))
    syms = [(".DJI", "道琼斯"), (".IXIC", "纳斯达克"), (".INX", "标普500")]
    out = {}
    for sym, name in syms:
        r = _trend_for(ak, safe, sym, name, lambda s: ak.index_us_stock_sina(symbol=s))
        if r:
            out[name] = r
    return out


def get_asia_index_trend(ak, safe=None):
    """亚太（日韩）指数近 5/15/30 日趋势：日经225、韩国KOSPI"""
    safe = safe or (lambda fn, *a, **k: fn(*a, **k))
    syms = [("日经225指数", "日经225"), ("首尔综合指数", "韩国KOSPI")]
    out = {}
    for sym, name in syms:
        r = _trend_for(ak, safe, sym, name, lambda s: ak.index_global_hist_sina(symbol=s))
        if r:
            out[name] = r
    return out
