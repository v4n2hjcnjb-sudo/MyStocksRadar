# -*- coding: utf-8 -*-
"""
04-收盘趋势研判｜自选股盘后趋势自动判断
读取：RADAR_DATA 数据目录/config/watch_stock.csv
输出：RADAR_DATA 数据目录/daily_report/YYYY-MM-DD盘后趋势.md
指标：MA5/10/20/60、量能(5日 vs 20日均量)、MACD(12,26,9)

2026-10 增强（来自 Materials/ 操盘技巧素材）：
  - 周线信号：站稳5周线 / 5-20周线多头 / 突破前4周高点 / 10周线防守 / 破阴起爆
  - 日线形态：回踩MA20止跌缩量、长阴短柱、梅开二度、三K结构、主升浪可量化形态
  - 综合评分：趋势基础分 + 周线/形态信号加权，输出强势排序
"""
import sys
import os
import time
import datetime as dt
import pandas as pd
import numpy as np

import ta_rules as ta
import data_common as dc

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 数据根目录：由 bootstrap/启动脚本注入 RADAR_DATA；未设置时落到用户目录，避免依赖固定盘符
RADAR_DATA = os.environ.get("RADAR_DATA") or os.path.join(os.path.expanduser("~"), "radar-data")
BASE = RADAR_DATA
WATCH_FILE = os.path.join(BASE, "config", "watch_stock.csv")
OUT_DIR = os.path.join(BASE, "daily_report")
DISCLAIMER = "\n---\n*本内容仅基于公开历史市场数据进行统计整理，不构成任何投资建议，无法预测股价未来走势，股市有风险，入市需谨慎。*"

# ⑤ 原“上升趋势（短期整理）”更名为“上升动能减弱”，更贴合 MACD 死叉/未站稳MA60 的含义
TREND_SCORE = {"上升趋势": 40, "上升动能减弱": 30, "震荡": 20,
               "下降趋势（弱势整理）": 10, "下降趋势": 0}


def ensure_dirs():
    os.makedirs(OUT_DIR, exist_ok=True)


def retry(fn, *a, tries=3, delay=2, **kw):
    """带退避重试的接口调用（外网接口偶发连接失败）"""
    last = None
    for i in range(tries):
        try:
            return fn(*a, **kw)
        except Exception as e:
            last = e
            print(f"  [warn] {getattr(fn, '__name__', 'fn')} 第{i + 1}次失败：{type(e).__name__}")
            if i < tries - 1:
                time.sleep(delay * (i + 1))
    raise last


def is_trade_date(d: dt.date) -> bool:
    try:
        import akshare as ak
        cal = retry(ak.tool_trade_date_hist_sina)
        return str(d) in set(cal["trade_date"].astype(str))
    except Exception:
        return d.weekday() < 5


def macd(close, fast=12, slow=26, signal=9):
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    dif = ema_fast - ema_slow
    dea = dif.ewm(span=signal, adjust=False).mean()
    return dif, dea, (dif - dea) * 2


def analyze(df):
    """df：按日期升序的日线，返回趋势结论 dict（④⑤⑦ 由 ta.trend_state 统一判定）"""
    close = df["收盘"]
    st = ta.trend_state(close)
    if not st["valid"]:
        return {"trend": "数据不足", "phase": "unknown",
                "basis": ["有效数据不足，无法判定趋势"],
                "c": 0.0, "m5": np.nan, "m10": np.nan, "m20": np.nan, "m60": np.nan}
    c, m5, m10, m20, m60 = st["c"], st["ma5"], st["ma10"], st["ma20"], st["ma60"]
    vol = df["成交量"]
    vma5 = float(vol.rolling(5).mean().iloc[-1])
    vma20 = float(vol.rolling(20).mean().iloc[-1])
    vol_expand = vma5 > vma20

    ma_state = ("多头排列(MA5>MA10>MA20)" if m5 > m10 > m20
                else ("空头排列(MA5<MA10<MA20)" if m5 < m10 < m20 else "均线交织"))
    basis = [f"均线：{ma_state}，收盘{'站上' if c > m20 else '跌破'}MA20"
             + (f"，{'站上' if c > m60 else '跌破'}MA60({m60:.2f})" if not np.isnan(m60) else "")]
    basis.append(f"量能：近5日均量{'大于' if vol_expand else '小于'}20日均量（{'放量' if vol_expand else '缩量'}）")
    macd_parts = []
    if st["golden"]:
        macd_parts.append("DIF上穿DEA（金叉）")
    if st["death"]:
        macd_parts.append("DIF下穿DEA（死叉）")
    macd_parts.append(f"DIF={st['d']:.3f}，DEA={st['e']:.3f}，{'零轴上方' if st['d'] > 0 else '零轴下方'}")
    basis.append("MACD：" + "；".join(macd_parts))
    recent_high = float(close.iloc[-60:].max())
    recent_low = float(close.iloc[-60:].min())
    support = m20 if not np.isnan(m20) else recent_low
    resist = recent_high
    basis.append(f"支撑参考：MA20≈{support:.2f}；压力参考：近60日高点≈{resist:.2f}")
    return {"trend": st["label"], "phase": st["phase"], "basis": basis,
            "c": c, "m5": m5, "m10": m10, "m20": m20, "m60": m60}


def collect_signals(df, code):
    """汇总素材技巧信号，返回 (周线信号, 形态信号, 均线分析)"""
    weekly, forms = [], []
    ma = ta.ma_analysis(df)

    if ma.get("pullback_ma20"):
        forms.append({"name": "回踩MA20缩量", "weight": 10,
                      "text": "回踩MA20止跌且量能萎缩（素材口径：洗盘概率大，可作买点观察）"})
    if ma.get("cross_20_60"):
        forms.append({"name": "MA20×MA60金叉", "weight": 10, "text": "MA20上穿MA60，中期趋势转强"})

    yin = ta.long_yin_short_bar(df)
    if yin.get("found"):
        w = 15 if yin.get("confirmed") else 8
        forms.append({"name": "长阴短柱", "weight": w, "text": yin["text"]})

    mk = ta.meikai_erdu(df, code)
    if mk.get("score", 0) >= 3:
        w = 15 if mk.get("hit") else 8
        forms.append({"name": "梅开二度", "weight": w, "text": mk["text"]})

    k3 = ta.three_k_bias(df)
    if k3.get("text"):
        forms.append({"name": k3.get("state", "三K"), "weight": 5, "text": k3["text"]})

    for s in ta.main_wave_signals(df, code):
        forms.append(s)

    weekly = ta.weekly_signals(df)
    return weekly, forms, ma


def main():
    import akshare as ak
    ensure_dirs()
    today = dt.date.today()
    if not is_trade_date(today):
        print(f"{today} 非交易日，跳过盘后趋势研判。")
        return
    if not os.path.exists(WATCH_FILE):
        print(f"❌ 未找到监控清单：{WATCH_FILE}")
        return

    watch = pd.read_csv(WATCH_FILE, dtype={"code": str})
    watch["code"] = watch["code"].str.zfill(6)

    # 400 日窗口：满足 MA60 + 周线 MA20周（约需 20+ 周）
    start = (today - dt.timedelta(days=400)).strftime("%Y%m%d")
    end = today.strftime("%Y%m%d")

    rows = []      # 汇总评分
    details = []   # 结构化逐只明细（供 dashboard）
    body = []      # 正文段落
    kline_dates = []  # 各股 K 线最后日期，用于报告标注真实数据截止日
    L = [f"# 【盘后趋势研判】{today.strftime('%Y-%m-%d')}", "",
         "> 基于前复权日线数据（窗口约400日），指标：均线、量能、MACD。",
         "> 形态与周线信号来自 Materials 素材技巧的机械化实现（均线体系、长阴短柱、梅开二度、周线买点、主升浪可量化形态），仅为客观统计，不代表未来涨跌。", ""]

    for _, row in watch.iterrows():
        code, name = row["code"], row["name"]
        print(f"处理 {code} {name} ...")
        try:
            # fresh=True：腾讯日线收盘后常滞后一日，启用多源择优取到当日收盘
            df = ta.load_kline(ak, code, start, end, retry=retry, fresh=True)
        except Exception as e:
            print(f"  [warn] {code} 历史数据获取失败：{type(e).__name__}: {e}")
            body.append(f"## {code} {name}\n- 数据获取失败，本次跳过。\n")
            continue
        if df is None or df.empty or len(df) < 25:
            n = 0 if df is None else len(df)
            print(f"  [warn] {code} 有效数据不足：{n} 条")
            body.append(f"## {code} {name}\n- 有效数据不足（{n} 条），无法判定趋势。\n")
            continue
        try:
            kline_dates.append(pd.to_datetime(df["日期"].max()))
        except Exception:
            pass

        r = analyze(df)
        weekly, forms, ma = collect_signals(df, code)
        base = TREND_SCORE.get(r["trend"], 20)
        # 权重设计：趋势基础分占6成，周线信号上限30，形态信号上限25，避免轻易顶到100分
        score = int(min(100, base * 0.6 + min(ta.score_signals(weekly)[0], 30)
                        + min(ta.score_signals(forms)[0], 25)))
        # ⑥ level 由趋势相位决定，避免“干净上升通道却被判弱势”的自相矛盾
        PHASE_LEVEL = {"up": "强势", "up_weak": "强势", "range": "中性",
                       "down_weak": "弱势", "down": "弱势"}
        level = PHASE_LEVEL.get(r.get("phase"), "中性")

        body.append(f"## {code} {name}")
        body.append(f"- **趋势标签：{r['trend']}**｜综合评分 {score}/100（{level}）")
        ma60_s = f"，MA60={r['m60']:.2f}" if not np.isnan(r["m60"]) else ""
        body.append(f"- 最新收盘：{r['c']:.2f}；MA5={r['m5']:.2f}，MA10={r['m10']:.2f}，MA20={r['m20']:.2f}{ma60_s}")
        for b in r["basis"]:
            body.append(f"- {b}")
        if weekly:
            body.append("- **周线信号**：" + "；".join(f"{s['name']}（{s['text']}）" for s in weekly))
        if forms:
            body.append("- **形态信号**：" + "；".join(f"{s['name']}（{s['text']}）" for s in forms))
        # 观察提示：把信号翻译成操作层面的话术（仅提示，非建议）
        hints = []
        if weekly:
            hints.append("周线级别出现买点类型信号，可作为中期观察方向")
        if ma.get("pullback_ma20"):
            hints.append("回踩MA20缩量，次日看能否守住MA20")
        if any(f["name"] == "长阴短柱" for f in forms):
            hints.append("长阴短柱形态成立，若后续收盘站上该阴线开盘价则形态确认")
        if any(f["name"] == "梅开二度" for f in forms):
            hints.append("梅开二度形态推进中，重点看是否出现倍量阳包阴")
        if not np.isnan(r["m60"]) and r["c"] < r["m60"]:
            hints.append("收盘在MA60下方，中期仍处弱势，需先收复长期成本线")
        if hints:
            body.append("- 观察提示：" + "；".join(hints))
        body.append("")
        rows.append({"代码": code, "名称": name, "趋势": r["trend"], "评分": score,
                     "周线信号": "、".join(s["name"] for s in weekly) or "--",
                     "形态信号": "、".join(s["name"] for s in forms) or "--"})
        details.append({
            "code": code, "name": name, "trend": r["trend"], "score": score,
            "level": level, "close": round(r["c"], 2),
            "ma5": round(r["m5"], 2), "ma10": round(r["m10"], 2),
            "ma20": round(r["m20"], 2),
            "ma60": (round(r["m60"], 2) if not np.isnan(r["m60"]) else None),
            "basis": r["basis"],
            "weekly": [{"name": s["name"], "text": s.get("text", "")} for s in weekly],
            "forms": [{"name": s["name"], "text": s.get("text", "")} for s in forms],
            "hints": hints,
        })

    # 汇总表
    if rows:
        L.append("## 今日形态/信号汇总（按综合评分排序）")
        L.append("")
        L.append("| 代码 | 名称 | 趋势 | 评分 | 周线信号 | 形态信号 |")
        L.append("| --- | --- | --- | --- | --- | --- |")
        for x in sorted(rows, key=lambda z: -z["评分"]):
            L.append(f"| {x['代码']} | {x['名称']} | {x['趋势']} | {x['评分']} | {x['周线信号']} | {x['形态信号']} |")
        L.append("")
    # 数据时效标注：标题按当天生成，但 K 线可能因数据源滞后停在上一交易日，
    # 必须明示真实数据截止日，避免「看起来是今日、实际是昨日」。
    last_date = max(kline_dates).strftime("%Y-%m-%d") if kline_dates else None
    data_fresh = bool(last_date and last_date == today.strftime("%Y-%m-%d"))
    if last_date:
        tag = "✅ 当日收盘" if data_fresh else "⚠️ 非当日收盘（K线数据源尚未更新，指标基于上一交易日）"
        L.insert(2, f"> **数据截止：{last_date}**（{tag}）｜样本 {len(kline_dates)} 只")
    else:
        L.insert(2, "> **数据截止：未知**（本次未取到有效 K 线）")

    L.extend(body)
    L.append(DISCLAIMER)

    out = os.path.join(OUT_DIR, f"{today.strftime('%Y-%m-%d')}盘后趋势.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"✅ 盘后趋势报告已保存：{out}")

    # ---- 结构化输出（前端 dashboard 用）----
    trend_data = {
        "date": today.strftime("%Y-%m-%d"),
        "kline_last_date": last_date,
        "data_fresh": data_fresh,
        "stocks": sorted(details, key=lambda z: -z["score"]),
        "summary": sorted(rows, key=lambda z: -z["评分"]),
    }
    dc.save_json(OUT_DIR, f"{today.strftime('%Y-%m-%d')}盘后趋势.json", trend_data)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        print(f"❌ {__file__} 异常终止：{e}")
        raise
