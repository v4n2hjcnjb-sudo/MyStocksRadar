@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

REM Keep this file ASCII-only. cmd.exe parses .bat with the active code page;
REM Chinese text + "chcp 65001" makes it split lines and run fragments as commands.
REM Data dir is under the install folder; upgrades never overwrite it.
set "RADAR_DATA=%~dp0..\data"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
set "PORT=8080"
REM Local-only console: login disabled by default.
set "AUTH_REQUIRED="

REM Always bypass proxy for loopback; keep any existing NO_PROXY entries.
REM HTTP_PROXY / HTTPS_PROXY stay intact so market-data scripts can still reach the internet.
set "NO_PROXY=127.0.0.1,localhost,::1,%NO_PROXY%"
set "no_proxy=127.0.0.1,localhost,::1,%no_proxy%"

REM Pick interpreter: packaged venv first, then system python.
set "PY=%~dp0..\.venv\Scripts\python.exe"
if not exist "%PY%" (
    where python >nul 2>nul
    if errorlevel 1 (
        echo [ERROR] Python / packaged .venv not found. Run deploy\bootstrap.py first.
        pause
        exit /b 1
    )
    set "PY=python"
)

REM If a healthy service is already running, only open the browser.
REM netstat alone is unreliable: Windows can leave PID 0 LISTENING ghost rows
REM after a killed process, which used to make the launcher skip starting entirely.
"%PY%" -c "import urllib.request as u,sys; o=u.build_opener(u.ProxyHandler({})); r=o.open('http://127.0.0.1:%PORT%/api/health',timeout=1); sys.exit(0 if r.status==200 else 1)" >nul 2>&1
if %errorlevel%==0 (
    echo A healthy service is already running; opening browser only.
    start "" "http://127.0.0.1:%PORT%/"
    exit /b 0
)

echo ============================================================
echo   A-Share Radar - Local Console
echo   Data  : %RADAR_DATA%
echo   URL   : http://127.0.0.1:%PORT%/
echo   Login : DISABLED (local only)
echo   Stop  : close the "RadarConsole" window
echo ============================================================

REM Start server in its own window, then wait until the port is really listening.
start "RadarConsole" cmd /k ""%PY%" server.py %PORT%"

set /a TRIES=0
:WAIT
set /a TRIES+=1
"%PY%" -c "import socket,sys; s=socket.socket(); s.settimeout(0.4); sys.exit(0 if s.connect_ex(('127.0.0.1',%PORT%))==0 else 1)" >nul 2>nul
if %errorlevel%==0 goto READY
if %TRIES% GEQ 30 goto TIMEOUT
ping -n 2 127.0.0.1 >nul
goto WAIT

:TIMEOUT
echo [ERROR] Server did not start within 30s.
echo         Check the RadarConsole window, or run manually:
echo         "%PY%" server.py %PORT%
pause
exit /b 1

:READY
echo Server is up. Opening browser...
start "" "http://127.0.0.1:%PORT%/"
echo.
echo Keep the "RadarConsole" window open - closing it stops the service.
echo This launcher window can be closed now.
pause >nul
endlocal
