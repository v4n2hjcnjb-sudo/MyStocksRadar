# -*- coding: utf-8 -*-
"""
A股投研雷达 · 本地控制台服务
- 托管前端页面（投研雷达控制台.html）
- 提供 API：健康检查 / 自选股读写 / 任务异步运行+实时日志 / 报告读取 / Excel下载
启动：python server.py [端口]    默认端口 8080
访问：http://127.0.0.1:8080
"""
import sys
import os
import io
import json
import time
import mimetypes
import base64
import subprocess
import threading
import datetime as dt
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 数据根目录：由 bootstrap/启动脚本注入 RADAR_DATA；未设置时落到用户目录，避免依赖固定盘符
RADAR_DATA = os.environ.get("RADAR_DATA") or os.path.join(os.path.expanduser("~"), "radar-data")
BASE = RADAR_DATA
# 分析脚本统一存放在本项目的 scripts/ 目录（单一代码源），与数据目录 BASE 解耦
SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts")
SCRIPTS = {
    "daily_hot": "daily_hot.py",
    "stock_pool": "stock_pool.py",
    "watch_monitor": "watch_monitor.py",
    "trend_report": "trend_report.py",
    "review_report": "review_report.py",
}
OUT_DIRS = {
    "daily_hot": "daily_hot",
    "stock_pool": "stock_pool",
    "watch_monitor": "watch_list",
    "trend_report": "daily_report",
    "review_report": "daily_report",
}
TASK_NAMES = {
    "daily_hot": "盘前热点",
    "stock_pool": "自动选股",
    "watch_monitor": "盘中监控",
    "trend_report": "盘后趋势",
    "review_report": "复盘研判",
}
HERE = os.path.dirname(os.path.abspath(__file__))
HTML_FILE = os.path.join(HERE, "投研雷达控制台.html")
WATCH_FILE = os.path.join(BASE, "config", "watch_stock.csv")
SCREENER_FILE = os.path.join(HERE, "选股.html")
THEME_FILE = os.path.join(HERE, "theme.css")
WORKSHOP_FILE = os.path.join(HERE, "workshop.html")
MATERIALS_DIR = os.path.join(BASE, "Materials")
INDICATORS_FILE = os.path.join(BASE, "config", "indicators.json")


def _venv_site_packages():
    """分发版无需注入：服务与任务子进程均由包内 .venv 的解释器启动，依赖天然可见。"""
    return None

def child_env():
    """构造子进程环境：把 venv 的 site-packages 注入 PYTHONPATH，并剔除指向本机的沙箱代理。"""
    env = dict(os.environ)
    # 强制所有任务子进程的 stdout/stderr 为 UTF-8。由 start-console.bat 启动时
    # 系统 locale 为 GBK(CP936)，脚本打印 ✅/❌ 会 UnicodeEncodeError 并让任务
    # 以退出码 1 结束（即便报告已成功写出）。Popen 读取端亦为 utf-8，两端一致。
    env["PYTHONIOENCODING"] = "utf-8"
    sp = _venv_site_packages()
    if sp:
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = sp + (os.pathsep + existing if existing else "")
    # 移除指向 127.0.0.1 / localhost 的代理（工具沙箱出口代理在主机网络上不存在，
    # 否则 akshare 走死代理导致行情抓取失败；真实企业代理不在本机，予以保留）
    try:
        from urllib.parse import urlparse
        for k in list(env.keys()):
            if k.upper().endswith("PROXY"):
                host = urlparse(env[k]).hostname or ""
                if host in ("127.0.0.1", "localhost", "::1"):
                    env.pop(k)
    except Exception:
        pass
    return env


# ===================== 登录鉴权（默认关闭，预留公网开关） =====================
# 当前仅在本机 127.0.0.1 使用：默认完全免登录，不生成密码文件、不校验 cookie。
# 将来若确需部署到公网，设环境变量 AUTH_REQUIRED=1 即可恢复账号密码登录
# （密码来自 console/auth.json，或 AUTH_USER / AUTH_PASS 环境变量）。
import secrets as _secrets
import hashlib as _hashlib
from http.cookies import SimpleCookie as _SimpleCookie

AUTH_REQUIRED = os.environ.get("AUTH_REQUIRED", "") in ("1", "true", "yes")
AUTH_FILE = os.path.join(HERE, "auth.json")
SALT_FILE = os.path.join(HERE, ".auth_salt")
SESSION_TTL = 12 * 3600  # 会话有效期（秒）


def _load_salt():
    if not AUTH_REQUIRED:
        return ""  # 免登录模式下不生成任何密码盐文件
    if os.path.exists(SALT_FILE):
        try:
            with open(SALT_FILE, "r", encoding="utf-8") as f:
                return f.read().strip()
        except Exception:
            pass
    salt = _secrets.token_hex(16)
    try:
        with open(SALT_FILE, "w", encoding="utf-8") as f:
            f.write(salt)
    except Exception:
        pass
    return salt


_AUTH_SALT = _load_salt()


def _hash_password(pw):
    return _hashlib.sha256((_AUTH_SALT + ":" + (pw or "")).encode("utf-8")).hexdigest()


def _load_credentials():
    user = os.environ.get("AUTH_USER", "admin")
    pw = os.environ.get("AUTH_PASS")
    if pw:
        return user, _hash_password(pw)
    if os.path.exists(AUTH_FILE):
        try:
            with open(AUTH_FILE, encoding="utf-8") as f:
                d = json.load(f)
            return d.get("user", "admin"), _hash_password(d.get("password", ""))
        except Exception:
            pass
    # 首次启动：生成随机密码并持久化，禁止内置弱默认口令
    pw = _secrets.token_urlsafe(12)
    try:
        os.makedirs(os.path.dirname(AUTH_FILE), exist_ok=True)
        with open(AUTH_FILE, "w", encoding="utf-8") as f:
            json.dump({"user": user, "password": pw}, f, ensure_ascii=False, indent=2)
        print("=" * 56)
        print(f"  已生成初始登录信息：账号 {user} / 密码 {pw}")
        print(f"  已保存到 {AUTH_FILE}（请妥善保管，可自行修改）")
        print("=" * 56)
    except Exception as e:
        print(f"  [警告] 无法写入 {AUTH_FILE}：{e}；本次使用临时随机密码")
    return user, _hash_password(pw)


AUTH_USER, AUTH_HASH = _load_credentials() if AUTH_REQUIRED else ("admin", "")
SESSIONS = {}  # token -> {"user":..., "expires":...}
SESSIONS_LOCK = threading.Lock()


def _new_session(user):
    token = _secrets.token_hex(32)
    with SESSIONS_LOCK:
        SESSIONS[token] = {"user": user, "expires": time.time() + SESSION_TTL}
    return token


def _purge_sessions():
    now = time.time()
    with SESSIONS_LOCK:
        expired = [t for t, s in SESSIONS.items() if s["expires"] < now]
        for t in expired:
            SESSIONS.pop(t, None)


LOGIN_HTML = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>投研雷达 · 登录</title>
<link rel="stylesheet" href="/theme.css">
</head>
<body><div class="login-wrap"><div class="login-card">
  <h1>投研雷达 · 登录</h1>
  <div class="sub">本地投研控制台 · 请输入账号密码</div>
  <form id="f" onsubmit="login(); return false;">
    <label>账号</label>
    <input id="user" value="admin" autocomplete="username">
    <label>密码</label>
    <input id="pass" type="password" autocomplete="current-password">
    <div class="msg" id="msg"></div>
    <button type="submit">登 录</button>
  </form>
</div></div>
<script>
async function login(){
  const msg=document.getElementById('msg'); msg.textContent='';
  const user=document.getElementById('user').value;
  const pass=document.getElementById('pass').value;
  try{
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user,password:pass})});
    const d=await r.json().catch(()=>({error:'登录失败'}));
    if(r.ok && d.ok){ window.location='/'; return false; }
    msg.textContent=d.error||'登录失败';
  }catch(e){ msg.textContent='网络错误'; }
  return false;
}
</script></body></html>"""


# ===================== 规则说明（单一数据源：前端浮窗 + 独立说明页共享） =====================
def _esc_html(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


RULES = [
    {"group": "通用指标", "items": [
        {"id": "ma_struct", "title": "均线结构（MA5 / MA20 / MA60）",
         "explain": "由5日、20日、60日均线排列判断趋势：MA5>MA20>MA60 为多头排列（上升趋势确认）；相反为空头排列；介于之间为均线交织。MA20 是短期趋势生命线，MA60 代表长期成本线。"},
        {"id": "vol_ratio", "title": "量比（估）",
         "explain": "当日成交量 ÷ 近5日日均成交量。>1 表示放量、资金活跃；<1 表示缩量。盘中使用近似值（当日成交量 ÷ 近5日均量）。"},
        {"id": "amount", "title": "成交额（亿）",
         "explain": "单位：亿元。反映个股资金参与程度，成交额越大代表交投越活跃。"},
        {"id": "macd", "title": "MACD",
         "explain": "由快线 DIF 与慢线 DEA 构成。DIF 上穿 DEA 为金叉（看多信号），下穿为死叉（看空）；柱状在零轴上方代表正向动能。"},
        {"id": "score", "title": "综合评分（0~100）",
         "explain": "多因子加权得出的 0~100 分，分数越高代表多维度共振越强。仅为统计结果，不构成买卖建议。"},
    ]},
    {"group": "盘前热点", "items": [
        {"id": "hot_sector", "title": "热点板块（行业动量 TOP）",
         "explain": "按申万行业聚合全市场涨跌幅，取中位涨跌幅排名靠前的板块（样本数≥8），代表当日资金主攻方向。"},
        {"id": "weak_sector", "title": "弱势板块",
         "explain": "当日中位涨跌幅排名靠后、资金流出的板块。"},
        {"id": "fed", "title": "美联储",
         "explain": "联邦基金目标利率及最新议息动态，影响全球流动性与风险偏好。"},
        {"id": "crude", "title": "原油 & 商品期货",
         "explain": "WTI/Brent 原油及主要商品期货最新价与涨跌幅，影响通胀预期与周期股表现。"},
        {"id": "index_trend", "title": "主要指数趋势（5/15/30日）",
         "explain": "主要指数近 5/15/30 日收盘价走势（迷你走势线），用于判断短、中、长期方向。"},
        {"id": "us_asia", "title": "美股 / 日韩指数趋势",
         "explain": "道琼斯 / 纳斯达克 / 标普500、日经225 / 韩国KOSPI 近 5/15/30 日走势，反映外围市场风险偏好。"},
        {"id": "sentiment", "title": "市场情绪 / 北向",
         "explain": "上涨/下跌家数、涨停/跌停数反映市场温度；北向资金（沪股通/深股通）为外资流向参考（实时披露已暂停）。"},
    ]},
    {"group": "自动选股规则（8条硬规则 + 加分项）", "items": [
        {"id": "pool_rule", "title": "选股规则总览",
         "explain": "候选池取自沪深300 + 中证500 成分股，依次经过市值、估值、质量、量能、技术、解禁 6 类规则筛选；通过后再从热点板块优先选出 3 只。"},
        {"id": "r_cap", "title": "规则·市值门槛",
         "explain": "总市值需在 50亿~500亿 之间，剔除市值过小与超大盘权重股。"},
        {"id": "r_pe", "title": "规则·PE(TTM) 门槛",
         "explain": "PE(TTM) 需在 10~35 之间，避免高估值与亏损股。"},
        {"id": "r_pb", "title": "规则·PB 门槛",
         "explain": "PB > 1，即股价高于每股净资产，作为质地底线。"},
        {"id": "r_st", "title": "规则·ST 过滤",
         "explain": "剔除 ST / *ST 等风险警示股票。"},
        {"id": "r_vol", "title": "规则·放量",
         "explain": "近5日均量 > 20日均量，代表资金开始关注。"},
        {"id": "r_macd", "title": "规则·MACD 金叉",
         "explain": "DIF 上穿 DEA，趋势转强信号。"},
        {"id": "r_unlock", "title": "规则·解禁",
         "explain": "未来30日无大额解禁（解禁市值 > 1亿元视为大额），规避潜在抛压。"},
        {"id": "r_quality", "title": "规则·质量门槛（ROE / 净利润）",
         "explain": "ROE 不为负（剔除亏损），净利润同比不低于 -50%（仅排除业绩暴雷，不追求零下滑）。"},
        {"id": "r_ind_pe", "title": "加分项·行业相对估值",
         "explain": "PE 低于同行业中位数可获加分（非硬筛选，避免与市值条件形成双重惩罚）。"},
        {"id": "pool_score", "title": "选股综合评分",
         "explain": "估值10 + 行业相对5 + 成长(ROE/净利)40 + 量能10 + MACD10 + 周线20 + 形态20 = 100 分。"},
        {"id": "hot_pick", "title": "热点精选 3 只",
         "explain": "从通过全部规则的候选池中，优先取属于当日热点板块的标的，按综合评分取前3；热点不足时用其余候选补齐。"},
        {"id": "filtered", "title": "过滤明细",
         "explain": "未通过任一规则的标的及其具体原因，详见 Excel「过滤明细」页。"},
    ]},
    {"group": "操盘技巧（素材机械化实现）", "items": [
        {"id": "intraday", "title": "日内强弱（开盘口诀近似）",
         "explain": "素材「黄金开盘30分钟六句口诀」的近似实现：用当日开/高/低/现价判断日内强弱（如『稳步上行不破开盘价』偏多、『冲高回落跌破开盘价』偏弱）。注意：素材要求看开盘后30分钟分时，此处为近似标签，仅作强弱参考，非买卖信号。"},
        {"id": "pullback_ma20", "title": "回踩 MA20 缩量",
         "explain": "价格回踩20日线附近止跌、且成交量萎缩（<20日均量），素材视为洗盘特征，可作买点观察。"},
        {"id": "cross_20_60", "title": "MA20 × MA60 金叉",
         "explain": "20日均线上穿60日均线，中期趋势由弱转强的信号。"},
        {"id": "break_ma60", "title": "跌破 MA60",
         "explain": "收盘价低于60日线（长期成本线失守），中期仍处弱势，需先收复长期成本线。"},
        {"id": "long_yin", "title": "长阴短柱",
         "explain": "回调中出现长阴线（跌幅≥3%、实体≥2.5%）但成交量≤前5日均量的80%，价跌量缩=抛压枯竭/洗盘；其后某日收盘站上该阴线开盘价则形态确认。"},
        {"id": "meikai", "title": "梅开二度",
         "explain": "素材「二三四口诀」：首板涨停（试盘）后缩量回调，回调不破涨停价1/2、出现三连阴、量缩至首板1/4以下，且出现倍量阳包阴启动。形态进度 0~5，≥3 提示关注，≥4 视为命中。"},
        {"id": "three_k", "title": "三 K 结构",
         "explain": "最近三根K线关系：外包线=波动放大、方向不明（偏谨慎）；内包线=缩量蓄势待方向；二号K线实体站上/跌破一号K线最高/最低=短多/短空结构。"},
        {"id": "weekly_5", "title": "周线买点·站稳5周线",
         "explain": "连续3周收盘站上5周均线，波段上车信号。"},
        {"id": "weekly_multi", "title": "周线买点·周线多头",
         "explain": "5周线上穿并高于20周线、且5周线拐头向上，中期趋势转强。"},
        {"id": "weekly_break", "title": "周线买点·突破平台",
         "explain": "本周收盘突破前4周最高价，震荡平台突破信号。"},
        {"id": "weekly_10", "title": "周线买点·10周线防守",
         "explain": "连续4周收盘站稳10周线，主力横盘建仓特征。"},
        {"id": "weekly_blast", "title": "周线买点·破阴起爆",
         "explain": "上周大阴被本周大阳反包、量能达周均量3倍，强启动信号。"},
        {"id": "main_wave", "title": "主升浪可量化形态",
         "explain": "素材「主升浪十句口诀」可量化部分，仅标记形态：低位放量、跌后反包、连板强势、连续阳线、长下影探底、突破均线束（均线粘合后放量长阳突破）。均为客观统计，非买卖结论。"},
    ]},
]


def render_rules_page():
    out = []
    out.append("""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>投研雷达 · 规则说明</title>
<link rel="stylesheet" href="/theme.css">
</head>
<body class="rules-page"><div class="wrap">
<header><h1>规则与操盘技巧说明</h1><a class="back" href="/">← 返回控制台</a></header>
<p class="lead">以下为该投研工具所用指标、选股规则与素材操盘技巧的口径说明。所有信号均基于公开历史数据客观统计，不构成任何投资建议，无法预测股价未来走势。</p>
""")
    for g in RULES:
        out.append(f'<div class="group"><h2>{_esc_html(g["group"])}</h2>')
        for it in g["items"]:
            out.append(
                f'<div class="item" id="{_esc_html(it["id"])}">'
                f'<h3>{_esc_html(it["title"])}<a class="anchor" href="#{_esc_html(it["id"])}">#</a></h3>'
                f'<p>{_esc_html(it["explain"])}</p></div>')
        out.append('</div>')
        out.append("""<p class="dis">本内容仅基于公开历史市场数据进行统计整理，不构成任何投资建议，无法预测股价未来走势，股市有风险，入市需谨慎。</p>
</div></body></html>""")
    return "\n".join(out)


# ---------------------------------------------------------------------------
# 技巧工坊：指标注册表（外部化收集素材里的可量化指标）
# 计算逻辑仍在 scripts/ta_rules.py（按 impl 字段映射）；本表只管理
# 评级 / 类型 / 参数 / 权重 / 启用 / 喂给哪些看板。AI 解析在 Phase 2 接入。
# ---------------------------------------------------------------------------
INDICATORS_SEED = [
    {"id": "A1_ma_structure", "name": "关键均线知识点", "rating": "A",
     "type": "因子", "source": "素材01 · 关键均线知识点",
     "impl": "ta_rules.ma_analysis",
     "boards": ["watch_monitor", "trend_report", "stock_pool"],
     "weight": 8, "enabled": True,
     "params": {"ma_long": 60, "cross": "MA20_MA60"},
     "note": "5/20/60日线结构；回踩MA20缩量+8、MA20×MA60金叉+8。仅作趋势分层，不作为买卖信号。"},
    {"id": "A2_long_yin_short_bar", "name": "长阴短柱", "rating": "A",
     "type": "形态", "source": "素材02 · 长阴短柱",
     "impl": "ta_rules.long_yin_short_bar",
     "boards": ["watch_monitor", "stock_pool", "trend_report"],
     "weight": 10, "enabled": True,
     "params": {"drop_pct": -3.0, "body_pct": 2.5, "vol_ratio": 0.8},
     "note": "价跌量缩=洗盘非出货；已确认+10/未确认+6。回答「跌了该不该怕」，不是「跌了会不会涨」。"},
    {"id": "A3_meikai_erdu", "name": "梅开二度", "rating": "A",
     "type": "形态", "source": "素材03 · 梅开二度",
     "impl": "ta_rules.meikai_erdu",
     "boards": ["watch_monitor", "stock_pool"],
     "weight": 10, "enabled": True,
     "params": {"first_limit": True, "pullback_half": True, "three_down": True,
                "vol_quarter": True, "next_day_big": True},
     "note": "5项进度评分；≥3项进形态标记，5项全中+10。阈值偏严，可能整月无触发。"},
    {"id": "A4_weekly_signals", "name": "周线买点", "rating": "A",
     "type": "因子", "source": "素材04 · 周线买点",
     "impl": "ta_rules.weekly_signals",
     "boards": ["stock_pool", "trend_report"],
     "weight": 20, "enabled": True,
     "params": {"signals": ["ma5_week", "ma5_20_week_bull", "break_platform",
                            "ma10_week_defend", "break_yin_burst"]},
     "note": "5周线/5-20周多头/突破平台/10周线防守/破阴起爆。周五收盘后稳定。弃用无阈值的「三星探底」。"},
    {"id": "A5_fundamental_filters", "name": "豆包选股因子（基本面）", "rating": "A",
     "type": "因子", "source": "素材05 · 豆包选股因子（基本面）",
     "impl": "stock_pool.rules_7_8",
     "boards": ["stock_pool"],
     "weight": 5, "enabled": True,
     "params": {"industry_pe_bonus": 5.0, "roe_min": 0.0,
                "profit_growth_min": -50.0, "ind_pe_min_sample": 5},
     "note": "规则7 行业相对估值(加分) + 规则8 盈利质量(剔除亏损/暴雷)。北向因子数据源已不存在，不实现。"},
    {"id": "A6_composite_score", "name": "AI选股因子流程（多因子评分）", "rating": "A",
     "type": "因子", "source": "素材06 · AI选股因子流程（多因子评分）",
     "impl": "stock_pool.composite_score",
     "boards": ["stock_pool"],
     "weight": 0, "enabled": True,
     "params": {"weights": {"估值": 15, "成长": 25, "量能": 10, "MACD": 10, "周线": 20, "形态": 20}},
     "note": "综合评分0-100框架（估值/成长/量能/MACD/周线/形态）。月度调仓与回测未采纳。"},
    {"id": "B1_intraday_bias", "name": "黄金开盘30分近似判定", "rating": "B",
     "type": "信号", "source": "素材07 · 黄金开盘30分近似判定",
     "impl": "ta_rules.intraday_bias",
     "boards": ["watch_monitor"],
     "weight": 6, "enabled": True,
     "params": {},
     "note": "用今开/最高/最低/现价做近似日内强弱标签+语气标记。非买卖信号；接入分时数据后可切9:30-10:00窗口。"},
    {"id": "B2_three_k_bias", "name": "三根K线偏见", "rating": "B",
     "type": "形态", "source": "素材08 · 三根K线偏见",
     "impl": "ta_rules.three_k_bias",
     "boards": ["watch_monitor"],
     "weight": 0, "enabled": False,
     "params": {},
     "note": "仅保留外包线/内包线中性形态；「实体站上/跌破」只输出结构描述，不给方向。"},
    {"id": "B3_main_wave", "name": "主升浪形态", "rating": "B",
     "type": "形态", "source": "素材09 · 主升浪形态",
     "impl": "ta_rules.main_wave_signals",
     "boards": ["trend_report", "stock_pool"],
     "weight": 12, "enabled": True,
     "params": {"signals": ["低位放量", "跌后反包", "连板", "连续阳线", "长下影", "突破均线束"]},
     "note": "实现6条可量化；权重10-15。弃用「布林下轨低吸/阴后小K线洗盘」等无阈值口诀。"},
    {"id": "B4_break_yin_burst", "name": "周线破阴起爆", "rating": "B",
     "type": "形态", "source": "素材10 · 周线破阴起爆",
     "impl": "ta_rules.weekly_signals:break_yin_burst",
     "boards": ["trend_report"],
     "weight": 15, "enabled": True,
     "params": {"drop": -7.0, "vol_mult": 3.0},
     "note": "稀有强信号（周线跌7%大阴+次周大阳反包+量3倍），权重最高+15，不承担主筛选。"},
    {"id": "C1_time_patterns", "name": "三大时间规律", "rating": "C",
     "type": "玄学", "source": "素材11 · 三大时间规律",
     "impl": None,
     "boards": [],
     "weight": 0, "enabled": False,
     "params": {},
     "note": "数字玄学/过拟合（连跌8天、连涨3/5/7天等）。不采纳，仅记录。"},
    {"id": "C2_never_fall", "name": "23家不倒闭清单", "rating": "C",
     "type": "名单", "source": "素材12 · 23家不倒闭清单",
     "impl": None,
     "boards": [],
     "weight": 0, "enabled": False,
     "params": {},
     "note": "长期持有清单；市值>500亿与选股池冲突，作底仓观察，不进评分。"},
    {"id": "C3_goldman_picks", "name": "高盛持仓/评论区荐股", "rating": "C",
     "type": "名单", "source": "素材13 · 高盛持仓/评论区荐股",
     "impl": None,
     "boards": [],
     "weight": 0, "enabled": False,
     "params": {},
     "note": "来源不可验证；不因名人持仓给任何加分（原则问题）。"},
]


def load_indicators():
    """读取指标注册表；文件不存在时用种子自举（首次启动自动创建）。"""
    if os.path.exists(INDICATORS_FILE):
        try:
            with open(INDICATORS_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    os.makedirs(os.path.dirname(INDICATORS_FILE), exist_ok=True)
    with open(INDICATORS_FILE, "w", encoding="utf-8") as f:
        json.dump(INDICATORS_SEED, f, ensure_ascii=False, indent=2)
    return INDICATORS_SEED


def save_indicators(inds):
    os.makedirs(os.path.dirname(INDICATORS_FILE), exist_ok=True)
    with open(INDICATORS_FILE, "w", encoding="utf-8") as f:
        json.dump(inds, f, ensure_ascii=False, indent=2)


def list_materials():
    """列出 Materials/ 下的收集素材（仅顶层文件，跳过子目录）。"""
    if not os.path.isdir(MATERIALS_DIR):
        return []
    out = []
    for n in sorted(os.listdir(MATERIALS_DIR)):
        p = os.path.join(MATERIALS_DIR, n)
        if not os.path.isfile(p):
            continue
        ext = n.rsplit(".", 1)[-1].lower() if "." in n else ""
        if ext in ("jpg", "jpeg", "png", "gif", "webp"):
            kind = "image"
        elif ext in ("md", "txt"):
            kind = "doc"
        else:
            kind = "file"
        out.append({"name": n, "kind": kind, "mtime": int(os.path.getmtime(p))})
    return out


# ---- 技巧工坊：素材与 WorkBuddy 协同辅助 ----

_MAT_SNAP = None  # 上一轮素材快照，用于刷新时计算增删


def refresh_materials_state():
    """重新扫描素材目录，返回相对上次快照的 (added, removed) 文件名列表。"""
    global _MAT_SNAP
    cur = [m["name"] for m in list_materials()]
    added = removed = []
    if _MAT_SNAP is not None:
        added = [n for n in cur if n not in _MAT_SNAP]
        removed = [n for n in _MAT_SNAP if n not in cur]
    _MAT_SNAP = set(cur)
    return added, removed


def _wb_candidate_paths():
    local = os.path.expandvars("%LOCALAPPDATA%")
    prog_files = os.environ.get("ProgramFiles", r"C:\Program Files")
    prog_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    roots = [os.path.join(local, "Programs"), prog_files, prog_files_x86,
             os.path.expandvars("%APPDATA%")]
    names = ("WorkBuddy.exe", "CodeBuddy.exe", "workbuddy.exe")
    found = []
    for r in roots:
        if not r or not os.path.isdir(r):
            continue
        for name in names:
            p = os.path.join(r, name)
            if os.path.isfile(p):
                found.append(p)
            for sub in ("WorkBuddy", "CodeBuddy"):
                p2 = os.path.join(r, sub, name)
                if os.path.isfile(p2):
                    found.append(p2)
    return found


def find_workbuddy():
    cands = _wb_candidate_paths()
    return cands[0] if cands else None


def is_workbuddy_running():
    if sys.platform.startswith("win"):
        try:
            out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq WorkBuddy.exe"],
                                 capture_output=True, text=True, timeout=5).stdout
            if "WorkBuddy.exe" in out:
                return True
            out2 = subprocess.run(["tasklist", "/FI", "IMAGENAME eq CodeBuddy.exe"],
                                  capture_output=True, text=True, timeout=5).stdout
            return "CodeBuddy.exe" in out2
        except Exception:
            return False
    try:
        out = subprocess.run(["pgrep", "-fl", "WorkBuddy"],
                             capture_output=True, text=True, timeout=5).stdout
        return bool(out.strip())
    except Exception:
        return False


def launch_workbuddy():
    exe = find_workbuddy()
    if not exe:
        return False, None, "未找到 WorkBuddy 可执行文件，请手动启动（常见位置：%LOCALAPPDATA%\\Programs\\WorkBuddy）"
    try:
        if sys.platform.startswith("win"):
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            subprocess.Popen([exe], startupinfo=si, close_fds=True)
        else:
            subprocess.Popen([exe], close_fds=True)
        return True, exe, "已尝试启动 WorkBuddy，请稍候在任务栏确认"
    except Exception as e:
        return False, exe, f"启动失败：{e}"


def open_materials_folder():
    d = MATERIALS_DIR
    os.makedirs(d, exist_ok=True)
    try:
        if sys.platform.startswith("win"):
            os.startfile(d)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", d])
        else:
            subprocess.Popen(["xdg-open", d])
        return True, "已请求系统打开素材文件夹"
    except Exception as e:
        return False, f"无法打开文件夹：{e}（路径：{d}）"


def build_parse_prompt(mats):
    names = "\n".join(f"  - {m['name']}（{m['kind']}）" for m in mats) or "  （暂无素材）"
    return (
        "你是 A股投研雷达的「技巧解析器」。请按以下步骤工作：\n\n"
        f"1. 读取素材目录：{MATERIALS_DIR}\n当前素材清单：\n{names}\n\n"
        "2. 将素材中的炒股技巧/形态/因子，解析为「可量化指标」，每条输出：\n"
        "   - id（英文蛇形，唯一）\n"
        "   - name（中文名）\n"
        "   - rating：A=可直接落地 / B=提示性 / C=仅记录\n"
        "   - type：形态 / 因子 / 信号\n"
        "   - source：来源素材文件名\n"
        "   - impl：对应的 ta_rules.py 或 stock_pool.py 函数名（若无可填 null）\n"
        "   - boards：作用于哪些看板（daily_hot/stock_pool/watch_monitor/trend_report/review_report）\n"
        "   - weight：权重(1-20)  enabled：true/false  params：参数字典  note：要点\n\n"
        f"3. 把解析结果合并进注册表文件：{INDICATORS_FILE}\n"
        "   - 已有 id 则更新字段；新技巧则追加；不再出现的旧条目保留但标记 enabled=false。\n"
        "   - 严格保持 JSON 合法（ensure_ascii=false）。\n\n"
        "4. 完成后用简短中文汇报：新增/更新了哪些指标、对应哪些看板、哪些需要用户在「技巧工坊」页面确认启用。\n\n"
        "注意：只产出/修改 indicators.json 与必要的指标说明，不要改动其它生产代码；"
        "新指标的真正计算逻辑仍由 ta_rules.py 承载，本步骤只登记映射。"
    )


JOBS = {}
JOB_SEQ = 0
JOB_LOCK = threading.Lock()
LOG_LIMIT = 1000


def now_str():
    return dt.datetime.now().strftime("%H:%M:%S")


def job_log(jid, text):
    with JOB_LOCK:
        j = JOBS.get(jid)
        if j is None:
            return
        j["log"].append(f"[{now_str()}] {text}")
        if len(j["log"]) > LOG_LIMIT:
            j["log"] = j["log"][-LOG_LIMIT:]


def latest_file(task):
    d = os.path.join(BASE, OUT_DIRS[task])
    if not os.path.isdir(d):
        return None
    fs = [os.path.join(d, f) for f in os.listdir(d) if f.endswith((".md", ".xlsx"))]
    if not fs:
        return None
    fs.sort(key=os.path.getmtime, reverse=True)
    return fs[0]


def latest_json(task):
    d = os.path.join(BASE, OUT_DIRS[task])
    if not os.path.isdir(d):
        return None
    fs = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".json")]
    if not fs:
        return None
    fs.sort(key=os.path.getmtime, reverse=True)
    return fs[0]


def latest_screener_file():
    """选股器结果优先：存在 screener_*.json 则返回它，否则回退每日选股池.json。"""
    d = os.path.join(BASE, OUT_DIRS["stock_pool"])
    if not os.path.isdir(d):
        return None, None, None
    allf = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".json")]
    scr = sorted([f for f in allf if os.path.basename(f).startswith("screener_")], reverse=True)
    if scr:
        return scr[0], os.path.basename(scr[0]), "screener"
    allf.sort(key=os.path.getmtime, reverse=True)
    if allf:
        return allf[0], os.path.basename(allf[0]), "daily"
    return None, None, None


def _run_script(jid, t, silent=False):
    """运行单个任务脚本，实时把子进程输出写入任务日志；返回是否成功（退出码0）。"""
    if t not in SCRIPTS:
        if not silent:
            job_log(jid, f"⚠️ 未知任务：{t}")
        return False
    script = os.path.join(SCRIPTS_DIR, SCRIPTS[t])
    if not os.path.exists(script):
        if not silent:
            job_log(jid, f"❌ 脚本不存在：{script}")
        return False
    if not silent:
        job_log(jid, f"▶ 开始任务：{TASK_NAMES.get(t, t)}（{t}）")
    try:
        flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
        proc = subprocess.Popen(
            [sys.executable, script],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
            creationflags=flags, env=child_env(), cwd=BASE,
        )
        for line in proc.stdout:
            line = line.rstrip("\n")
            if line:
                job_log(jid, line)
        proc.wait()
        ok = proc.returncode == 0
    except Exception as e:
        job_log(jid, f"❌ 运行异常：{e}")
        ok = False
    if not silent:
        if ok:
            job_log(jid, f"✅ 任务完成：{TASK_NAMES.get(t, t)}")
        else:
            job_log(jid, f"❌ 任务失败：{TASK_NAMES.get(t, t)}（退出码非0，详见上方日志）")
    return ok


def ensure_fresh_daily_hot(jid):
    """复盘研判前，确保 daily_hot 数据源为『当日收盘后』快照；否则自动刷新『盘前热点』。

    问题背景：daily_hot 常在盘前（如 08:28）运行，其行情实为前一交易日收盘；
    若收盘后未重跑，复盘研判会误用盘前快照（=昨天收盘）。本函数按 generated_at
    判断是否已达当日 15:00 收盘，陈旧则静默刷新（刷新失败不阻断复盘，仅降级使用现有数据）。
    """
    now = dt.datetime.now()
    p = latest_json("daily_hot")
    need = True
    reason = "无数据文件"
    gen = ""
    if p:
        try:
            d = json.load(open(p, encoding="utf-8"))
            gen = d.get("generated_at") or d.get("date") or ""
            gdt = None
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
                try:
                    gdt = dt.datetime.strptime(gen, fmt)
                    break
                except Exception:
                    continue
            if gdt is not None:
                close_t = dt.datetime(now.year, now.month, now.day, 15, 0, 0)
                if gdt >= close_t:
                    need = False
                    reason = f"已是最新收盘快照（{gen}）"
                else:
                    reason = f"最近快照为 {gen}（早于今日 15:00 收盘）"
        except Exception as e:
            reason = f"读取数据失败：{e}"
    if need:
        job_log(jid, f"ℹ️ 指数/广度数据源陈旧（{reason}），自动刷新『盘前热点』以获取最新收盘数据…")
        _run_script(jid, "daily_hot", silent=True)
    else:
        job_log(jid, f"✓ 指数/广度数据源{reason}，无需刷新。")


def run_job(jid, tasks):
    j = JOBS.get(jid)
    if j is None:
        return
    j["state"] = "running"
    results = []
    try:
        # 若监控清单缺失，自动写入默认样本清单，避免 watch_monitor / trend_report 无数据
        if not os.path.exists(WATCH_FILE):
            try:
                os.makedirs(os.path.dirname(WATCH_FILE), exist_ok=True)
                with open(WATCH_FILE, "w", encoding="utf-8", newline="") as f:
                    f.write("code,name\n600519,贵州茅台\n600036,招商银行\n"
                            "601318,中国平安\n300750,宁德时代\n000858,五粮液\n"
                            "600276,恒瑞医药\n000333,美的集团\n")
                job_log(jid, "ℹ️ 监控清单不存在，已自动创建默认样本（可在左侧「自选股票清单」修改后保存）")
            except Exception as e:
                job_log(jid, f"⚠️ 创建默认监控清单失败：{e}")
        # 复盘研判依赖当日收盘的指数/广度数据；若数据源仍是盘前/昨日快照，先自动刷新
        if "review_report" in tasks:
            ensure_fresh_daily_hot(jid)
        for t in tasks:
            if t not in SCRIPTS:
                job_log(jid, f"⚠️ 未知任务：{t}")
                results.append({"task": t, "ok": False, "error": "未知任务"})
                continue
            j["current"] = TASK_NAMES.get(t, t)
            ok = _run_script(jid, t)
            f = latest_file(t)
            results.append({"task": t, "ok": ok, "file": os.path.basename(f) if f else None})
        j["results"] = results
        j["state"] = "done"
        job_log(jid, "🏁 全部任务执行结束。")
    except Exception as e:
        j["state"] = "error"
        j["error"] = str(e)
        job_log(jid, f"❌ 任务引擎异常：{e}")


def run_screener_job(jid, params):
    """选股器实时重跑：把自定义条件写入临时参数文件，以 SCREENER_PARAMS_FILE 环境变量拉起 stock_pool 子进程。"""
    j = JOBS.get(jid)
    if j is None:
        return
    j["state"] = "running"
    try:
        os.makedirs(os.path.join(BASE, "cache"), exist_ok=True)
        params_path = os.path.join(BASE, "cache", f"screener_params_{jid}.json")
        with open(params_path, "w", encoding="utf-8") as f:
            json.dump(params or {}, f, ensure_ascii=False)
        script = os.path.join(SCRIPTS_DIR, SCRIPTS["stock_pool"])
        if not os.path.exists(script):
            job_log(jid, f"❌ 脚本不存在：{script}")
            j["state"] = "error"
            j["error"] = "脚本不存在"
            return
        env = child_env()
        env["SCREENER_PARAMS_FILE"] = params_path
        flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
        job_log(jid, "▶ 开始选股器实时重跑（stock_pool，自定义条件）")
        proc = subprocess.Popen(
            [sys.executable, script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", creationflags=flags,
            env=env, cwd=BASE,
        )
        for line in proc.stdout:
            line = line.rstrip("\n")
            if line:
                job_log(jid, line)
        proc.wait()
        ok = proc.returncode == 0
        j["state"] = "done" if ok else "error"
        job_log(jid, "✅ 选股重跑完成（结果见选股页）" if ok else "❌ 选股重跑失败（退出码非0）")
    except Exception as e:
        j["state"] = "error"
        j["error"] = str(e)
        job_log(jid, f"❌ 选股重跑异常：{e}")


def read_watch():
    if not os.path.exists(WATCH_FILE):
        return []
    try:
        with open(WATCH_FILE, encoding="utf-8") as f:
            lines = f.read().strip().splitlines()
        out = []
        for i, ln in enumerate(lines):
            if i == 0 and ln.strip().startswith("code"):
                continue
            parts = [p.strip() for p in ln.split(",")]
            if parts and parts[0]:
                code = parts[0].zfill(6)
                name = parts[1] if len(parts) > 1 else ""
                out.append({"code": code, "name": name})
        return out
    except Exception:
        return []


def write_watch(watch):
    os.makedirs(os.path.dirname(WATCH_FILE), exist_ok=True)
    rows = ["code,name"]
    for w in watch:
        rows.append(f"{w.get('code', '').zfill(6)},{w.get('name', '')}")
    with open(WATCH_FILE, "w", encoding="utf-8", newline="") as f:
        f.write("\n".join(rows) + "\n")
    return read_watch()


class Handler(BaseHTTPRequestHandler):
    server_version = "RadarConsole/1.0"

    def log_message(self, fmt, *args):
        return

    def _authed(self):
        if not AUTH_REQUIRED:
            return True
        _purge_sessions()
        cookie = self.headers.get("Cookie")
        if not cookie:
            return False
        try:
            c = _SimpleCookie()
            c.load(cookie)
            m = c.get("radar_sid")
            if not m:
                return False
            token = m.value
            with SESSIONS_LOCK:
                s = SESSIONS.get(token)
                if not s or s["expires"] < time.time():
                    SESSIONS.pop(token, None)
                    return False
            return True
        except Exception:
            return False

    def _set_cookie(self, token):
        self.send_header("Set-Cookie",
                         f"radar_sid={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_TTL}")

    def _clear_session(self):
        cookie = self.headers.get("Cookie")
        if cookie:
            try:
                c = _SimpleCookie()
                c.load(cookie)
                m = c.get("radar_sid")
                if m:
                    with SESSIONS_LOCK:
                        SESSIONS.pop(m.value, None)
            except Exception:
                pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _html(self, content):
        body = content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        q = parse_qs(u.query)
        if path == "/login":
            if not AUTH_REQUIRED:
                self.send_response(302)
                self.send_header("Location", "/")
                self.end_headers()
                return
            self._html(LOGIN_HTML)
            return
        if path == "/logout":
            if AUTH_REQUIRED:
                self._clear_session()
            self.send_response(302)
            self.send_header("Location", "/login" if AUTH_REQUIRED else "/")
            self.end_headers()
            return
        # 健康探测免登录：纯存活 ping，无敏感数据，供外部代理/监控稳定判定 upstream 存活
        if path == "/api/health":
            self._json({"ok": True, "server": "radar-console", "time": now_str(),
                        "base": BASE, "scripts": sorted(SCRIPTS.keys())})
            return
        # 共享样式表：静态资源，免登录（与 /api/health 同策略），供所有页面统一引用
        if path == "/theme.css":
            if os.path.exists(THEME_FILE):
                with open(THEME_FILE, encoding="utf-8") as fh:
                    body = fh.read().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/css; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "public, max-age=300")
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_error(404)
            return
        # 收集素材静态文件（截图/报告）：静态资源，免登录，供技巧工坊缩略图引用
        if path.startswith("/materials/"):
            fname = path[len("/materials/"):].split("?")[0]
            fname = os.path.basename(fname)  # 防目录穿越
            fp = os.path.join(MATERIALS_DIR, fname)
            if os.path.isfile(fp):
                mime, _ = mimetypes.guess_type(fp)
                with open(fp, "rb") as fh:
                    body = fh.read()
                self.send_response(200)
                self.send_header("Content-Type", mime or "application/octet-stream")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "public, max-age=3600")
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_error(404)
            return
        if not self._authed():
            if path.startswith("/api/"):
                self._json({"error": "未登录"}, 401)
                return
            self.send_response(302)
            self.send_header("Location", "/login")
            self.end_headers()
            return
        if path == "/" or path == "/index.html":
            if os.path.exists(HTML_FILE):
                with open(HTML_FILE, encoding="utf-8") as f:
                    self._html(f.read())
            else:
                self._json({"error": f"未找到前端页面：{HTML_FILE}"}, 500)
            return
        if path == "/api/rules":
            self._json({"rules": RULES})
            return
        if path == "/rules":
            self._html(render_rules_page())
            return
        if path == "/screener":
            if os.path.exists(SCREENER_FILE):
                with open(SCREENER_FILE, encoding="utf-8") as f:
                    self._html(f.read())
            else:
                self._json({"error": f"未找到选股页面：{SCREENER_FILE}"}, 500)
            return
        if path == "/workshop":
            if os.path.exists(WORKSHOP_FILE):
                with open(WORKSHOP_FILE, encoding="utf-8") as f:
                    self._html(f.read())
            else:
                self._json({"error": f"未找到技巧工坊页面：{WORKSHOP_FILE}"}, 500)
            return
        if path == "/api/screener/data":
            fp, fn, mode = latest_screener_file()
            if fp is None:
                self._json({"exists": False, "message": "暂无选股数据：可先在选股页点「实时重跑」，或运行每日选股任务。"})
                return
            try:
                with open(fp, encoding="utf-8") as fh:
                    obj = json.load(fh)
                self._json({"exists": True, "mode": mode, "filename": fn, "data": obj})
            except Exception as e:
                self._json({"exists": False, "error": str(e)}, 500)
            return
        if path == "/api/workshop":
            inds = load_indicators()
            mats = list_materials()
            added, removed = refresh_materials_state()
            self._json({"indicators": inds, "materials": mats,
                        "added": added, "removed": removed,
                        "boards": TASK_NAMES, "materials_dir": MATERIALS_DIR})
            return
        if path == "/api/workshop/wb":
            self._json({"running": is_workbuddy_running(),
                        "path": find_workbuddy(),
                        "materials_dir": MATERIALS_DIR})
            return
        if path == "/api/watch":
            self._json({"watch": read_watch(), "file": WATCH_FILE})
            return
        if path == "/api/status":
            jid = (q.get("id") or [""])[0]
            j = JOBS.get(jid)
            if j is None:
                self._json({"error": "任务不存在"}, 404)
                return
            tail = j["log"][-400:]
            self._json({"id": jid, "state": j["state"], "current": j.get("current"),
                        "results": j.get("results", []), "error": j.get("error"),
                        "log": tail, "started": j.get("started")})
            return
        if path == "/api/report":
            task = (q.get("task") or [""])[0]
            if task not in OUT_DIRS:
                self._json({"error": "未知任务"}, 400)
                return
            f = latest_file(task)
            if f is None:
                self._json({"task": task, "exists": False, "message": "暂无报告，先运行任务生成"})
                return
            if f.endswith(".md"):
                with open(f, encoding="utf-8") as fp:
                    self._json({"task": task, "exists": True, "path": f,
                                "filename": os.path.basename(f), "md": fp.read()})
            else:
                self._json({"task": task, "exists": True, "path": f,
                            "filename": os.path.basename(f), "md": None})
            return
        if path == "/api/download":
            task = (q.get("task") or [""])[0]
            fn = (q.get("file") or [""])[0]
            if task not in OUT_DIRS or not fn:
                self._json({"error": "参数错误"}, 400)
                return
            fn = os.path.basename(fn)
            fp = os.path.join(BASE, OUT_DIRS[task], fn)
            if not os.path.exists(fp):
                self._json({"error": "文件不存在"}, 404)
                return
            with open(fp, "rb") as fh:
                body = fh.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + quote(os.path.basename(fp)))
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/api/data":
            task = (q.get("task") or [""])[0]
            if task not in OUT_DIRS:
                self._json({"error": "未知任务"}, 400)
                return
            f = latest_json(task)
            if f is None:
                self._json({"task": task, "exists": False,
                            "message": "暂无结构化数据，先运行任务生成"})
                return
            try:
                with open(f, encoding="utf-8") as fp:
                    obj = json.load(fp)
                self._json({"task": task, "exists": True, "filename": os.path.basename(f), "data": obj})
            except Exception as e:
                self._json({"task": task, "exists": False, "error": str(e)}, 500)
            return
        if path == "/api/review":
            # 今日复盘与明日研判：读取 daily_report 下最新的 *-今日复盘与明日研判.md
            d = os.path.join(BASE, "daily_report")
            cand = []
            if os.path.isdir(d):
                cand = [f for f in os.listdir(d) if "复盘" in f and f.endswith(".md")]
            if not cand:
                self._json({"exists": False,
                            "message": "暂无复盘与明日研判报告，可将 *-今日复盘与明日研判.md 放到 daily_report 目录后刷新。"})
                return
            cand.sort(key=lambda f: os.path.getmtime(os.path.join(d, f)), reverse=True)
            fp = os.path.join(d, cand[0])
            if (q.get("raw") or [""])[0] == "1":
                with open(fp, encoding="utf-8") as fh:
                    raw = fh.read().encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/markdown; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
            date = "-".join(cand[0].split("-")[:3])  # 文件名形如 2026-10-29-今日复盘与明日研判.md
            with open(fp, encoding="utf-8") as fh:
                md = fh.read()
            self._json({"exists": True, "filename": cand[0], "date": date, "md": md})
            return
        self._json({"error": "404 Not Found", "path": path}, 404)

    def do_POST(self):
        u = urlparse(self.path)
        path = u.path
        try:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b""
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            data = {}
        if path == "/api/login":
            if not AUTH_REQUIRED:
                self._json({"error": "当前为免登录模式"}, 404)
                return
            user = data.get("user", "")
            pw = data.get("password", "")
            if user == AUTH_USER and _hash_password(pw) == AUTH_HASH:
                token = _new_session(user)
                body = b'{"ok":true}'
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self._set_cookie(token)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self._json({"error": "用户名或密码错误"}, 401)
            return
        if not self._authed():
            self._json({"error": "未登录"}, 401)
            return
        if path == "/api/watch":
            watch = data.get("watch")
            if not isinstance(watch, list):
                self._json({"error": "watch 必须是列表"}, 400)
                return
            try:
                w = write_watch(watch)
                self._json({"ok": True, "watch": w})
            except Exception as e:
                self._json({"error": f"保存失败：{e}"}, 500)
            return
        if path == "/api/workshop":
            ind_id = data.get("id")
            if not ind_id:
                self._json({"error": "缺少 id"}, 400)
                return
            inds = load_indicators()
            found = next((it for it in inds if it.get("id") == ind_id), None)
            if found is None:
                self._json({"error": "指标不存在"}, 404)
                return
            if "enabled" in data:
                found["enabled"] = bool(data["enabled"])
            if "weight" in data:
                try:
                    found["weight"] = float(data["weight"])
                except (TypeError, ValueError):
                    self._json({"error": "weight 必须是数字"}, 400)
                    return
            save_indicators(inds)
            self._json({"ok": True, "indicator": found})
            return
        # ---- 技巧工坊：素材上传（base64） ----
        if path == "/api/workshop/upload":
            name = data.get("name", "")
            b64 = data.get("data", "")
            if not name or not b64:
                self._json({"error": "缺少文件名或内容"}, 400)
                return
            name = os.path.basename(name)
            if not name or name in (".", ".."):
                self._json({"error": "非法文件名"}, 400)
                return
            try:
                raw = base64.b64decode(b64)
            except Exception:
                self._json({"error": "文件内容解码失败"}, 400)
                return
            if len(raw) > 30 * 1024 * 1024:
                self._json({"error": "文件过大（上限 30MB）"}, 400)
                return
            os.makedirs(MATERIALS_DIR, exist_ok=True)
            fp = os.path.join(MATERIALS_DIR, name)
            try:
                with open(fp, "wb") as fh:
                    fh.write(raw)
                global _MAT_SNAP
                _MAT_SNAP = None  # 清空快照，使下次刷新能识别本次新增
                self._json({"ok": True, "name": name, "size": len(raw)})
            except Exception as e:
                self._json({"error": f"保存失败：{e}"}, 500)
            return
        # ---- 技巧工坊：打开素材文件夹 ----
        if path == "/api/workshop/open-folder":
            ok, note = open_materials_folder()
            self._json({"ok": ok, "note": note})
            return
        # ---- 技巧工坊：一键启动 WorkBuddy ----
        if path == "/api/workshop/launch-wb":
            ok, exe, note = launch_workbuddy()
            self._json({"ok": ok, "path": exe, "note": note,
                        "running": is_workbuddy_running()})
            return
        # ---- 技巧工坊：手动触发 AI 解析（需 WorkBuddy） ----
        if path == "/api/workshop/ai-parse":
            mats = list_materials()
            if not is_workbuddy_running():
                self._json({"status": "need_wb", "running": False,
                            "msg": "WorkBuddy 未运行，请先点击「一键启动 WorkBuddy」。"})
                return
            prompt = build_parse_prompt(mats)
            self._json({"status": "ready", "running": True,
                        "msg": "请切换到已启动的 WorkBuddy，把下方提示词粘贴到对话执行解析；"
                               "解析完成后回到本页点「刷新」即可载入新技巧。",
                        "prompt": prompt,
                        "materials": [m["name"] for m in mats]})
            return
        if path == "/api/run":
            global JOB_SEQ
            tasks = data.get("tasks") or []
            tasks = [t for t in tasks if t in SCRIPTS]
            if not tasks:
                self._json({"error": "未选择有效任务"}, 400)
                return
            with JOB_LOCK:
                JOB_SEQ += 1
                jid = f"job{JOB_SEQ}"
                JOBS[jid] = {"id": jid, "state": "queued", "log": [], "results": [],
                             "current": None, "started": now_str(), "error": None}
            job_log(jid, "🚀 任务队列已创建：" + " → ".join(TASK_NAMES.get(t, t) for t in tasks))
            th = threading.Thread(target=run_job, args=(jid, tasks), daemon=True)
            th.start()
            self._json({"id": jid, "tasks": tasks})
            return
        if path == "/api/screener/run":
            params = data.get("params") or {}
            with JOB_LOCK:
                JOB_SEQ += 1
                jid = f"job{JOB_SEQ}"
                JOBS[jid] = {"id": jid, "state": "queued", "log": [], "results": [],
                             "current": "选股重跑", "started": now_str(), "error": None}
            job_log(jid, "🚀 选股器实时重跑任务已创建")
            th = threading.Thread(target=run_screener_job, args=(jid, params), daemon=True)
            th.start()
            self._json({"id": jid})
            return
        self._json({"error": "404 Not Found"}, 404)


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    host = sys.argv[2] if len(sys.argv) > 2 else os.environ.get("BIND_HOST", "127.0.0.1")
    if not os.path.exists(BASE):
        os.makedirs(BASE, exist_ok=True)
    print("=" * 56)
    print("  A股投研雷达 · 本地控制台")
    print(f"  数据目录：{BASE}")
    print(f"  监听地址：{host}:{port}")
    print(f"  访问地址：http://{host if host != '0.0.0.0' else '127.0.0.1'}:{port}")
    print("  关闭服务：按 Ctrl+C")
    print("=" * 56)
    if not AUTH_REQUIRED:
        print("  登录验证：已取消（本机免登录，打开即用）")
    else:
        print(f"  登录验证：已启用（AUTH_REQUIRED=1，账号密码见 {AUTH_FILE}）")
    if host in ("0.0.0.0", ""):
        print("  [注意] 已绑定 0.0.0.0（监听所有网卡）。若需公网访问，请确保登录验证已启用，")
        print("         并经由带 TLS 的隧道/反向代理（如 Cloudflare Tunnel、ngrok）暴露，避免明文传输密码。")
    srv = ThreadingHTTPServer((host, port), Handler)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止。")
        srv.server_close()


if __name__ == "__main__":
    main()
